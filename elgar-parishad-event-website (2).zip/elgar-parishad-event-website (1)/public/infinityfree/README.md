# Elgar Parishad — InfinityFree Hosting Package

This folder is a **static HTML + PHP + MySQL** version of the Elgar Parishad website. It does **not** need Node.js, Next.js, PostgreSQL, npm, SSH, or a reverse proxy. It runs on InfinityFree's normal free PHP hosting.

## What is included

- `index.html` — public bilingual website (same design/sections/features)
- `organiser.html` — organiser dashboard
- `assets/tailwind.js`, `assets/lucide.min.js`, `assets/styles.css` — local UI assets (no CDN required)
- `js/i18n.js` — English / मराठी translations
- `js/initial-data.js` — snapshot of the current live content and photos
- `images/` — Dr. B.R. Ambedkar original photo, Chief Guest photo, organiser photos, and the large Dr. Ambedkar portrait
- `uploads/` — new photos uploaded by the committee
- `api/config.php`, `api/bootstrap.php`, `api/index.php` — JSON API endpoints
- `install.php` — one-click MySQL table creator/seeder
- `schema.sql` — manual phpMyAdmin import alternative
- `health.html` — static heartbeat page for external uptime monitors
- `.htaccess` — UTF-8, directory index, and static asset caching (kept minimal for shared-hosting compatibility)

## Deployment steps

1. In your **InfinityFree control panel**, create a **MySQL database**. Copy:
   - MySQL hostname (for example `sql123.infinityfree.com`)
   - Database name (for example `if0_12345678_elgar`)
   - Database username
   - Database password (this is your InfinityFree account password or the one shown in the panel)

2. Open `api/config.php` and replace the placeholder values:

   ```php
   define('DB_HOST', 'sqlXXX.infinityfree.com');
   define('DB_NAME', 'if0_XXXXXX_elgar');
   define('DB_USER', 'if0_XXXXXX');
   define('DB_PASS', 'CHANGE_ME');
   define('ORGANISER_PASSCODE', 'ELGAR2026'); // change to your own private passcode
   ```

3. Upload **the contents of this folder** (not the folder itself) into `htdocs` using the InfinityFree File Manager or FTP.

4. Make sure the `uploads/` folder exists and is writable. If photo uploads fail, set its permissions to `755` or `777` in the File Manager.

5. Visit `https://your-domain/install.php` once. It creates the MySQL tables and seeds the default announcements/opinions. Then **delete `install.php`** for security.

6. Open:
   - Public site: `https://your-domain/`
   - Organiser portal: `https://your-domain/organiser.html`
   - Default passcode: `ELGAR2026` (or whatever you set in `api/config.php`)

## How it works

- The public homepage is plain static HTML. On load it reads `js/initial-data.js` immediately, then calls `api/index.php?action=state` to refresh venue/time, updates, opinions, and photos from MySQL.
- RSVP registrations, opinions, updates, photos, and organiser tools are saved through PHP endpoints into MySQL.
- Uploaded photos are written to `uploads/` as normal files, so no PostgreSQL/Base64 database is needed.
- The organiser session uses a standard PHP session cookie; no Node.js server is required.
- If MySQL is not configured yet, the website still displays the exported snapshot from `js/initial-data.js`; forms will show a server error until `install.php` has been run.

## Dr. B.R. Ambedkar photo setting

- The organiser dashboard now has a **"Dr. Ambedkar Photo"** tab.
- Upload a JPG/PNG from a phone/PC or paste an image URL, then click **Save Large Photo**.
- The selected photo appears **large** in the Dr. Ambedkar section of the public homepage (`max-w-[420px]` on desktop, full width on mobile).
- **Restore Original** removes the custom upload and returns to the bundled archival portrait `images/ambedkar-original.jpg`.
- Existing installations are migrated automatically: `install.php` and `api/bootstrap.php` add the `ambedkar_photo_path` column if it is missing.
- The public footer and the organiser dashboard both include the credit **"Design by Sangham Prakash"**.

## Will the organiser portal go offline?

- **There is no Node.js process to crash.** `organiser.html` is a normal static HTML file served by Apache; `api/index.php` runs only when a request is made. This is why it works on InfinityFree.
- **The login is a normal first-party PHP session cookie.** The earlier preview "bouncing back to login" issue was caused by third-party cookie blocking inside the sandbox iframe. On a normal InfinityFree domain this does not apply.
- **The portal page itself stays reachable** even if MySQL is temporarily unavailable. The dashboard shows a clear error and the public site keeps showing its exported snapshot; RSVP/opinion/update actions resume once MySQL is back.
- **Free hosting is not a 100% uptime SLA.** InfinityFree can still have maintenance, resource limits, or suspend accounts after long inactivity. To reduce this risk, point a free uptime monitor (for example UptimeRobot) at `https://your-domain/health.html` and ping it every 5–10 minutes.
- **Use one canonical domain.** `example.com` and `www.example.com` are different cookie hosts. Open the portal from one of them consistently; otherwise you may simply be asked to log in again.
- **Sessions can expire after inactivity.** If that happens, sign in again with the passcode from `api/config.php`.
- **Photo uploads need a writable `uploads/` folder.** If uploads fail, set its permissions to `755` or `777` in the InfinityFree File Manager.
- **Keep backups** of your MySQL database and the `uploads/` folder. Free hosting does not guarantee backups.
- For a PHP-level check that does not require MySQL, use `api/index.php?action=health`.

## Notes

- InfinityFree free hosting provides **MySQL**, not PostgreSQL. This package uses MySQL only.
- The Next.js/PostgreSQL version remains in the main project for the preview sandbox; this folder is the deployable InfinityFree version.
- All static assets are local, so the site does not depend on Tailwind/Lucide CDNs at runtime.
- Keep a backup of `uploads/` and your MySQL database before making large changes.
