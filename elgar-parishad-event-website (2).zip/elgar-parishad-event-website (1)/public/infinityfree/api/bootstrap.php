<?php
require_once __DIR__ . '/config.php';

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_samesite', 'Lax');
    session_set_cookie_params(0, '/', '', false, true);
    session_start();
}

header('Content-Type: application/json; charset=utf-8');

function getDb() {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS, array(
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ));
    return $pdo;
}

function bodyJson() {
    $raw = file_get_contents('php://input');
    if (!$raw) return array();
    $data = json_decode($raw, true);
    return is_array($data) ? $data : array();
}

function jsonResponse($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function requireAuth() {
    if (empty($_SESSION['organiser'])) {
        jsonResponse(array('error' => 'Unauthorized'), 401);
    }
}

function isAuthenticated() {
    return !empty($_SESSION['organiser']);
}

function textVal($body, $key, $max = 1000) {
    $value = isset($body[$key]) && is_scalar($body[$key]) ? trim((string)$body[$key]) : '';
    if (function_exists('mb_substr')) return mb_substr($value, 0, $max);
    return substr($value, 0, $max);
}

function nullableText($body, $key, $max = 1000) {
    $value = textVal($body, $key, $max);
    return $value === '' ? null : $value;
}

function intValParam($body, $key, $default = 0, $min = 0, $max = 500) {
    $value = isset($body[$key]) ? intval($body[$key]) : $default;
    if ($value < $min) $value = $min;
    if ($value > $max) $value = $max;
    return $value;
}

function isoDate($value) {
    if (!$value) return '';
    $ts = strtotime((string)$value);
    return $ts ? date('c', $ts) : (string)$value;
}

function saveBase64Image($base64, $prefix) {
    if (!is_string($base64) || $base64 === '') {
        throw new Exception('Please choose a photo.');
    }
    $mime = 'image/jpeg';
    $raw = $base64;
    if (preg_match('/^data:image\/(png|jpeg|jpg|webp|gif);base64,(.+)$/is', $base64, $m)) {
        $mime = 'image/' . (strtolower($m[1]) === 'jpg' ? 'jpeg' : strtolower($m[1]));
        $raw = $m[2];
    }
    $binary = base64_decode($raw, true);
    if ($binary === false || strlen($binary) === 0) {
        throw new Exception('Invalid image data.');
    }
    if (strlen($binary) > 3 * 1024 * 1024) {
        throw new Exception('Image is too large. Please use a photo under 3MB.');
    }
    $ext = 'jpg';
    if (strpos($mime, 'png') !== false) $ext = 'png';
    elseif (strpos($mime, 'webp') !== false) $ext = 'webp';
    elseif (strpos($mime, 'gif') !== false) $ext = 'gif';
    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }
    $name = preg_replace('/[^a-zA-Z0-9_-]/', '-', $prefix) . '-' . bin2hex(random_bytes(8)) . '.' . $ext;
    if (file_put_contents(UPLOAD_DIR . $name, $binary) === false) {
        throw new Exception('Could not save the uploaded photo. Check uploads/ folder permissions.');
    }
    return UPLOAD_URL . $name;
}

function resolveImageInput($body, $prefix) {
    if (!empty($body['imageBase64'])) {
        return saveBase64Image($body['imageBase64'], $prefix);
    }
    if (!empty($body['imageUrl']) && is_string($body['imageUrl'])) {
        $url = trim($body['imageUrl']);
        if (preg_match('/^https?:\/\//i', $url) || substr($url, 0, 1) === '/') {
            return $url;
        }
        throw new Exception('Please provide a valid image URL.');
    }
    throw new Exception('Please choose a photo or provide an image URL.');
}

function deleteUploadedFile($url) {
    if (!$url || !is_string($url)) return;
    if (strpos($url, UPLOAD_URL) !== 0) return;
    $relative = substr($url, strlen(UPLOAD_URL));
    if (strpos($relative, '..') !== false || strpos($relative, '/') !== false) return;
    $path = UPLOAD_DIR . $relative;
    if (is_file($path)) @unlink($path);
}

function ensureAmbedkarPhotoColumn($db) {
    // Safe migration for sites installed before this setting was added.
    $stmt = $db->prepare("SELECT COUNT(*) AS c FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'event_settings'");
    $stmt->execute();
    $table = $stmt->fetch();
    if (!$table || intval($table['c']) === 0) return;

    $stmt = $db->prepare("SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'event_settings' AND COLUMN_NAME = 'ambedkar_photo_path'");
    $stmt->execute();
    $column = $stmt->fetch();
    if ($column && intval($column['c']) === 0) {
        $db->exec('ALTER TABLE event_settings ADD COLUMN ambedkar_photo_path VARCHAR(500) NULL');
    }
}

function defaultSettings() {
    return array(
        'venue_en' => 'To be announced soon by the Organising Committee (Nashik)',
        'venue_mr' => 'आयोजन समितीमार्फत लवकरच जाहीर केले जाईल (नाशिक)',
        'time_en' => 'To be announced soon',
        'time_mr' => 'लवकरच जाहीर केले जाईल',
        'guest_photo_path' => null,
        'ambedkar_photo_path' => null,
    );
}

function ensureSettings($db) {
    ensureAmbedkarPhotoColumn($db);
    $row = $db->query('SELECT * FROM event_settings ORDER BY id LIMIT 1')->fetch();
    if ($row) return $row;
    $d = defaultSettings();
    $stmt = $db->prepare('INSERT INTO event_settings (venue_en, venue_mr, time_en, time_mr, guest_photo_path, ambedkar_photo_path) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->execute(array($d['venue_en'], $d['venue_mr'], $d['time_en'], $d['time_mr'], null, null));
    return array_merge(array('id' => $db->lastInsertId()), $d);
}

function settingsDto($row) {
    return array(
        'id' => intval($row['id']),
        'venueEn' => $row['venue_en'],
        'venueMr' => $row['venue_mr'],
        'timeEn' => $row['time_en'],
        'timeMr' => $row['time_mr'],
        'guestPhotoUrl' => $row['guest_photo_path'] ?: null,
        'ambedkarPhotoUrl' => isset($row['ambedkar_photo_path']) ? ($row['ambedkar_photo_path'] ?: null) : null,
    );
}

function updateDto($row) {
    return array(
        'id' => intval($row['id']),
        'titleEn' => $row['title_en'],
        'titleMr' => $row['title_mr'],
        'bodyEn' => $row['body_en'],
        'bodyMr' => $row['body_mr'],
        'category' => $row['category'],
        'authorName' => $row['author_name'],
        'resolvedImageUrl' => $row['image_path'] ?: null,
        'isPinned' => (bool)$row['is_pinned'],
        'createdAt' => isoDate($row['created_at']),
    );
}

function opinionDto($row) {
    return array(
        'id' => intval($row['id']),
        'name' => $row['name'],
        'city' => $row['city'],
        'role' => $row['role'],
        'message' => $row['message'],
        'isVisible' => (bool)$row['is_visible'],
        'isFeatured' => (bool)$row['is_featured'],
        'createdAt' => isoDate($row['created_at']),
    );
}

function attendeeDto($row) {
    return array(
        'id' => intval($row['id']),
        'fullName' => $row['full_name'],
        'city' => $row['city'],
        'status' => $row['status'],
        'companions' => intval($row['companions']),
        'notes' => $row['notes'],
        'createdAt' => isoDate($row['created_at']),
    );
}

function organiserPhotosPayload($db) {
    $rows = $db->query('SELECT * FROM organiser_photos ORDER BY created_at DESC')->fetchAll();
    $profiles = array();
    $gallery = array();
    foreach ($rows as $row) {
        $url = $row['image_path'] ?: null;
        if (!$url) continue;
        if ($row['kind'] === 'profile' && $row['slot_key']) {
            if (!isset($profiles[$row['slot_key']])) $profiles[$row['slot_key']] = $url;
        } elseif ($row['kind'] === 'gallery') {
            $gallery[] = array(
                'id' => intval($row['id']),
                'url' => $url,
                'captionEn' => $row['caption_en'],
                'captionMr' => $row['caption_mr'],
            );
        }
    }
    return array('profiles' => $profiles, 'gallery' => $gallery);
}

function publicState($db) {
    $settings = ensureSettings($db);
    $updates = array();
    foreach ($db->query('SELECT * FROM updates ORDER BY is_pinned DESC, created_at DESC')->fetchAll() as $row) {
        $updates[] = updateDto($row);
    }
    $opinions = array();
    foreach ($db->query('SELECT * FROM opinions WHERE is_visible = 1 ORDER BY is_featured DESC, created_at DESC')->fetchAll() as $row) {
        $opinions[] = opinionDto($row);
    }
    return array(
        'settings' => settingsDto($settings),
        'guestPhotoUrl' => $settings['guest_photo_path'] ?: null,
        'ambedkarPhotoUrl' => isset($settings['ambedkar_photo_path']) ? ($settings['ambedkar_photo_path'] ?: null) : null,
        'updates' => $updates,
        'opinions' => $opinions,
        'organiserPhotos' => organiserPhotosPayload($db),
    );
}

function adminState($db) {
    $state = publicState($db);
    $attendees = array();
    foreach ($db->query('SELECT * FROM attendees ORDER BY created_at DESC')->fetchAll() as $row) {
        $attendees[] = attendeeDto($row);
    }
    $statsRow = $db->query("SELECT COUNT(*) AS total_registrations, COALESCE(SUM(status = 'attending'), 0) AS attending_registrations, COALESCE(SUM(status = 'maybe'), 0) AS maybe_registrations, COALESCE(SUM(CASE WHEN status = 'attending' THEN 1 + companions ELSE 0 END), 0) AS confirmed_headcount, COALESCE(SUM(1 + companions), 0) AS total_potential_headcount FROM attendees")->fetch();
    $allOpinions = array();
    foreach ($db->query('SELECT * FROM opinions ORDER BY is_featured DESC, created_at DESC')->fetchAll() as $row) {
        $allOpinions[] = opinionDto($row);
    }
    $state['attendees'] = $attendees;
    $state['opinionsAdmin'] = $allOpinions;
    $state['stats'] = array(
        'totalRegistrations' => intval($statsRow['total_registrations']),
        'attendingRegistrations' => intval($statsRow['attending_registrations']),
        'maybeRegistrations' => intval($statsRow['maybe_registrations']),
        'confirmedHeadcount' => intval($statsRow['confirmed_headcount']),
        'totalPotentialHeadcount' => intval($statsRow['total_potential_headcount']),
    );
    return $state;
}
