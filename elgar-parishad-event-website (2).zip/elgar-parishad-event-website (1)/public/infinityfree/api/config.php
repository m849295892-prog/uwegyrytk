<?php
// InfinityFree MySQL settings — fill these in before running install.php.
// Find them in your InfinityFree control panel under "MySQL Databases".
define('DB_HOST', 'sqlXXX.infinityfree.com');
define('DB_NAME', 'if0_XXXXXX_elgar');
define('DB_USER', 'if0_XXXXXX');
define('DB_PASS', 'CHANGE_ME');

// Change this to a private passcode for your organising committee.
define('ORGANISER_PASSCODE', 'ELGAR2026');

// Uploaded photos are stored as files inside this folder.
define('UPLOAD_DIR', dirname(__DIR__) . '/uploads/');
define('UPLOAD_URL', 'uploads/');
