<?php
require_once __DIR__ . '/bootstrap.php';

$action = isset($_GET['action']) ? (string)$_GET['action'] : 'health';
$method = $_SERVER['REQUEST_METHOD'];
$body = bodyJson();

try {
    if ($action === 'health') {
        jsonResponse(array('ok' => true));
    }

    if ($action === 'state' && $method === 'GET') {
        jsonResponse(publicState(getDb()));
    }

    if ($action === 'rsvp' && $method === 'POST') {
        $fullName = textVal($body, 'fullName', 255);
        $city = textVal($body, 'city', 255);
        if (strlen($fullName) < 2) jsonResponse(array('error' => 'Please enter your full name'), 400);
        if (strlen($city) < 2) jsonResponse(array('error' => 'Please enter your city, taluka, or village'), 400);
        $status = isset($body['status']) && $body['status'] === 'maybe' ? 'maybe' : 'attending';
        $companions = intValParam($body, 'companions', 0, 0, 500);
        $notes = nullableText($body, 'notes', 1000);
        $db = getDb();
        ensureSettings($db);
        $stmt = $db->prepare('INSERT INTO attendees (full_name, city, status, companions, notes) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute(array($fullName, $city, $status, $companions, $notes));
        $id = $db->lastInsertId();
        jsonResponse(array('registration' => array(
            'id' => intval($id),
            'referenceCode' => 'ELG-2026-' . str_pad((string)$id, 4, '0', STR_PAD_LEFT),
            'fullName' => $fullName,
            'city' => $city,
            'status' => $status,
            'companions' => $companions,
        )), 201);
    }

    if ($action === 'opinion' && $method === 'POST') {
        $name = textVal($body, 'name', 255);
        $city = textVal($body, 'city', 255);
        $role = nullableText($body, 'role', 255);
        $message = textVal($body, 'message', 1200);
        if (strlen($name) < 2) jsonResponse(array('error' => 'Please enter your name'), 400);
        if (strlen($city) < 2) jsonResponse(array('error' => 'Please enter your city or district'), 400);
        if (strlen($message) < 5) jsonResponse(array('error' => 'Please share your opinion (at least 5 characters)'), 400);
        $db = getDb();
        ensureSettings($db);
        $stmt = $db->prepare('INSERT INTO opinions (name, city, role, message, is_visible, is_featured) VALUES (?, ?, ?, ?, 1, 0)');
        $stmt->execute(array($name, $city, $role, $message));
        $id = $db->lastInsertId();
        $row = $db->prepare('SELECT * FROM opinions WHERE id = ?');
        $row->execute(array($id));
        jsonResponse(array('opinion' => opinionDto($row->fetch())), 201);
    }

    if ($action === 'login' && $method === 'POST') {
        $passcode = isset($body['passcode']) ? (string)$body['passcode'] : '';
        if (!hash_equals(ORGANISER_PASSCODE, trim($passcode))) {
            jsonResponse(array('error' => 'Invalid organiser passcode'), 401);
        }
        $_SESSION['organiser'] = true;
        jsonResponse(array('authenticated' => true));
    }

    if ($action === 'logout' && $method === 'POST') {
        $_SESSION = array();
        session_destroy();
        jsonResponse(array('authenticated' => false));
    }

    if ($action === 'session' && $method === 'GET') {
        jsonResponse(array('authenticated' => isAuthenticated()));
    }

    if ($action === 'admin' && $method === 'GET') {
        requireAuth();
        jsonResponse(adminState(getDb()));
    }

    if ($action === 'attendees' && $method === 'GET') {
        requireAuth();
        $state = adminState(getDb());
        jsonResponse(array('attendees' => $state['attendees'], 'stats' => $state['stats']));
    }

    if ($action === 'attendee_delete' && $method === 'DELETE') {
        requireAuth();
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        if ($id <= 0) jsonResponse(array('error' => 'Invalid ID'), 400);
        $stmt = getDb()->prepare('DELETE FROM attendees WHERE id = ?');
        $stmt->execute(array($id));
        jsonResponse(array('deleted' => true));
    }

    if ($action === 'opinion_patch' && $method === 'PATCH') {
        requireAuth();
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        if ($id <= 0) jsonResponse(array('error' => 'Invalid ID'), 400);
        $sets = array();
        $params = array();
        if (isset($body['isVisible']) && is_bool($body['isVisible'])) {
            $sets[] = 'is_visible = ?';
            $params[] = $body['isVisible'] ? 1 : 0;
        }
        if (isset($body['isFeatured']) && is_bool($body['isFeatured'])) {
            $sets[] = 'is_featured = ?';
            $params[] = $body['isFeatured'] ? 1 : 0;
        }
        if (empty($sets)) jsonResponse(array('error' => 'Nothing to update'), 400);
        $params[] = $id;
        $stmt = getDb()->prepare('UPDATE opinions SET ' . implode(', ', $sets) . ' WHERE id = ?');
        $stmt->execute($params);
        jsonResponse(array('updated' => true));
    }

    if ($action === 'opinion_delete' && $method === 'DELETE') {
        requireAuth();
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        if ($id <= 0) jsonResponse(array('error' => 'Invalid ID'), 400);
        $stmt = getDb()->prepare('DELETE FROM opinions WHERE id = ?');
        $stmt->execute(array($id));
        jsonResponse(array('deleted' => true));
    }

    if ($action === 'update_post' && $method === 'POST') {
        requireAuth();
        $titleEn = textVal($body, 'titleEn', 500);
        $titleMr = nullableText($body, 'titleMr', 500);
        $bodyEn = textVal($body, 'bodyEn', 5000);
        $bodyMr = nullableText($body, 'bodyMr', 5000);
        $category = textVal($body, 'category', 50) ?: 'announcement';
        if (!in_array($category, array('announcement', 'venue', 'photo', 'press'), true)) $category = 'announcement';
        $authorName = textVal($body, 'authorName', 255) ?: 'Organising Committee';
        $isPinned = !empty($body['isPinned']) ? 1 : 0;
        $imagePath = null;
        if (!empty($body['imageBase64']) || !empty($body['imageUrl'])) {
            $imagePath = resolveImageInput($body, 'update');
        }
        if ($titleEn === '' && !$titleMr) jsonResponse(array('error' => 'Please provide a post title'), 400);
        $stmt = getDb()->prepare('INSERT INTO updates (title_en, title_mr, body_en, body_mr, category, author_name, image_path, is_pinned) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute(array($titleEn ?: $titleMr, $titleMr ?: $titleEn, $bodyEn, $bodyMr, $category, $authorName, $imagePath, $isPinned));
        jsonResponse(array('update' => array('id' => intval(getDb()->lastInsertId()))), 201);
    }

    if ($action === 'update_patch' && $method === 'PATCH') {
        requireAuth();
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        if ($id <= 0) jsonResponse(array('error' => 'Invalid ID'), 400);
        $pinned = isset($body['isPinned']) && $body['isPinned'] ? 1 : 0;
        $stmt = getDb()->prepare('UPDATE updates SET is_pinned = ? WHERE id = ?');
        $stmt->execute(array($pinned, $id));
        jsonResponse(array('updated' => true));
    }

    if ($action === 'update_delete' && $method === 'DELETE') {
        requireAuth();
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        if ($id <= 0) jsonResponse(array('error' => 'Invalid ID'), 400);
        $db = getDb();
        $stmt = $db->prepare('SELECT image_path FROM updates WHERE id = ?');
        $stmt->execute(array($id));
        $row = $stmt->fetch();
        if ($row) deleteUploadedFile($row['image_path']);
        $del = $db->prepare('DELETE FROM updates WHERE id = ?');
        $del->execute(array($id));
        jsonResponse(array('deleted' => true));
    }

    if ($action === 'venue' && $method === 'POST') {
        requireAuth();
        $db = getDb();
        $settings = ensureSettings($db);
        $venueEn = textVal($body, 'venueEn', 500) ?: 'To be announced soon by the Organising Committee (Nashik)';
        $venueMr = nullableText($body, 'venueMr', 500) ?: $venueEn;
        $timeEn = textVal($body, 'timeEn', 255) ?: 'To be announced soon';
        $timeMr = nullableText($body, 'timeMr', 255) ?: $timeEn;
        $stmt = $db->prepare('UPDATE event_settings SET venue_en = ?, venue_mr = ?, time_en = ?, time_mr = ? WHERE id = ?');
        $stmt->execute(array($venueEn, $venueMr, $timeEn, $timeMr, $settings['id']));
        jsonResponse(array('settings' => settingsDto(array_merge($settings, array('venue_en' => $venueEn, 'venue_mr' => $venueMr, 'time_en' => $timeEn, 'time_mr' => $timeMr)))));
    }

    if ($action === 'guest_photo' && $method === 'POST') {
        requireAuth();
        $db = getDb();
        $settings = ensureSettings($db);
        $path = resolveImageInput($body, 'chief-guest');
        if (!empty($settings['guest_photo_path'])) deleteUploadedFile($settings['guest_photo_path']);
        $stmt = $db->prepare('UPDATE event_settings SET guest_photo_path = ? WHERE id = ?');
        $stmt->execute(array($path, $settings['id']));
        jsonResponse(array('guestPhotoUrl' => $path));
    }

    if ($action === 'guest_photo_delete' && $method === 'DELETE') {
        requireAuth();
        $db = getDb();
        $settings = ensureSettings($db);
        if (!empty($settings['guest_photo_path'])) deleteUploadedFile($settings['guest_photo_path']);
        $stmt = $db->prepare('UPDATE event_settings SET guest_photo_path = NULL WHERE id = ?');
        $stmt->execute(array($settings['id']));
        jsonResponse(array('guestPhotoUrl' => null));
    }

    if ($action === 'ambedkar_photo' && $method === 'POST') {
        requireAuth();
        $db = getDb();
        $settings = ensureSettings($db);
        $path = resolveImageInput($body, 'ambedkar');
        if (!empty($settings['ambedkar_photo_path'])) deleteUploadedFile($settings['ambedkar_photo_path']);
        $stmt = $db->prepare('UPDATE event_settings SET ambedkar_photo_path = ? WHERE id = ?');
        $stmt->execute(array($path, $settings['id']));
        jsonResponse(array('ambedkarPhotoUrl' => $path));
    }

    if ($action === 'ambedkar_photo_delete' && $method === 'DELETE') {
        requireAuth();
        $db = getDb();
        $settings = ensureSettings($db);
        if (!empty($settings['ambedkar_photo_path'])) deleteUploadedFile($settings['ambedkar_photo_path']);
        $stmt = $db->prepare('UPDATE event_settings SET ambedkar_photo_path = NULL WHERE id = ?');
        $stmt->execute(array($settings['id']));
        jsonResponse(array('ambedkarPhotoUrl' => null));
    }

    if ($action === 'organiser_photo' && $method === 'POST') {
        requireAuth();
        $kind = isset($body['kind']) && $body['kind'] === 'profile' ? 'profile' : 'gallery';
        $slotKey = textVal($body, 'slotKey', 100);
        $allowed = array('babanrao-gholap', 'vilas-patil', 'prakash-bagul', 'mahesh-avhad', 'sanjay-donde');
        if ($kind === 'profile' && !in_array($slotKey, $allowed, true)) {
            jsonResponse(array('error' => 'Please select a valid organiser'), 400);
        }
        $captionEn = $kind === 'gallery' ? nullableText($body, 'captionEn', 200) : null;
        $captionMr = $kind === 'gallery' ? nullableText($body, 'captionMr', 200) : null;
        $prefix = $kind === 'profile' ? 'organiser-' . $slotKey : 'committee';
        $path = resolveImageInput($body, $prefix);
        $db = getDb();
        if ($kind === 'profile') {
            $old = $db->prepare("SELECT image_path FROM organiser_photos WHERE kind = 'profile' AND slot_key = ?");
            $old->execute(array($slotKey));
            foreach ($old->fetchAll() as $row) deleteUploadedFile($row['image_path']);
            $del = $db->prepare("DELETE FROM organiser_photos WHERE kind = 'profile' AND slot_key = ?");
            $del->execute(array($slotKey));
        }
        $stmt = $db->prepare('INSERT INTO organiser_photos (kind, slot_key, image_path, caption_en, caption_mr) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute(array($kind, $kind === 'profile' ? $slotKey : null, $path, $captionEn, $captionMr));
        jsonResponse(organiserPhotosPayload($db), 201);
    }

    if ($action === 'organiser_photo_delete' && $method === 'DELETE') {
        requireAuth();
        $db = getDb();
        $slotKey = isset($_GET['slotKey']) ? (string)$_GET['slotKey'] : '';
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        if ($slotKey !== '') {
            $stmt = $db->prepare("SELECT * FROM organiser_photos WHERE kind = 'profile' AND slot_key = ?");
            $stmt->execute(array($slotKey));
            foreach ($stmt->fetchAll() as $row) {
                deleteUploadedFile($row['image_path']);
                $del = $db->prepare('DELETE FROM organiser_photos WHERE id = ?');
                $del->execute(array($row['id']));
            }
        } elseif ($id > 0) {
            $stmt = $db->prepare('SELECT * FROM organiser_photos WHERE id = ?');
            $stmt->execute(array($id));
            $row = $stmt->fetch();
            if ($row) {
                deleteUploadedFile($row['image_path']);
                $del = $db->prepare('DELETE FROM organiser_photos WHERE id = ?');
                $del->execute(array($id));
            }
        } else {
            jsonResponse(array('error' => 'Please specify a photo to remove'), 400);
        }
        jsonResponse(organiserPhotosPayload($db));
    }

    jsonResponse(array('error' => 'Unknown action'), 404);
} catch (Throwable $e) {
    error_log('Elgar InfinityFree API error: ' . $e->getMessage());
    jsonResponse(array('error' => 'Server error. Please check api/config.php and run install.php.'), 500);
}
