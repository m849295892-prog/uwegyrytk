<?php
require_once __DIR__ . '/api/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');

$messages = array();
$error = null;

try {
    $db = getDb();

    $statements = array(
        "CREATE TABLE IF NOT EXISTS event_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            venue_en TEXT NOT NULL,
            venue_mr TEXT NOT NULL,
            time_en VARCHAR(255) NOT NULL,
            time_mr VARCHAR(255) NOT NULL,
            guest_photo_path VARCHAR(500) NULL,
            ambedkar_photo_path VARCHAR(500) NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS attendees (
            id INT AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(255) NOT NULL,
            city VARCHAR(255) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'attending',
            companions INT NOT NULL DEFAULT 0,
            notes TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS opinions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            city VARCHAR(255) NOT NULL,
            role VARCHAR(255) NULL,
            message TEXT NOT NULL,
            is_visible TINYINT(1) NOT NULL DEFAULT 1,
            is_featured TINYINT(1) NOT NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS updates (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title_en VARCHAR(500) NOT NULL,
            title_mr TEXT NULL,
            body_en TEXT NULL,
            body_mr TEXT NULL,
            category VARCHAR(50) NOT NULL DEFAULT 'announcement',
            author_name VARCHAR(255) NOT NULL DEFAULT 'Organising Committee',
            image_path VARCHAR(500) NULL,
            is_pinned TINYINT(1) NOT NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS organiser_photos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            kind VARCHAR(20) NOT NULL DEFAULT 'gallery',
            slot_key VARCHAR(100) NULL,
            image_path VARCHAR(500) NULL,
            caption_en VARCHAR(500) NULL,
            caption_mr VARCHAR(500) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    );

    foreach ($statements as $sql) {
        $db->exec($sql);
        $messages[] = 'Table ready.';
    }

    ensureAmbedkarPhotoColumn($db);
    $messages[] = 'Dr. Ambedkar photo setting ready.';

    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }
    @chmod(UPLOAD_DIR, 0777);
    $messages[] = 'Uploads folder ready.';

    $count = $db->query('SELECT COUNT(*) AS c FROM event_settings')->fetch();
    if (intval($count['c']) === 0) {
        $stmt = $db->prepare('INSERT INTO event_settings (venue_en, venue_mr, time_en, time_mr) VALUES (?, ?, ?, ?)');
        $stmt->execute(array(
            'To be announced soon by the Organising Committee (Nashik)',
            'आयोजन समितीमार्फत लवकरच जाहीर केले जाईल (नाशिक)',
            'To be announced soon',
            'लवकरच जाहीर केले जाईल',
        ));
        $messages[] = 'Default venue/time seeded.';
    }

    $count = $db->query('SELECT COUNT(*) AS c FROM updates')->fetch();
    if (intval($count['c']) === 0) {
        $stmt = $db->prepare('INSERT INTO updates (title_en, title_mr, body_en, body_mr, category, author_name, is_pinned) VALUES (?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute(array(
            'Elgar Parishad for Private Sector Reservation — 12th December 2026, Nashik',
            'खाजगी क्षेत्रातील आरक्षणासाठी एल्गार परिषद — १२ डिसेंबर २०२६, नाशिक',
            'We invite all citizens, students, workers, and Ambedkarite organisations to unite in Nashik on 12th December 2026 under the guidance of Chief Guest Adv. Prakash Ambedkar to raise our constitutional demand for reservation in the private sector.',
            'खाजगी क्षेत्रातील आरक्षणाच्या घटनात्मक मागणीसाठी १२ डिसेंबर २०२६ रोजी नाशिक येथे प्रमुख पाहुणे अ‍ॅड. प्रकाश आंबेडकर यांच्या मार्गदर्शनाखाली होणाऱ्या एल्गार परिषदेत सर्व नागरिक, विद्यार्थी, कामगार आणि आंबेडकरी संघटनांनी मोठ्या संख्येने सहभागी व्हावे.',
            'announcement',
            'Organising Committee (Babanrao Gholap, Vilas Patil, Prakash Bagul)',
            1,
            'Venue & Schedule Notice from the Organising Committee',
            'स्थळ व वेळेबाबत आयोजन समितीची सूचना',
            'Preparations across Nashik district are underway. The exact ground/venue and detailed schedule for 12th December 2026 will be officially announced soon by the Organising Committee.',
            'नाशिक जिल्ह्यात तयारी वेगाने सुरू आहे. १२ डिसेंबर २०२६ च्या परिषदेचे निश्चित ठिकाण आणि सविस्तर वेळापत्रक आयोजन समितीमार्फत लवकरच जाहीर केले जाईल.',
            'venue',
            'Organising Committee',
            0,
        ));
        $messages[] = 'Default announcements seeded.';
    }

    $count = $db->query('SELECT COUNT(*) AS c FROM opinions')->fetch();
    if (intval($count['c']) === 0) {
        $stmt = $db->prepare('INSERT INTO opinions (name, city, role, message, is_visible, is_featured) VALUES (?, ?, ?, ?, 1, 1), (?, ?, ?, ?, 1, 1)');
        $stmt->execute(array(
            'Milind Kamble', 'Nashik', 'Youth Activist',
            'With rapid privatization across industries, constitutional reservation in the private sector is essential for social justice and equal opportunity. Fully supporting Elgar Parishad!',
            'सुजाता गायकवाड', 'मनमाड, नाशिक', 'विद्यार्थिनी',
            'खाजगी क्षेत्रात आरक्षण लागू झाल्याशिवाय बहुजन तरुणांना समान संधी मिळणार नाही. १२ डिसेंबर रोजी नाशिकच्या एल्गार परिषदेत आम्ही नक्की सहभागी होणार!',
        ));
        $messages[] = 'Default opinions seeded.';
    }
} catch (Throwable $e) {
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Elgar Parishad — InfinityFree Installer</title>
  <script src="assets/tailwind.js"></script>
  <link rel="stylesheet" href="assets/styles.css">
</head>
<body class="bg-slate-50 min-h-screen flex items-center justify-center p-4">
  <div class="max-w-xl w-full bg-white rounded-2xl shadow-xl border border-slate-200 p-8">
    <h1 class="text-2xl font-extrabold text-[#08245E] mb-3">InfinityFree Setup</h1>
    <?php if ($error): ?>
      <div class="p-4 rounded-xl bg-red-50 border border-red-200 text-red-800 text-sm mb-4">
        <strong>Setup failed:</strong> <?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?>
      </div>
      <p class="text-sm text-slate-600">Edit <code>api/config.php</code> with your InfinityFree MySQL host, database, user, and password, then refresh this page.</p>
    <?php else: ?>
      <div class="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-sm mb-4">
        <strong>Setup complete!</strong> Your MySQL tables are ready.
      </div>
      <ul class="list-disc pl-5 text-sm text-slate-600 space-y-1 mb-5">
        <?php foreach ($messages as $message): ?>
          <li><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></li>
        <?php endforeach; ?>
      </ul>
      <p class="text-sm text-slate-700 mb-4">For security, <strong>delete install.php</strong> from your hosting now.</p>
      <div class="flex flex-wrap gap-3">
        <a href="index.html" class="px-5 py-2.5 rounded-xl bg-[#0D47A1] text-white font-semibold text-sm">Open Website</a>
        <a href="organiser.html" class="px-5 py-2.5 rounded-xl bg-amber-400 text-[#08245E] font-semibold text-sm">Organiser Portal</a>
      </div>
    <?php endif; ?>
  </div>
</body>
</html>
