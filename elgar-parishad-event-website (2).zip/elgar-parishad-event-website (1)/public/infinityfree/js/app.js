(function () {
  'use strict';

  var lang = 'en';
  var state = normalizeState(window.ELGAR_INITIAL_DATA || {});
  var rsvpStatus = 'attending';
  var SLOTS = [
    'babanrao-gholap',
    'vilas-patil',
    'prakash-bagul',
    'mahesh-avhad',
    'sanjay-donde'
  ];

  function t() { return window.ELGAR_TRANSLATIONS[lang]; }

  function esc(value) {
    return String(value === undefined || value === null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
  }

  function resolvePath(obj, path) {
    return path.split('.').reduce(function (acc, key) {
      return acc === undefined || acc === null ? undefined : acc[key];
    }, obj);
  }

  function normalizeState(raw) {
    var settings = raw.settings || {};
    return {
      settings: {
        id: settings.id || 1,
        venueEn: settings.venueEn || 'To be announced soon by the Organising Committee (Nashik)',
        venueMr: settings.venueMr || 'आयोजन समितीमार्फत लवकरच जाहीर केले जाईल (नाशिक)',
        timeEn: settings.timeEn || 'To be announced soon',
        timeMr: settings.timeMr || 'लवकरच जाहीर केले जाईल',
        guestPhotoUrl: raw.guestPhotoUrl !== undefined ? raw.guestPhotoUrl : (settings.guestPhotoUrl || null),
        ambedkarPhotoUrl: raw.ambedkarPhotoUrl || settings.ambedkarPhotoUrl || 'images/ambedkar-original.jpg'
      },
      updates: Array.isArray(raw.updates) ? raw.updates : [],
      opinions: Array.isArray(raw.opinions) ? raw.opinions : [],
      organiserPhotos: {
        profiles: (raw.organiserPhotos && raw.organiserPhotos.profiles) || {},
        gallery: (raw.organiserPhotos && Array.isArray(raw.organiserPhotos.gallery)) ? raw.organiserPhotos.gallery : []
      }
    };
  }

  function apiRequest(action, method, body) {
    var options = {
      method: method || 'GET',
      cache: 'no-store',
      credentials: 'same-origin',
      headers: {}
    };
    if (body) {
      options.headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(body);
    }
    return fetch('api/index.php?action=' + encodeURIComponent(action), options)
      .then(function (res) { return res.text().then(function (text) { return { res: res, text: text }; }); })
      .then(function (result) {
        var data;
        try { data = JSON.parse(result.text); }
        catch (e) { throw new Error('Server returned an invalid response. Run install.php and check api/config.php.'); }
        if (!result.res.ok) throw new Error(data.error || 'Request failed.');
        return data;
      });
  }

  function formatDate(value) {
    if (!value) return '';
    var d = new Date(value);
    if (isNaN(d.getTime())) return '';
    try { return d.toLocaleDateString(lang === 'mr' ? 'mr-IN' : 'en-IN', { day: 'numeric', month: 'short', year: 'numeric' }); }
    catch (e) { return d.toLocaleDateString(); }
  }

  function applyStaticTranslations() {
    var tr = t();
    document.documentElement.lang = lang === 'mr' ? 'mr' : 'en';
    document.title = tr.siteTitle + ' | Reservation in the Private Sector';

    document.querySelectorAll('[data-i18n]').forEach(function (el) {
      var value = resolvePath(tr, el.getAttribute('data-i18n'));
      if (typeof value === 'string') el.textContent = value;
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach(function (el) {
      var value = resolvePath(tr, el.getAttribute('data-i18n-placeholder'));
      if (typeof value === 'string') el.setAttribute('placeholder', value);
    });
    document.querySelectorAll('[data-custom-en]').forEach(function (el) {
      var value = lang === 'mr' ? (el.getAttribute('data-custom-mr') || '') : (el.getAttribute('data-custom-en') || '');
      var target = el.classList.contains('lang-switch-text') ? el : el.querySelector('.lang-switch-text');
      (target || el).textContent = value;
    });
    document.querySelectorAll('[data-lang-btn]').forEach(function (btn) {
      var active = btn.getAttribute('data-lang-btn') === lang;
      btn.className = 'px-2.5 sm:px-3 py-1 rounded-full text-xs font-semibold transition ' +
        (active ? 'bg-amber-400 text-[#08245E] shadow' : 'text-blue-100 hover:text-white');
    });
  }

  function setLang(next) {
    lang = next === 'mr' ? 'mr' : 'en';
    try { localStorage.setItem('elgar_lang', lang); } catch (e) {}
    applyStaticTranslations();
    renderAll();
  }

  function renderSettings() {
    var s = state.settings;
    var venue = document.getElementById('venueText');
    var time = document.getElementById('timeText');
    if (venue) venue.textContent = lang === 'mr' ? s.venueMr : s.venueEn;
    if (time) time.textContent = lang === 'mr' ? s.timeMr : s.timeEn;

    var ambedkarImg = document.getElementById('ambedkarPhoto');
    if (ambedkarImg) {
      ambedkarImg.src = s.ambedkarPhotoUrl || 'images/ambedkar-original.jpg';
    }

    var wrap = document.getElementById('chiefGuestPhotoWrap');
    if (!wrap) return;
    if (s.guestPhotoUrl) {
      wrap.innerHTML = '<img src="' + esc(s.guestPhotoUrl) + '" alt="' + esc(t().hero.chiefGuestName) + '" class="w-full h-full object-cover object-top">';
      wrap.className = 'w-16 h-16 sm:w-20 sm:h-20 rounded-full border-2 border-amber-300 shadow-lg bg-white/10 shrink-0 overflow-hidden';
    } else {
      wrap.textContent = 'PA';
      wrap.className = 'w-16 h-16 sm:w-20 sm:h-20 rounded-full border-2 border-amber-300/60 bg-amber-400/20 shadow-inner shrink-0 flex items-center justify-center text-amber-200 font-extrabold text-lg';
    }
  }

  function renderOrganiserPhotos() {
    var profiles = state.organiserPhotos.profiles || {};
    for (var i = 0; i < 5; i++) {
      var container = document.getElementById('orgPhoto' + i);
      if (!container) continue;
      var url = profiles[SLOTS[i]];
      if (url) {
        var size = i < 3 ? 'w-16 h-16 border-[#0D47A1]' : 'w-14 h-14 border-blue-200';
        container.innerHTML = '<img src="' + esc(url) + '" alt="Organiser" class="' + size + ' rounded-full object-cover object-top border-2 shadow bg-white">';
      } else if (i < 3) {
        container.innerHTML = '<div class="w-14 h-14 rounded-full bg-[#0D47A1] text-amber-300 flex items-center justify-center shadow"><span data-chakra="w-8 h-8" class="inline-flex"></span></div>';
      } else {
        container.innerHTML = '<div class="w-12 h-12 rounded-full bg-blue-100 text-[#0D47A1] flex items-center justify-center"><i data-lucide="users" class="w-6 h-6"></i></div>';
      }
    }
  }

  function renderGallery() {
    var gallery = state.organiserPhotos.gallery || [];
    var grid = document.getElementById('committeeGallery');
    var empty = document.getElementById('committeeGalleryEmpty');
    if (!grid || !empty) return;
    if (!gallery.length) {
      grid.innerHTML = '';
      grid.classList.add('hidden');
      grid.classList.remove('grid');
      empty.classList.remove('hidden');
      return;
    }
    empty.classList.add('hidden');
    grid.classList.remove('hidden');
    grid.classList.add('grid');
    grid.innerHTML = gallery.map(function (item) {
      var caption = lang === 'mr'
        ? (item.captionMr || item.captionEn || t().organisers.galleryTitle)
        : (item.captionEn || item.captionMr || t().organisers.galleryTitle);
      return '<button type="button" data-lightbox-url="' + esc(item.url) + '" data-lightbox-title="' + esc(caption) + '" class="group bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden text-left hover:shadow-md transition">' +
        '<img src="' + esc(item.url) + '" alt="' + esc(caption) + '" class="w-full h-52 object-cover bg-slate-100 group-hover:scale-105 transition duration-300">' +
        '<div class="px-4 py-3 text-sm font-semibold text-[#0F172A]">' + esc(caption) + '</div></button>';
    }).join('');
  }

  function renderUpdates() {
    var grid = document.getElementById('updatesGrid');
    if (!grid) return;
    var updates = state.updates || [];
    if (!updates.length) {
      grid.className = 'bg-white rounded-2xl border border-slate-200 p-10 text-center text-slate-500';
      grid.innerHTML = esc(t().updates.noUpdates);
      return;
    }
    grid.className = 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6';
    grid.innerHTML = updates.map(function (post) {
      var title = lang === 'mr' ? (post.titleMr || post.titleEn || '') : (post.titleEn || post.titleMr || '');
      var body = lang === 'mr' ? (post.bodyMr || post.bodyEn || '') : (post.bodyEn || post.bodyMr || '');
      var categories = t().updates.categories;
      var catLabel = categories[post.category] || categories.announcement;
      var image = post.resolvedImageUrl
        ? '<button type="button" data-lightbox-url="' + esc(post.resolvedImageUrl) + '" data-lightbox-title="' + esc(title) + '" class="relative h-52 w-full bg-slate-100 overflow-hidden group"><img src="' + esc(post.resolvedImageUrl) + '" alt="' + esc(title) + '" class="w-full h-full object-cover group-hover:scale-105 transition duration-300"></button>'
        : '';
      var pinned = post.isPinned
        ? '<span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900"><i data-lucide="pin" class="w-3 h-3"></i>' + esc(t().updates.pinnedBadge) + '</span>'
        : '';
      return '<article class="bg-white rounded-2xl border ' + (post.isPinned ? 'border-amber-400 ring-1 ring-amber-300/60' : 'border-slate-200') + ' shadow-sm overflow-hidden flex flex-col">' + image +
        '<div class="p-6 flex-1 flex flex-col justify-between space-y-4"><div class="space-y-3"><div class="flex flex-wrap items-center justify-between gap-2"><span class="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wide bg-blue-50 text-[#0D47A1] border border-blue-100">' + esc(catLabel) + '</span>' + pinned + '</div>' +
        '<h3 class="text-lg font-bold leading-snug">' + esc(title) + '</h3>' +
        (body ? '<p class="text-sm text-slate-600 leading-relaxed whitespace-pre-line">' + esc(body) + '</p>' : '') +
        '</div><div class="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500"><span class="truncate max-w-[65%]">' + esc(t().updates.postedBy) + ' ' + esc(post.authorName || '') + '</span><span>' + esc(formatDate(post.createdAt)) + '</span></div></div></article>';
    }).join('');
  }

  function renderOpinions() {
    var list = document.getElementById('opinionsList');
    var count = document.getElementById('opinionCount');
    if (!list) return;
    var opinions = state.opinions || [];
    if (count) count.textContent = String(opinions.length);
    if (!opinions.length) {
      list.innerHTML = '<div class="bg-white rounded-2xl p-8 border border-slate-200 text-center text-slate-500 text-sm">' + esc(t().opinions.emptyFeed) + '</div>';
      return;
    }
    list.innerHTML = opinions.map(function (op) {
      var meta = esc(op.city) + (op.role ? ' • ' + esc(op.role) : '');
      var featured = op.isFeatured
        ? '<span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900"><i data-lucide="sparkles" class="w-3 h-3"></i>' + esc(t().opinions.featuredBadge) + '</span>'
        : '';
      return '<div class="bg-white rounded-2xl p-5 border shadow-sm ' + (op.isFeatured ? 'border-amber-300 ring-1 ring-amber-200' : 'border-slate-200') + '">' +
        '<div class="flex flex-wrap items-center justify-between gap-2 mb-2"><div><span class="font-bold">' + esc(op.name) + '</span><span class="text-xs text-slate-500 ml-2">' + meta + '</span></div>' + featured + '</div>' +
        '<p class="text-sm text-slate-700 leading-relaxed whitespace-pre-line">“' + esc(op.message) + '”</p>' +
        '<div class="text-[11px] text-slate-400 mt-2">' + esc(formatDate(op.createdAt)) + '</div></div>';
    }).join('');
  }

  function refreshIcons() {
    if (window.lucide && typeof window.lucide.createIcons === 'function') window.lucide.createIcons();
    if (window.renderChakras) window.renderChakras(document);
  }

  function attachLightbox() {
    document.querySelectorAll('[data-lightbox-url]').forEach(function (el) {
      if (el.getAttribute('data-lightbox-bound') === '1') return;
      el.setAttribute('data-lightbox-bound', '1');
      el.addEventListener('click', function () {
        var box = document.getElementById('lightbox');
        var img = document.getElementById('lightboxImage');
        var title = document.getElementById('lightboxTitle');
        if (!box || !img || !title) return;
        img.src = el.getAttribute('data-lightbox-url') || '';
        img.alt = el.getAttribute('data-lightbox-title') || '';
        title.textContent = el.getAttribute('data-lightbox-title') || '';
        box.classList.remove('hidden');
      });
    });
  }

  function renderAll() {
    renderSettings();
    renderOrganiserPhotos();
    renderGallery();
    renderUpdates();
    renderOpinions();
    attachLightbox();
    refreshIcons();
  }

  function updateRsvpButtons() {
    var yes = document.getElementById('rsvpStatusAttending');
    var maybe = document.getElementById('rsvpStatusMaybe');
    if (!yes || !maybe) return;
    var base = 'p-3.5 rounded-xl border-2 text-left text-sm font-semibold flex items-center gap-2.5 transition ';
    yes.className = base + (rsvpStatus === 'attending' ? 'border-[#0D47A1] bg-blue-50 text-[#08245E]' : 'border-slate-200 text-slate-700');
    maybe.className = base + (rsvpStatus === 'maybe' ? 'border-amber-500 bg-amber-50 text-amber-950' : 'border-slate-200 text-slate-700');
  }

  function showError(id, message) {
    var el = document.getElementById(id);
    if (!el) return;
    el.textContent = message;
    el.classList.remove('hidden');
  }

  function hide(id) {
    var el = document.getElementById(id);
    if (el) el.classList.add('hidden');
  }

  function bindEvents() {
    document.querySelectorAll('[data-lang-btn]').forEach(function (btn) {
      btn.addEventListener('click', function () { setLang(btn.getAttribute('data-lang-btn')); });
    });
    document.querySelectorAll('[data-lang-switch]').forEach(function (btn) {
      btn.addEventListener('click', function () { setLang(lang === 'en' ? 'mr' : 'en'); });
    });

    var menuButton = document.getElementById('mobileMenuButton');
    var menu = document.getElementById('mobileMenu');
    if (menuButton && menu) {
      menuButton.addEventListener('click', function () { menu.classList.toggle('hidden'); });
      menu.querySelectorAll('a').forEach(function (a) {
        a.addEventListener('click', function () { menu.classList.add('hidden'); });
      });
    }

    var yes = document.getElementById('rsvpStatusAttending');
    var maybe = document.getElementById('rsvpStatusMaybe');
    if (yes) yes.addEventListener('click', function () { rsvpStatus = 'attending'; updateRsvpButtons(); });
    if (maybe) maybe.addEventListener('click', function () { rsvpStatus = 'maybe'; updateRsvpButtons(); });

    var rsvpForm = document.getElementById('rsvpForm');
    if (rsvpForm) {
      rsvpForm.addEventListener('submit', function (e) {
        e.preventDefault();
        hide('rsvpError');
        var submit = document.getElementById('rsvpSubmit');
        if (submit) { submit.disabled = true; submit.textContent = t().rsvp.submitting; }
        apiRequest('rsvp', 'POST', {
          fullName: document.getElementById('rsvpFullName').value,
          city: document.getElementById('rsvpCity').value,
          status: rsvpStatus,
          companions: Number(document.getElementById('rsvpCompanions').value) || 0,
          notes: document.getElementById('rsvpNotes').value
        }).then(function (data) {
          rsvpForm.classList.add('hidden');
          document.getElementById('rsvpSuccess').classList.remove('hidden');
          document.getElementById('rsvpSuccessRef').textContent = data.registration.referenceCode + ' • ' + data.registration.fullName;
          rsvpForm.reset();
          rsvpStatus = 'attending';
          updateRsvpButtons();
        }).catch(function (err) {
          showError('rsvpError', err.message);
        }).finally(function () {
          if (submit) { submit.disabled = false; submit.textContent = t().rsvp.submitBtn; }
        });
      });
    }

    var rsvpReset = document.getElementById('rsvpReset');
    if (rsvpReset) {
      rsvpReset.addEventListener('click', function () {
        document.getElementById('rsvpSuccess').classList.add('hidden');
        document.getElementById('rsvpForm').classList.remove('hidden');
        rsvpStatus = 'attending';
        updateRsvpButtons();
      });
    }

    var opinionForm = document.getElementById('opinionForm');
    if (opinionForm) {
      opinionForm.addEventListener('submit', function (e) {
        e.preventDefault();
        hide('opError');
        hide('opSuccess');
        var submit = document.getElementById('opSubmit');
        if (submit) { submit.disabled = true; submit.textContent = t().opinions.submitting; }
        apiRequest('opinion', 'POST', {
          name: document.getElementById('opName').value,
          city: document.getElementById('opCity').value,
          role: document.getElementById('opRole').value,
          message: document.getElementById('opMessage').value
        }).then(function (data) {
          state.opinions.unshift(data.opinion);
          renderOpinions();
          attachLightbox();
          refreshIcons();
          document.getElementById('opSuccess').classList.remove('hidden');
          opinionForm.reset();
        }).catch(function (err) {
          showError('opError', err.message);
        }).finally(function () {
          if (submit) { submit.disabled = false; submit.textContent = t().opinions.submitBtn; }
        });
      });
    }

    var lightbox = document.getElementById('lightbox');
    var lightboxClose = document.getElementById('lightboxClose');
    if (lightboxClose) lightboxClose.addEventListener('click', function () { lightbox.classList.add('hidden'); });
    if (lightbox) lightbox.addEventListener('click', function (e) { if (e.target === lightbox) lightbox.classList.add('hidden'); });
  }

  function hydrate() {
    apiRequest('state', 'GET').then(function (data) {
      state = normalizeState(data);
      renderAll();
    }).catch(function () {
      // Keep the static snapshot when PHP/MySQL is not configured yet.
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    try { lang = localStorage.getItem('elgar_lang') === 'mr' ? 'mr' : 'en'; } catch (e) {}
    state = normalizeState(window.ELGAR_INITIAL_DATA || {});
    applyStaticTranslations();
    updateRsvpButtons();
    bindEvents();
    renderAll();
    hydrate();
  });
})();
