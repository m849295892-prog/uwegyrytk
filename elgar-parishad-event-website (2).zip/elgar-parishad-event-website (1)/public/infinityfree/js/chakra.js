window.chakraSVG = function (className) {
  var lines = '';
  for (var i = 0; i < 24; i++) {
    lines += '<line x1="50" y1="41" x2="50" y2="6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" transform="rotate(' + (i * 15) + ' 50 50)"/>';
  }
  return '<svg viewBox="0 0 100 100" class="' + className + '" fill="none" aria-hidden="true">' +
    '<circle cx="50" cy="50" r="45" stroke="currentColor" stroke-width="4.5"/>' +
    '<circle cx="50" cy="50" r="9" stroke="currentColor" stroke-width="3.5"/>' +
    '<circle cx="50" cy="50" r="3.5" fill="currentColor"/>' + lines + '</svg>';
};

window.renderChakras = function (root) {
  var scope = root || document;
  scope.querySelectorAll('[data-chakra]').forEach(function (el) {
    if (el.getAttribute('data-chakra-rendered') === '1') return;
    el.innerHTML = window.chakraSVG(el.getAttribute('data-chakra') || 'w-8 h-8');
    el.setAttribute('data-chakra-rendered', '1');
  });
};

document.addEventListener('DOMContentLoaded', function () {
  window.renderChakras();
});
