window.ELGAR_INITIAL_DATA = {
  "settings": {
    "id": 1,
    "venueEn": "To be announced soon by the Organising Committee (Nashik)",
    "venueMr": "आयोजन समितीमार्फत लवकरच जाहीर केले जाईल (नाशिक)",
    "timeEn": "To be announced soon",
    "timeMr": "लवकरच जाहीर केले जाईल",
    "guestPhotoUrl": "images/chief-guest.jpg",
    "ambedkarPhotoUrl": "images/ambedkar-original.jpg"
  },
  "updates": [
    {
      "id": 1,
      "titleEn": "Elgar Parishad for Private Sector Reservation — 12th December 2026, Nashik",
      "titleMr": "खाजगी क्षेत्रातील आरक्षणासाठी एल्गार परिषद — १२ डिसेंबर २०२६, नाशिक",
      "bodyEn": "We invite all citizens, students, workers, and Ambedkarite organisations to unite in Nashik on 12th December 2026 under the guidance of Chief Guest Adv. Prakash Ambedkar to raise our constitutional demand for reservation in the private sector.",
      "bodyMr": "खाजगी क्षेत्रातील आरक्षणाच्या घटनात्मक मागणीसाठी १२ डिसेंबर २०२६ रोजी नाशिक येथे प्रमुख पाहुणे अ‍ॅड. प्रकाश आंबेडकर यांच्या मार्गदर्शनाखाली होणाऱ्या एल्गार परिषदेत सर्व नागरिक, विद्यार्थी, कामगार आणि आंबेडकरी संघटनांनी मोठ्या संख्येने सहभागी व्हावे.",
      "category": "announcement",
      "authorName": "Organising Committee (Babanrao Gholap, Vilas Patil, Prakash Bagul)",
      "resolvedImageUrl": null,
      "isPinned": true,
      "createdAt": "2026-11-10T11:42:57.983Z"
    },
    {
      "id": 2,
      "titleEn": "Venue & Schedule Notice from the Organising Committee",
      "titleMr": "स्थळ व वेळेबाबत आयोजन समितीची सूचना",
      "bodyEn": "Preparations across Nashik district are underway. The exact ground/venue and detailed schedule for 12th December 2026 will be officially announced soon by the Organising Committee. Please register your attendance below to receive timely updates.",
      "bodyMr": "नाशिक जिल्ह्यात तयारी वेगाने सुरू आहे. १२ डिसेंबर २०२६ च्या परिषदेचे निश्चित ठिकाण आणि सविस्तर वेळापत्रक आयोजन समितीमार्फत लवकरच जाहीर केले जाईल. वेळेवर माहिती मिळवण्यासाठी कृपया खाली आपली उपस्थिती नोंदवा.",
      "category": "venue",
      "authorName": "Organising Committee",
      "resolvedImageUrl": null,
      "isPinned": false,
      "createdAt": "2026-11-10T11:42:57.983Z"
    }
  ],
  "opinions": [
    {
      "id": 1,
      "name": "Milind Kamble",
      "city": "Nashik",
      "role": "Youth Activist",
      "message": "With rapid privatization across industries, constitutional reservation in the private sector is essential for social justice and equal opportunity. Fully supporting Elgar Parishad!",
      "isVisible": true,
      "isFeatured": true,
      "createdAt": "2026-11-10T11:42:57.986Z"
    },
    {
      "id": 2,
      "name": "सुजाता गायकवाड",
      "city": "मनमाड, नाशिक",
      "role": "विद्यार्थिनी",
      "message": "खाजगी क्षेत्रात आरक्षण लागू झाल्याशिवाय बहुजन तरुणांना समान संधी मिळणार नाही. १२ डिसेंबर रोजी नाशिकच्या एल्गार परिषदेत आम्ही नक्की सहभागी होणार!",
      "isVisible": true,
      "isFeatured": true,
      "createdAt": "2026-11-10T11:42:57.986Z"
    }
  ],
  "organiserPhotos": {
    "profiles": {
      "prakash-bagul": "images/organiser-prakash-bagul.jpg"
    },
    "gallery": []
  }
};
