(function () {
  'use strict';

  var lang = 'en';
  var admin = null;
  var currentTab = 'attendees';
  var filteredAttendees = [];
  var payloads = { update: null, guestPhoto: null, ambedkarPhoto: null, profilePhoto: null, galleryPhoto: null };

  var SLOTS = [
    { key: 'babanrao-gholap', nameEn: 'Babanrao Gholap', nameMr: 'बबनराव घोलप' },
    { key: 'vilas-patil', nameEn: 'Vilas Patil', nameMr: 'विलास पाटील' },
    { key: 'prakash-bagul', nameEn: 'Prakash Bagul', nameMr: 'प्रकाश बागुल' },
    { key: 'mahesh-avhad', nameEn: 'Mahesh Avhad', nameMr: 'महेश आव्हाड' },
    { key: 'sanjay-donde', nameEn: 'Sanjay Donde', nameMr: 'संजय दोंदे' }
  ];

  var MSG = {
    en: {
      noAttendees: 'No matching attendee registrations found yet.',
      confirmed: 'confirmed', tentative: 'tentative',
      noUpdates: 'No updates published yet.',
      noOpinions: 'No public opinions submitted yet.',
      noGallery: 'No committee photos uploaded yet.',
      remove: 'Remove', highlight: 'Highlight', unhighlight: 'Unhighlight',
      hide: 'Hide', show: 'Show', delete: 'Delete', pin: 'Pin', unpin: 'Unpin',
      saved: 'Saved successfully.', removed: 'Removed successfully.',
      choosePhoto: 'Please choose a photo first.',
      chooseImageOrUrl: 'Please choose a photo or paste an image URL.',
      loginFailed: 'Invalid organiser passcode.',
      loadFailed: 'Could not load dashboard data. Check api/config.php and run install.php.',
      saving: 'Saving...', publishing: 'Publishing...', verifying: 'Verifying...',
      updatePublished: 'Update published to the website!',
      venueSaved: 'Venue & time updated on the public homepage!',
      guestPhotoSaved: 'Chief Guest photo is now live beside his name!',
      guestPhotoRemoved: 'Chief Guest photo removed.',
      ambedkarPhotoSaved: "Dr. Ambedkar's large photo is now live on the homepage!",
      ambedkarPhotoRemoved: 'Reverted to the original archival photo.',
      profileSaved: 'Organiser profile photo updated!',
      gallerySaved: 'Committee photo published to the gallery!',
      photoRemoved: 'Photo removed.',
      csvName: 'elgar-parishad-attendees.csv',
      ref: 'Ref', name: 'Name', city: 'City / Taluka', status: 'Status',
      headcount: 'Headcount', notes: 'Notes', action: 'Action',
      attending: 'Attending', maybe: 'Maybe', featured: 'Highlighted',
      hidden: 'Hidden', publishedUpdates: 'Published Updates',
      allPhotos: 'Published Photos'
    },
    mr: {
      noAttendees: 'अजून कोणतीही नोंदणी नाही.',
      confirmed: 'निश्चित', tentative: 'इच्छुक',
      noUpdates: 'अजून कोणतीही माहिती प्रसिद्ध नाही.',
      noOpinions: 'अजून कोणतेही मत नोंदवले नाही.',
      noGallery: 'अजून कोणतेही छायाचित्र जोडले नाही.',
      remove: 'काढा', highlight: 'ठळक करा', unhighlight: 'ठळकपणा काढा',
      hide: 'लपवा', show: 'दाखवा', delete: 'काढून टाका', pin: 'पिन करा', unpin: 'पिन काढा',
      saved: 'यशस्वीरित्या जतन केले.', removed: 'यशस्वीरित्या काढले.',
      choosePhoto: 'कृपया आधी फोटो निवडा.',
      chooseImageOrUrl: 'कृपया फोटो निवडा किंवा लिंक टाका.',
      loginFailed: 'चुकीचा पासकोड.',
      loadFailed: 'डॅशबोर्ड माहिती लोड झाली नाही. api/config.php तपासा व install.php चालवा.',
      saving: 'जतन होत आहे...', publishing: 'प्रसिद्ध होत आहे...', verifying: 'तपासत आहे...',
      updatePublished: 'माहिती वेबसाईटवर प्रसिद्ध झाली!',
      venueSaved: 'स्थळ आणि वेळ मुख्य पानावर अपडेट झाली आहे!',
      guestPhotoSaved: 'प्रमुख पाहुण्यांचा फोटो नावाजवळ प्रसिद्ध झाला आहे!',
      guestPhotoRemoved: 'प्रमुख पाहुण्यांचा फोटो काढला आहे.',
      ambedkarPhotoSaved: 'डॉ. बाबासाहेब आंबेडकरांचा मोठा फोटो मुख्य पानावर अपडेट झाला आहे!',
      ambedkarPhotoRemoved: 'मूळ ऐतिहासिक छायाचित्र पुन्हा वापरले जात आहे.',
      profileSaved: 'आयोजकाचा फोटो अपडेट झाला!',
      gallerySaved: 'समितीचे छायाचित्र गॅलरीत प्रसिद्ध झाले!',
      photoRemoved: 'छायाचित्र काढले आहे.',
      csvName: 'elgar-parishad-attendees.csv',
      ref: 'क्र.', name: 'नाव', city: 'शहर / तालुका', status: 'स्थिती',
      headcount: 'एकूण लोक', notes: 'टीप', action: 'कृती',
      attending: 'उपस्थित', maybe: 'इच्छुक', featured: 'निवडलेले',
      hidden: 'लपवलेले', publishedUpdates: 'प्रसिद्ध केलेल्या पोस्ट',
      allPhotos: 'प्रसिद्ध छायाचित्रे'
    }
  };

  function msg(key) { return (MSG[lang] && MSG[lang][key]) || MSG.en[key] || key; }

  function esc(value) {
    return String(value === undefined || value === null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
  }

  function apiRequest(params, method, body) {
    var qs = new URLSearchParams(params || {}).toString();
    var options = {
      method: method || 'GET',
      cache: 'no-store',
      credentials: 'same-origin',
      headers: {}
    };
    if (body) {
      options.headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(body);
    }
    return fetch('api/index.php?' + qs, options)
      .then(function (res) { return res.text().then(function (text) { return { res: res, text: text }; }); })
      .then(function (result) {
        var data;
        try { data = JSON.parse(result.text); }
        catch (e) {
          var err = new Error(msg('loadFailed'));
          err.status = result.res.status;
          throw err;
        }
        if (!result.res.ok) {
          var error = new Error(data.error || msg('loadFailed'));
          error.status = result.res.status;
          throw error;
        }
        return data;
      });
  }

  function compressImage(file) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onerror = function () { reject(new Error('Could not read file')); };
      reader.onload = function () {
        var img = new Image();
        img.onerror = function () { reject(new Error('Invalid image file')); };
        img.onload = function () {
          var maxDim = 1280;
          var width = img.width, height = img.height;
          if (width > maxDim || height > maxDim) {
            if (width > height) { height = Math.round(height * maxDim / width); width = maxDim; }
            else { width = Math.round(width * maxDim / height); height = maxDim; }
          }
          var canvas = document.createElement('canvas');
          canvas.width = width; canvas.height = height;
          var ctx = canvas.getContext('2d');
          if (!ctx) { reject(new Error('Canvas unavailable')); return; }
          ctx.drawImage(img, 0, 0, width, height);
          resolve({
            base64: canvas.toDataURL('image/jpeg', 0.82),
            mimeType: 'image/jpeg',
            fileName: file.name
          });
        };
        img.src = String(reader.result);
      };
      reader.readAsDataURL(file);
    });
  }

  function formatDate(value) {
    if (!value) return '';
    var d = new Date(value);
    if (isNaN(d.getTime())) return '';
    try { return d.toLocaleDateString(lang === 'mr' ? 'mr-IN' : 'en-IN'); }
    catch (e) { return d.toLocaleDateString(); }
  }

  function showFeedback(id, text) {
    var el = document.getElementById(id);
    if (!el) return;
    el.textContent = text;
    el.classList.remove('hidden');
  }
  function hideFeedback(id) {
    var el = document.getElementById(id);
    if (el) el.classList.add('hidden');
  }
  function busy(btn, text) {
    if (!btn) return;
    btn.setAttribute('data-original-text', btn.textContent);
    btn.disabled = true;
    btn.textContent = text;
  }
  function unbusy(btn) {
    if (!btn) return;
    btn.disabled = false;
    btn.textContent = btn.getAttribute('data-original-text') || 'Save';
  }

  function applyDashTranslations() {
    document.documentElement.lang = lang === 'mr' ? 'mr' : 'en';
    document.title = lang === 'mr' ? 'एल्गार परिषद — आयोजक पोर्टल' : 'Elgar Parishad — Organiser Portal';
    document.querySelectorAll('[data-dash-en]').forEach(function (el) {
      var value = lang === 'mr' ? el.getAttribute('data-dash-mr') : el.getAttribute('data-dash-en');
      if (value !== null) el.textContent = value;
    });
    document.querySelectorAll('[data-dash-en-placeholder]').forEach(function (el) {
      var value = lang === 'mr' ? el.getAttribute('data-dash-mr-placeholder') : el.getAttribute('data-dash-en-placeholder');
      if (value !== null) el.setAttribute('placeholder', value);
    });
    document.querySelectorAll('[data-dash-lang-btn]').forEach(function (btn) {
      var active = btn.getAttribute('data-dash-lang-btn') === lang;
      btn.className = 'px-2.5 py-1 rounded-full text-xs font-semibold ' +
        (active ? 'bg-amber-400 text-[#08245E]' : 'text-slate-600');
      if (btn.closest('header')) {
        btn.className = 'px-2.5 py-1 rounded-full text-xs font-semibold ' +
          (active ? 'bg-amber-400 text-[#08245E]' : 'text-blue-100');
      }
    });
  }

  function setDashLang(next) {
    lang = next === 'mr' ? 'mr' : 'en';
    try { localStorage.setItem('elgar_dash_lang', lang); } catch (e) {}
    applyDashTranslations();
    renderAll();
  }

  function showLogin() {
    document.getElementById('dashboardView').classList.add('hidden');
    document.getElementById('loginView').classList.remove('hidden');
    applyDashTranslations();
    refreshIcons();
  }

  function showDashboard() {
    document.getElementById('loginView').classList.add('hidden');
    document.getElementById('dashboardView').classList.remove('hidden');
    applyDashTranslations();
    refreshIcons();
  }

  function refreshIcons() {
    if (window.lucide && typeof window.lucide.createIcons === 'function') window.lucide.createIcons();
    if (window.renderChakras) window.renderChakras(document);
  }

  function renderKpis() {
    if (!admin) return;
    var stats = admin.stats || {};
    var attendees = admin.attendees || [];
    var opinions = admin.opinionsAdmin || [];
    var updates = admin.updates || [];
    document.getElementById('statHeadcount').textContent = String(stats.confirmedHeadcount || 0);
    document.getElementById('statApplications').textContent = String(stats.totalRegistrations || 0);
    document.getElementById('statOpinions').textContent = String(opinions.length);
    document.getElementById('statUpdates').textContent = String(updates.length);
    document.getElementById('statApplicationsNote').textContent =
      (stats.attendingRegistrations || 0) + ' ' + msg('confirmed') + ' • ' +
      (stats.maybeRegistrations || 0) + ' ' + msg('tentative');
    document.getElementById('attendeeTabCount').textContent = String(attendees.length);
    document.getElementById('opinionTabCount').textContent = String(opinions.length);
    document.getElementById('updatesAdminCount').textContent = String(updates.length);
  }

  function renderAttendees() {
    var wrap = document.getElementById('attendeesTableWrap');
    if (!wrap || !admin) return;
    var q = (document.getElementById('attendeeSearch').value || '').trim().toLowerCase();
    var status = document.getElementById('attendeeStatusFilter').value;
    filteredAttendees = (admin.attendees || []).filter(function (a) {
      if (status !== 'all' && a.status !== status) return false;
      if (!q) return true;
      return (a.fullName || '').toLowerCase().indexOf(q) !== -1 ||
        (a.city || '').toLowerCase().indexOf(q) !== -1 ||
        (a.notes || '').toLowerCase().indexOf(q) !== -1;
    });

    if (!filteredAttendees.length) {
      wrap.innerHTML = '<div class="p-10 text-center text-slate-500 text-sm">' + esc(msg('noAttendees')) + '</div>';
      return;
    }
    wrap.innerHTML = '<div class="overflow-x-auto"><table class="w-full text-left text-sm"><thead class="bg-slate-50 text-xs uppercase text-slate-600 border-b border-slate-200"><tr>' +
      '<th class="px-4 py-3" data-dash-en="Ref" data-dash-mr="क्र.">Ref</th>' +
      '<th class="px-4 py-3" data-dash-en="Name" data-dash-mr="नाव">Name</th>' +
      '<th class="px-4 py-3" data-dash-en="City / Taluka" data-dash-mr="शहर / तालुका">City / Taluka</th>' +
      '<th class="px-4 py-3" data-dash-en="Status" data-dash-mr="स्थिती">Status</th>' +
      '<th class="px-4 py-3" data-dash-en="Headcount" data-dash-mr="एकूण लोक">Headcount</th>' +
      '<th class="px-4 py-3" data-dash-en="Notes" data-dash-mr="टीप">Notes</th>' +
      '<th class="px-4 py-3 text-right" data-dash-en="Action" data-dash-mr="कृती">Action</th>' +
      '</tr></thead><tbody class="divide-y divide-slate-100">' +
      filteredAttendees.map(function (row) {
        var statusLabel = row.status === 'attending' ? msg('attending') : msg('maybe');
        var statusClass = row.status === 'attending' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800';
        return '<tr class="hover:bg-slate-50/70">' +
          '<td class="px-4 py-3 font-mono text-xs text-slate-500">ELG-' + String(row.id).padStart(4, '0') + '</td>' +
          '<td class="px-4 py-3 font-semibold">' + esc(row.fullName) + '</td>' +
          '<td class="px-4 py-3">' + esc(row.city) + '</td>' +
          '<td class="px-4 py-3"><span class="inline-flex px-2.5 py-0.5 rounded-full text-xs font-semibold ' + statusClass + '">' + esc(statusLabel) + '</span></td>' +
          '<td class="px-4 py-3 font-bold text-[#0D47A1]">' + (1 + Number(row.companions || 0)) + ' <span class="text-xs font-normal text-slate-500">(+' + Number(row.companions || 0) + ')</span></td>' +
          '<td class="px-4 py-3 text-xs text-slate-600 max-w-xs truncate">' + esc(row.notes || '—') + '</td>' +
          '<td class="px-4 py-3 text-right"><button type="button" data-action="delete-attendee" data-id="' + row.id + '" title="' + esc(msg('delete')) + '" class="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50"><i data-lucide="trash-2" class="w-4 h-4"></i></button></td>' +
          '</tr>';
      }).join('') + '</tbody></table></div>';
  }

  function renderUpdatesAdmin() {
    var list = document.getElementById('updatesAdminList');
    if (!list || !admin) return;
    var updates = admin.updates || [];
    if (!updates.length) {
      list.innerHTML = '<div class="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-500 text-sm">' + esc(msg('noUpdates')) + '</div>';
      return;
    }
    list.innerHTML = updates.map(function (u) {
      var img = u.resolvedImageUrl ? '<img src="' + esc(u.resolvedImageUrl) + '" alt="" class="w-full sm:w-32 h-28 object-cover rounded-xl shrink-0 bg-slate-100">' : '';
      return '<div class="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col sm:flex-row gap-4 shadow-sm">' + img +
        '<div class="flex-1 space-y-1.5"><div class="flex items-center justify-between gap-2"><span class="text-[11px] font-bold uppercase text-[#0D47A1] bg-blue-50 px-2 py-0.5 rounded-full">' + esc(u.category) + '</span><div class="flex gap-1.5">' +
        '<button type="button" data-action="toggle-pin" data-id="' + u.id + '" data-pinned="' + (u.isPinned ? '1' : '0') + '" title="' + esc(u.isPinned ? msg('unpin') : msg('pin')) + '" class="p-1.5 rounded-lg ' + (u.isPinned ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-600') + '"><i data-lucide="' + (u.isPinned ? 'pin-off' : 'pin') + '" class="w-4 h-4"></i></button>' +
        '<button type="button" data-action="delete-update" data-id="' + u.id + '" title="' + esc(msg('delete')) + '" class="p-1.5 rounded-lg bg-red-50 text-red-600"><i data-lucide="trash-2" class="w-4 h-4"></i></button>' +
        '</div></div><h4 class="font-bold text-sm">' + esc(u.titleEn) + '</h4>' +
        (u.titleMr && u.titleMr !== u.titleEn ? '<div class="text-xs font-semibold text-slate-700">' + esc(u.titleMr) + '</div>' : '') +
        '<p class="text-xs text-slate-600 line-clamp-2">' + esc(u.bodyEn || '') + '</p>' +
        '<div class="text-[11px] text-slate-400">' + esc(u.authorName || '') + ' • ' + esc(formatDate(u.createdAt)) + '</div></div></div>';
    }).join('');
  }

  function renderOpinionsAdmin() {
    var list = document.getElementById('opinionsAdminList');
    if (!list || !admin) return;
    var opinions = admin.opinionsAdmin || [];
    if (!opinions.length) {
      list.innerHTML = '<div class="md:col-span-2 bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-500 text-sm">' + esc(msg('noOpinions')) + '</div>';
      return;
    }
    list.innerHTML = opinions.map(function (op) {
      return '<div class="bg-white rounded-2xl p-5 border shadow-sm space-y-3 ' + (!op.isVisible ? 'border-slate-200 opacity-60' : op.isFeatured ? 'border-amber-400' : 'border-slate-200') + '">' +
        '<div class="flex items-start justify-between gap-2"><div><div class="font-bold">' + esc(op.name) + '</div><div class="text-xs text-slate-500">' + esc(op.city) + (op.role ? ' • ' + esc(op.role) : '') + '</div></div>' +
        '<div class="flex items-center gap-1.5">' +
        '<button type="button" data-action="toggle-featured" data-id="' + op.id + '" data-featured="' + (op.isFeatured ? '1' : '0') + '" title="' + esc(op.isFeatured ? msg('unhighlight') : msg('highlight')) + '" class="p-1.5 rounded-lg ' + (op.isFeatured ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-600') + '"><i data-lucide="sparkles" class="w-4 h-4"></i></button>' +
        '<button type="button" data-action="toggle-visible" data-id="' + op.id + '" data-visible="' + (op.isVisible ? '1' : '0') + '" title="' + esc(op.isVisible ? msg('hide') : msg('show')) + '" class="p-1.5 rounded-lg bg-slate-100 text-slate-700"><i data-lucide="' + (op.isVisible ? 'eye' : 'eye-off') + '" class="w-4 h-4"></i></button>' +
        '<button type="button" data-action="delete-opinion" data-id="' + op.id + '" title="' + esc(msg('delete')) + '" class="p-1.5 rounded-lg bg-red-50 text-red-600"><i data-lucide="trash-2" class="w-4 h-4"></i></button>' +
        '</div></div><p class="text-sm text-slate-700 leading-relaxed">“' + esc(op.message) + '”</p>' +
        '<div class="text-[11px] text-slate-400">' + esc(formatDate(op.createdAt)) + '</div></div>';
    }).join('');
  }

  function renderVenue() {
    if (!admin || !admin.settings) return;
    document.getElementById('venueEn').value = admin.settings.venueEn || '';
    document.getElementById('venueMr').value = admin.settings.venueMr || '';
    document.getElementById('timeEn').value = admin.settings.timeEn || '';
    document.getElementById('timeMr').value = admin.settings.timeMr || '';
  }

  function renderGuestPhoto() {
    var wrap = document.getElementById('guestPhotoAdminPreview');
    if (!wrap || !admin) return;
    var url = admin.guestPhotoUrl || (admin.settings && admin.settings.guestPhotoUrl) || null;
    if (url) {
      wrap.innerHTML = '<img src="' + esc(url) + '" alt="Adv. Prakash Ambedkar" class="w-full h-full object-cover object-top">';
      wrap.className = 'w-20 h-20 rounded-full border-2 border-amber-300 shadow-lg bg-white/10 overflow-hidden';
    } else {
      wrap.textContent = 'PA';
      wrap.className = 'w-20 h-20 rounded-full border-2 border-amber-300/60 bg-amber-400/20 flex items-center justify-center text-amber-200 font-extrabold text-xl';
    }
  }

  function renderAmbedkarPhoto() {
    var wrap = document.getElementById('ambedkarPhotoAdminPreview');
    if (!wrap || !admin) return;
    var url = admin.ambedkarPhotoUrl ||
      (admin.settings && admin.settings.ambedkarPhotoUrl) ||
      'images/ambedkar-original.jpg';
    wrap.innerHTML = '<img src="' + esc(url) + '" alt="Dr. B.R. Ambedkar" class="w-full h-auto object-cover block">';
    wrap.className = 'rounded-2xl overflow-hidden border-4 border-amber-400/80 shadow-2xl max-w-[360px] w-full bg-slate-900';
  }

  function renderOrganiserPhotos() {
    if (!admin) return;
    var photos = admin.organiserPhotos || { profiles: {}, gallery: [] };
    var profiles = photos.profiles || {};
    var gallery = photos.gallery || [];
    var grid = document.getElementById('profilePhotosGrid');
    grid.innerHTML = SLOTS.map(function (slot) {
      var url = profiles[slot.key];
      var name = lang === 'mr' ? slot.nameMr : slot.nameEn;
      var initials = slot.nameEn.split(' ').map(function (w) { return w[0]; }).join('');
      return '<div class="bg-slate-50 border border-slate-200 rounded-xl p-3 text-center">' +
        (url ? '<img src="' + esc(url) + '" alt="' + esc(name) + '" class="w-14 h-14 rounded-full object-cover object-top border-2 border-[#0D47A1] mx-auto mb-2 bg-white">' :
          '<div class="w-14 h-14 rounded-full bg-blue-100 text-[#0D47A1] flex items-center justify-center mx-auto mb-2 font-bold text-sm">' + esc(initials) + '</div>') +
        '<div class="text-xs font-semibold leading-tight">' + esc(name) + '</div>' +
        (url ? '<button type="button" data-action="remove-profile" data-slot="' + esc(slot.key) + '" class="mt-2 inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-red-50 text-red-700 text-[11px] font-semibold"><i data-lucide="trash-2" class="w-3 h-3"></i><span data-dash-en="Remove" data-dash-mr="काढा">Remove</span></button>' : '') +
        '</div>';
    }).join('');

    var galleryList = document.getElementById('galleryAdminList');
    if (!gallery.length) {
      galleryList.innerHTML = '<div class="col-span-full text-sm text-slate-500">' + esc(msg('noGallery')) + '</div>';
      return;
    }
    galleryList.innerHTML = gallery.map(function (item) {
      var caption = lang === 'mr' ? (item.captionMr || item.captionEn || '') : (item.captionEn || item.captionMr || '');
      return '<div class="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-50">' +
        '<img src="' + esc(item.url) + '" alt="' + esc(caption) + '" class="w-full h-28 object-cover">' +
        '<div class="px-2 py-1.5 text-[11px] font-medium text-slate-700 truncate">' + esc(caption || '—') + '</div>' +
        '<button type="button" data-action="delete-gallery" data-id="' + item.id + '" title="' + esc(msg('delete')) + '" class="absolute top-1.5 right-1.5 p-1.5 rounded-lg bg-black/60 text-white"><i data-lucide="trash-2" class="w-3.5 h-3.5"></i></button></div>';
    }).join('');
  }

  function setTab(tab) {
    currentTab = tab;
    document.querySelectorAll('.tab-panel').forEach(function (panel) { panel.classList.add('hidden'); });
    var panel = document.getElementById('tab-' + tab);
    if (panel) panel.classList.remove('hidden');
    document.querySelectorAll('.tab-button').forEach(function (btn) {
      var active = btn.getAttribute('data-tab') === tab;
      btn.className = 'tab-button inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition ' +
        (active ? 'bg-[#0D47A1] text-white shadow-sm' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100');
    });
  }

  function refreshAll() {
    renderKpis();
    renderAttendees();
    renderUpdatesAdmin();
    renderOpinionsAdmin();
    renderVenue();
    renderGuestPhoto();
    renderAmbedkarPhoto();
    renderOrganiserPhotos();
    attachDynamicActions();
    applyDashTranslations();
    refreshIcons();
    setTab(currentTab);
  }

  function loadAdmin() {
    var loading = document.getElementById('dashboardLoading');
    loading.classList.remove('hidden');
    hideFeedback('adminError');
    return apiRequest({ action: 'admin' }, 'GET')
      .then(function (data) { admin = data; refreshAll(); })
      .catch(function (err) {
        if (err.status === 401) { showLogin(); return; }
        showFeedback('adminError', err.message);
      })
      .finally(function () { loading.classList.add('hidden'); });
  }

  function attachDynamicActions() {
    document.querySelectorAll('[data-action]').forEach(function (el) {
      if (el.getAttribute('data-bound') === '1') return;
      el.setAttribute('data-bound', '1');
      el.addEventListener('click', function () { handleAction(el); });
    });
  }

  function handleAction(el) {
    var action = el.getAttribute('data-action');
    var id = el.getAttribute('data-id');
    var params = { action: action };
    var method = 'DELETE';
    var body = null;

    if (action === 'delete-attendee') { params.action = 'attendee_delete'; params.id = id; }
    else if (action === 'delete-update') { params.action = 'update_delete'; params.id = id; }
    else if (action === 'toggle-pin') {
      params.action = 'update_patch'; params.id = id; method = 'PATCH';
      body = { isPinned: el.getAttribute('data-pinned') !== '1' };
    }
    else if (action === 'toggle-featured') {
      params.action = 'opinion_patch'; params.id = id; method = 'PATCH';
      body = { isFeatured: el.getAttribute('data-featured') !== '1' };
    }
    else if (action === 'toggle-visible') {
      params.action = 'opinion_patch'; params.id = id; method = 'PATCH';
      body = { isVisible: el.getAttribute('data-visible') !== '1' };
    }
    else if (action === 'delete-opinion') { params.action = 'opinion_delete'; params.id = id; }
    else if (action === 'remove-profile') { params.action = 'organiser_photo_delete'; params.slotKey = el.getAttribute('data-slot'); }
    else if (action === 'delete-gallery') { params.action = 'organiser_photo_delete'; params.id = id; }
    else return;

    apiRequest(params, method, body).then(function () {
      if (action === 'remove-profile' || action === 'delete-gallery') showFeedback('orgPhotoFeedback', msg('photoRemoved'));
      if (action === 'toggle-pin' || action === 'delete-update') showFeedback('updateFeedback', msg('saved'));
      return loadAdmin();
    }).catch(function (err) { showFeedback('adminError', err.message); });
  }

  function exportCsv() {
    var headers = ['ID', 'Full Name', 'City/Taluka', 'Status', 'Companions', 'Total Headcount', 'Notes', 'Registered At'];
    var rows = filteredAttendees.map(function (a) {
      return [
        'ELG-2026-' + String(a.id).padStart(4, '0'),
        a.fullName, a.city, a.status,
        String(a.companions || 0), String(1 + Number(a.companions || 0)),
        (a.notes || '').replace(/\r?\n/g, ' '),
        a.createdAt || ''
      ];
    });
    var csv = '\uFEFF' + [headers].concat(rows).map(function (row) {
      return row.map(function (cell) { return '"' + String(cell).replace(/"/g, '""') + '"'; }).join(',');
    }).join('\n');
    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = msg('csvName');
    a.click();
    URL.revokeObjectURL(url);
  }

  function handleFileInput(inputId, previewId, key, feedbackId) {
    var input = document.getElementById(inputId);
    if (!input) return;
    input.addEventListener('change', function () {
      var file = input.files && input.files[0];
      if (!file) return;
      compressImage(file).then(function (payload) {
        payloads[key] = payload;
        var preview = document.getElementById(previewId);
        if (!preview) return;
        if (preview.tagName === 'IMG') {
          preview.src = payload.base64;
          preview.classList.remove('hidden');
        } else if (previewId === 'ambedkarPhotoAdminPreview') {
          preview.innerHTML = '<img src="' + esc(payload.base64) + '" alt="Dr. B.R. Ambedkar preview" class="w-full h-auto object-cover block">';
          preview.className = 'rounded-2xl overflow-hidden border-4 border-amber-400/80 shadow-2xl max-w-[360px] w-full bg-slate-900';
        } else {
          preview.innerHTML = '<img src="' + esc(payload.base64) + '" alt="Preview" class="w-full h-full object-cover object-top">';
          preview.className = 'w-20 h-20 rounded-full border-2 border-amber-300 shadow-lg bg-white/10 overflow-hidden';
        }
      }).catch(function () { showFeedback(feedbackId, msg('choosePhoto')); });
    });
  }

  function clearImageState(key, previewId) {
    payloads[key] = null;
    var preview = document.getElementById(previewId);
    if (!preview) return;
    if (previewId === 'guestPhotoAdminPreview') {
      preview.textContent = 'PA';
      preview.className = 'w-20 h-20 rounded-full border-2 border-amber-300/60 bg-amber-400/20 flex items-center justify-center text-amber-200 font-extrabold text-xl';
    } else if (previewId === 'ambedkarPhotoAdminPreview') {
      preview.innerHTML = '<img src="images/ambedkar-original.jpg" alt="Dr. B.R. Ambedkar" class="w-full h-auto object-cover block">';
      preview.className = 'rounded-2xl overflow-hidden border-4 border-amber-400/80 shadow-2xl max-w-[360px] w-full bg-slate-900';
    } else {
      preview.src = '';
      preview.classList.add('hidden');
    }
  }

  function bindStaticEvents() {
    document.querySelectorAll('[data-dash-lang-btn]').forEach(function (btn) {
      btn.addEventListener('click', function () { setDashLang(btn.getAttribute('data-dash-lang-btn')); });
    });
    document.querySelectorAll('.tab-button').forEach(function (btn) {
      btn.addEventListener('click', function () { setTab(btn.getAttribute('data-tab')); });
    });

    document.getElementById('logoutBtn').addEventListener('click', function () {
      apiRequest({ action: 'logout' }, 'POST').catch(function () {}).finally(function () {
        admin = null; showLogin();
      });
    });

    document.getElementById('loginForm').addEventListener('submit', function (e) {
      e.preventDefault();
      hideFeedback('loginError');
      var btn = document.getElementById('loginSubmit');
      busy(btn, msg('verifying'));
      apiRequest({ action: 'login' }, 'POST', { passcode: document.getElementById('passcodeInput').value })
        .then(function () {
          document.getElementById('passcodeInput').value = '';
          showDashboard();
          return loadAdmin();
        })
        .catch(function (err) { showFeedback('loginError', err.message || msg('loginFailed')); })
        .finally(function () { unbusy(btn); });
    });

    document.getElementById('attendeeSearch').addEventListener('input', function () { renderAttendees(); attachDynamicActions(); applyDashTranslations(); refreshIcons(); });
    document.getElementById('attendeeStatusFilter').addEventListener('change', function () { renderAttendees(); attachDynamicActions(); applyDashTranslations(); refreshIcons(); });
    document.getElementById('exportCsv').addEventListener('click', exportCsv);

    handleFileInput('updateImage', 'updatePreview', 'update', 'updateFeedback');
    handleFileInput('guestPhotoInput', 'guestPhotoAdminPreview', 'guestPhoto', 'guestPhotoFeedback');
    handleFileInput('ambedkarPhotoInput', 'ambedkarPhotoAdminPreview', 'ambedkarPhoto', 'ambedkarPhotoFeedback');
    handleFileInput('profilePhotoInput', 'profilePhotoPreview', 'profilePhoto', 'orgPhotoFeedback');
    handleFileInput('galleryPhotoInput', 'galleryPhotoPreview', 'galleryPhoto', 'orgPhotoFeedback');

    document.getElementById('updateForm').addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = document.getElementById('updateSubmit');
      busy(btn, msg('publishing'));
      var body = {
        titleEn: document.getElementById('updateTitleEn').value,
        titleMr: document.getElementById('updateTitleMr').value,
        bodyEn: document.getElementById('updateBodyEn').value,
        bodyMr: document.getElementById('updateBodyMr').value,
        category: document.getElementById('updateCategory').value,
        authorName: document.getElementById('updateAuthor').value,
        isPinned: document.getElementById('updatePinned').checked
      };
      if (payloads.update) {
        body.imageBase64 = payloads.update.base64;
        body.imageMimeType = payloads.update.mimeType;
        body.imageFileName = payloads.update.fileName;
      }
      apiRequest({ action: 'update_post' }, 'POST', body).then(function () {
        document.getElementById('updateForm').reset();
        clearImageState('update', 'updatePreview');
        showFeedback('updateFeedback', msg('updatePublished'));
        return loadAdmin();
      }).catch(function (err) { showFeedback('updateFeedback', err.message); })
        .finally(function () { unbusy(btn); });
    });

    document.getElementById('venueForm').addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = document.getElementById('venueSubmit');
      busy(btn, msg('saving'));
      apiRequest({ action: 'venue' }, 'POST', {
        venueEn: document.getElementById('venueEn').value,
        venueMr: document.getElementById('venueMr').value,
        timeEn: document.getElementById('timeEn').value,
        timeMr: document.getElementById('timeMr').value
      }).then(function () {
        showFeedback('venueFeedback', msg('venueSaved'));
        return loadAdmin();
      }).catch(function (err) { showFeedback('venueFeedback', err.message); })
        .finally(function () { unbusy(btn); });
    });

    document.getElementById('guestPhotoForm').addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = document.getElementById('guestPhotoSubmit');
      var url = document.getElementById('guestPhotoUrlInput').value.trim();
      if (!payloads.guestPhoto && !url) { showFeedback('guestPhotoFeedback', msg('chooseImageOrUrl')); return; }
      busy(btn, msg('saving'));
      var body = {};
      if (payloads.guestPhoto) {
        body.imageBase64 = payloads.guestPhoto.base64;
        body.imageMimeType = payloads.guestPhoto.mimeType;
        body.imageFileName = payloads.guestPhoto.fileName;
      } else { body.imageUrl = url; }
      apiRequest({ action: 'guest_photo' }, 'POST', body).then(function () {
        document.getElementById('guestPhotoForm').reset();
        clearImageState('guestPhoto', 'guestPhotoAdminPreview');
        showFeedback('guestPhotoFeedback', msg('guestPhotoSaved'));
        return loadAdmin();
      }).catch(function (err) { showFeedback('guestPhotoFeedback', err.message); })
        .finally(function () { unbusy(btn); });
    });

    document.getElementById('guestPhotoRemove').addEventListener('click', function () {
      apiRequest({ action: 'guest_photo_delete' }, 'DELETE').then(function () {
        clearImageState('guestPhoto', 'guestPhotoAdminPreview');
        showFeedback('guestPhotoFeedback', msg('guestPhotoRemoved'));
        return loadAdmin();
      }).catch(function (err) { showFeedback('guestPhotoFeedback', err.message); });
    });

    document.getElementById('ambedkarPhotoForm').addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = document.getElementById('ambedkarPhotoSubmit');
      var url = document.getElementById('ambedkarPhotoUrlInput').value.trim();
      if (!payloads.ambedkarPhoto && !url) { showFeedback('ambedkarPhotoFeedback', msg('chooseImageOrUrl')); return; }
      busy(btn, msg('saving'));
      var body = {};
      if (payloads.ambedkarPhoto) {
        body.imageBase64 = payloads.ambedkarPhoto.base64;
        body.imageMimeType = payloads.ambedkarPhoto.mimeType;
        body.imageFileName = payloads.ambedkarPhoto.fileName;
      } else { body.imageUrl = url; }
      apiRequest({ action: 'ambedkar_photo' }, 'POST', body).then(function () {
        document.getElementById('ambedkarPhotoForm').reset();
        clearImageState('ambedkarPhoto', 'ambedkarPhotoAdminPreview');
        showFeedback('ambedkarPhotoFeedback', msg('ambedkarPhotoSaved'));
        return loadAdmin();
      }).catch(function (err) { showFeedback('ambedkarPhotoFeedback', err.message); })
        .finally(function () { unbusy(btn); });
    });

    document.getElementById('ambedkarPhotoRemove').addEventListener('click', function () {
      apiRequest({ action: 'ambedkar_photo_delete' }, 'DELETE').then(function () {
        clearImageState('ambedkarPhoto', 'ambedkarPhotoAdminPreview');
        showFeedback('ambedkarPhotoFeedback', msg('ambedkarPhotoRemoved'));
        return loadAdmin();
      }).catch(function (err) { showFeedback('ambedkarPhotoFeedback', err.message); });
    });

    document.getElementById('profilePhotoForm').addEventListener('submit', function (e) {
      e.preventDefault();
      if (!payloads.profilePhoto) { showFeedback('orgPhotoFeedback', msg('choosePhoto')); return; }
      var btn = document.getElementById('profilePhotoSubmit');
      busy(btn, msg('saving'));
      apiRequest({ action: 'organiser_photo' }, 'POST', {
        kind: 'profile',
        slotKey: document.getElementById('profileSlot').value,
        imageBase64: payloads.profilePhoto.base64,
        imageMimeType: payloads.profilePhoto.mimeType,
        imageFileName: payloads.profilePhoto.fileName
      }).then(function () {
        document.getElementById('profilePhotoForm').reset();
        clearImageState('profilePhoto', 'profilePhotoPreview');
        showFeedback('orgPhotoFeedback', msg('profileSaved'));
        return loadAdmin();
      }).catch(function (err) { showFeedback('orgPhotoFeedback', err.message); })
        .finally(function () { unbusy(btn); });
    });

    document.getElementById('galleryPhotoForm').addEventListener('submit', function (e) {
      e.preventDefault();
      if (!payloads.galleryPhoto) { showFeedback('orgPhotoFeedback', msg('choosePhoto')); return; }
      var btn = document.getElementById('galleryPhotoSubmit');
      busy(btn, msg('publishing'));
      apiRequest({ action: 'organiser_photo' }, 'POST', {
        kind: 'gallery',
        captionEn: document.getElementById('galleryCaptionEn').value,
        captionMr: document.getElementById('galleryCaptionMr').value,
        imageBase64: payloads.galleryPhoto.base64,
        imageMimeType: payloads.galleryPhoto.mimeType,
        imageFileName: payloads.galleryPhoto.fileName
      }).then(function () {
        document.getElementById('galleryPhotoForm').reset();
        clearImageState('galleryPhoto', 'galleryPhotoPreview');
        showFeedback('orgPhotoFeedback', msg('gallerySaved'));
        return loadAdmin();
      }).catch(function (err) { showFeedback('orgPhotoFeedback', err.message); })
        .finally(function () { unbusy(btn); });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    try { lang = localStorage.getItem('elgar_dash_lang') === 'mr' ? 'mr' : 'en'; } catch (e) {}
    bindStaticEvents();
    applyDashTranslations();
    apiRequest({ action: 'session' }, 'GET')
      .then(function (data) {
        if (data.authenticated) { showDashboard(); return loadAdmin(); }
        showLogin();
      })
      .catch(function () { showLogin(); });
  });
})();
