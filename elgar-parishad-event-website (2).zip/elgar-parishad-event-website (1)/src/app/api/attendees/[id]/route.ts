import { NextResponse } from "next/server";
import { db } from "@/db";
import { attendees } from "@/db/schema";
import { isOrganiserAuthenticated } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function DELETE(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  const authed = await isOrganiserAuthenticated(request);
  if (!authed) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await context.params;
  const numId = Number.parseInt(id, 10);
  if (!Number.isFinite(numId)) {
    return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
  }

  await db.delete(attendees).where(eq(attendees.id, numId));
  return NextResponse.json({ deleted: true });
}
