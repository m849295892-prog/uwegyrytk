import { NextResponse } from "next/server";
import { db } from "@/db";
import { attendees } from "@/db/schema";
import { isOrganiserAuthenticated } from "@/lib/auth";
import { getEventSummary } from "@/app/api/event-info/route";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const authed = await isOrganiserAuthenticated(request);
  if (!authed) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const list = await db
      .select()
      .from(attendees)
      .orderBy(desc(attendees.createdAt));

    const summary = await getEventSummary();

    return NextResponse.json({
      attendees: list,
      stats: summary.stats,
    });
  } catch (error) {
    console.error("GET /api/attendees error:", error);
    return NextResponse.json(
      { error: "Failed to fetch attendees" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const fullName =
      typeof body?.fullName === "string" ? body.fullName.trim() : "";
    const city = typeof body?.city === "string" ? body.city.trim() : "";
    const status = body?.status === "maybe" ? "maybe" : "attending";
    const companionsNum = Number.parseInt(String(body?.companions ?? "0"), 10);
    const companions =
      Number.isFinite(companionsNum) && companionsNum >= 0
        ? Math.min(companionsNum, 500)
        : 0;
    const notes =
      typeof body?.notes === "string" && body.notes.trim()
        ? body.notes.trim()
        : null;

    if (fullName.length < 2) {
      return NextResponse.json(
        { error: "Please enter your full name" },
        { status: 400 }
      );
    }
    if (city.length < 2) {
      return NextResponse.json(
        { error: "Please enter your city, taluka, or village" },
        { status: 400 }
      );
    }

    const [created] = await db
      .insert(attendees)
      .values({
        fullName,
        phone: null,
        city,
        organization: null,
        status,
        companions,
        notes,
      })
      .returning();

    const summary = await getEventSummary();

    return NextResponse.json(
      {
        registration: {
          id: created.id,
          referenceCode: `ELG-2026-${String(created.id).padStart(4, "0")}`,
          fullName: created.fullName,
          city: created.city,
          status: created.status,
          companions: created.companions,
        },
        stats: summary.stats,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("POST /api/attendees error:", error);
    return NextResponse.json(
      { error: "Could not save registration. Please try again." },
      { status: 500 }
    );
  }
}
