import { NextResponse } from "next/server";
import {
  createSessionToken,
  ORGANISER_COOKIE_NAME,
  verifyPasscode,
} from "@/lib/auth";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const passcode = typeof body?.passcode === "string" ? body.passcode : "";

    if (!verifyPasscode(passcode)) {
      return NextResponse.json(
        { error: "Invalid organiser passcode" },
        { status: 401 }
      );
    }

    const forwardedProto = request.headers.get("x-forwarded-proto");
    const isHttps =
      forwardedProto === "https" || request.url.startsWith("https://");

    const token = createSessionToken();
    const response = NextResponse.json({ authenticated: true, token });
    response.cookies.set(ORGANISER_COOKIE_NAME, token, {
      httpOnly: true,
      sameSite: isHttps ? "none" : "lax",
      secure: isHttps,
      path: "/",
      maxAge: 14 * 24 * 60 * 60,
    });
    return response;
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }
}
