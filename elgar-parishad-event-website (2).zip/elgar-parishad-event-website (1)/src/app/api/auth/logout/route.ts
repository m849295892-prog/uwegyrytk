import { NextResponse } from "next/server";
import { ORGANISER_COOKIE_NAME } from "@/lib/auth";

export async function POST(request: Request) {
  const forwardedProto = request.headers.get("x-forwarded-proto");
  const isHttps =
    forwardedProto === "https" || request.url.startsWith("https://");

  const response = NextResponse.json({ authenticated: false });
  response.cookies.set(ORGANISER_COOKIE_NAME, "", {
    httpOnly: true,
    sameSite: isHttps ? "none" : "lax",
    secure: isHttps,
    path: "/",
    maxAge: 0,
  });
  return response;
}
