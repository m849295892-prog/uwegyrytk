import { NextResponse } from "next/server";
import { isOrganiserAuthenticated } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const authenticated = await isOrganiserAuthenticated(request);
  return NextResponse.json({ authenticated });
}
