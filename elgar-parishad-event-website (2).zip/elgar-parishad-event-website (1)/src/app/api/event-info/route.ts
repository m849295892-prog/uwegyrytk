import { NextResponse } from "next/server";
import { db } from "@/db";
import { attendees, eventSettings } from "@/db/schema";
import { ensureSeedData } from "@/lib/seed";
import { isOrganiserAuthenticated } from "@/lib/auth";
import { eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function getEventSummary() {
  await ensureSeedData();
  const [settings] = await db.select().from(eventSettings).limit(1);

  const [stats] = await db
    .select({
      totalRegistrations: sql<number>`count(*)::int`,
      attendingRegistrations: sql<number>`count(*) filter (where ${attendees.status} = 'attending')::int`,
      maybeRegistrations: sql<number>`count(*) filter (where ${attendees.status} = 'maybe')::int`,
      confirmedHeadcount: sql<number>`coalesce(sum(case when ${attendees.status} = 'attending' then 1 + ${attendees.companions} else 0 end), 0)::int`,
      totalPotentialHeadcount: sql<number>`coalesce(sum(1 + ${attendees.companions}), 0)::int`,
    })
    .from(attendees);

  const guestPhotoUrl = settings?.guestPhotoId
    ? `/api/media/${settings.guestPhotoId}`
    : settings?.guestPhotoUrl ?? null;

  const ambedkarPhotoUrl = settings?.ambedkarPhotoId
    ? `/api/media/${settings.ambedkarPhotoId}`
    : settings?.ambedkarPhotoUrl ?? null;

  return {
    settings: settings ?? {
      id: 1,
      venueEn: "To be announced soon by the Organising Committee (Nashik)",
      venueMr: "आयोजन समितीमार्फत लवकरच जाहीर केले जाईल (नाशिक)",
      timeEn: "To be announced soon",
      timeMr: "लवकरच जाहीर केले जाईल",
      guestPhotoId: null,
      guestPhotoUrl: null,
      ambedkarPhotoId: null,
      ambedkarPhotoUrl: null,
      updatedAt: new Date(),
    },
    guestPhotoUrl,
    ambedkarPhotoUrl,
    stats: stats ?? {
      totalRegistrations: 0,
      attendingRegistrations: 0,
      maybeRegistrations: 0,
      confirmedHeadcount: 0,
      totalPotentialHeadcount: 0,
    },
  };
}

export async function GET() {
  try {
    const summary = await getEventSummary();
    return NextResponse.json(summary);
  } catch (error) {
    console.error("GET /api/event-info error:", error);
    return NextResponse.json(
      { error: "Failed to load event info" },
      { status: 500 }
    );
  }
}

export async function PATCH(request: Request) {
  const authed = await isOrganiserAuthenticated(request);
  if (!authed) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    await ensureSeedData();
    const body = await request.json();
    const venueEn =
      typeof body?.venueEn === "string" && body.venueEn.trim()
        ? body.venueEn.trim()
        : "To be announced soon by the Organising Committee (Nashik)";
    const venueMr =
      typeof body?.venueMr === "string" && body.venueMr.trim()
        ? body.venueMr.trim()
        : venueEn;
    const timeEn =
      typeof body?.timeEn === "string" && body.timeEn.trim()
        ? body.timeEn.trim()
        : "To be announced soon";
    const timeMr =
      typeof body?.timeMr === "string" && body.timeMr.trim()
        ? body.timeMr.trim()
        : timeEn;

    const [existing] = await db.select().from(eventSettings).limit(1);

    if (existing) {
      const [updated] = await db
        .update(eventSettings)
        .set({
          venueEn,
          venueMr,
          timeEn,
          timeMr,
          updatedAt: new Date(),
        })
        .where(eq(eventSettings.id, existing.id))
        .returning();
      return NextResponse.json({ settings: updated });
    } else {
      const [inserted] = await db
        .insert(eventSettings)
        .values({ venueEn, venueMr, timeEn, timeMr })
        .returning();
      return NextResponse.json({ settings: inserted });
    }
  } catch (error) {
    console.error("PATCH /api/event-info error:", error);
    return NextResponse.json(
      { error: "Failed to update event details" },
      { status: 500 }
    );
  }
}
