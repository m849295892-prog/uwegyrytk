import { NextResponse } from "next/server";
import { db } from "@/db";
import { eventSettings, mediaAssets } from "@/db/schema";
import { ensureSeedData } from "@/lib/seed";
import { isOrganiserAuthenticated } from "@/lib/auth";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

async function getSettingsRow() {
  await ensureSeedData();
  const [row] = await db.select().from(eventSettings).limit(1);
  return row;
}

export async function POST(request: Request) {
  const authed = await isOrganiserAuthenticated(request);
  if (!authed) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const current = await getSettingsRow();
    if (!current) {
      return NextResponse.json(
        { error: "Event settings not available" },
        { status: 500 }
      );
    }

    let newMediaId: number | null = null;
    let newPhotoUrl: string | null = null;

    if (typeof body?.imageBase64 === "string" && body.imageBase64.length > 0) {
      let rawBase64 = body.imageBase64;
      let mimeType =
        typeof body?.imageMimeType === "string" &&
        body.imageMimeType.startsWith("image/")
          ? body.imageMimeType
          : "image/jpeg";

      const match = rawBase64.match(
        /^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/
      );
      if (match) {
        mimeType = match[1];
        rawBase64 = match[2];
      }

      if (rawBase64.length > 4_200_000) {
        return NextResponse.json(
          { error: "Image is too large. Please upload an image under 3MB." },
          { status: 400 }
        );
      }

      const [saved] = await db
        .insert(mediaAssets)
        .values({
          mimeType,
          base64Data: rawBase64,
          fileName:
            typeof body?.imageFileName === "string"
              ? body.imageFileName.slice(0, 120)
              : "chief-guest.jpg",
        })
        .returning();
      newMediaId = saved.id;
    } else if (
      typeof body?.imageUrl === "string" &&
      body.imageUrl.trim()
    ) {
      const url = body.imageUrl.trim();
      if (
        !/^https?:\/\//i.test(url) &&
        !url.startsWith("/")
      ) {
        return NextResponse.json(
          { error: "Please provide a valid image URL" },
          { status: 400 }
        );
      }
      newPhotoUrl = url;
    } else {
      return NextResponse.json(
        { error: "Please choose a photo or provide an image URL" },
        { status: 400 }
      );
    }

    if (current.guestPhotoId) {
      await db
        .delete(mediaAssets)
        .where(eq(mediaAssets.id, current.guestPhotoId));
    }

    await db
      .update(eventSettings)
      .set({
        guestPhotoId: newMediaId,
        guestPhotoUrl: newPhotoUrl,
        updatedAt: new Date(),
      })
      .where(eq(eventSettings.id, current.id));

    return NextResponse.json({
      guestPhotoUrl: newMediaId
        ? `/api/media/${newMediaId}`
        : newPhotoUrl,
    });
  } catch (error) {
    console.error("POST /api/guest-photo error:", error);
    return NextResponse.json(
      { error: "Failed to save the Chief Guest photo" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  const authed = await isOrganiserAuthenticated(request);
  if (!authed) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const current = await getSettingsRow();
    if (!current) {
      return NextResponse.json({ guestPhotoUrl: null });
    }

    if (current.guestPhotoId) {
      await db
        .delete(mediaAssets)
        .where(eq(mediaAssets.id, current.guestPhotoId));
    }

    await db
      .update(eventSettings)
      .set({
        guestPhotoId: null,
        guestPhotoUrl: null,
        updatedAt: new Date(),
      })
      .where(eq(eventSettings.id, current.id));

    return NextResponse.json({ guestPhotoUrl: null });
  } catch (error) {
    console.error("DELETE /api/guest-photo error:", error);
    return NextResponse.json(
      { error: "Failed to remove the Chief Guest photo" },
      { status: 500 }
    );
  }
}
