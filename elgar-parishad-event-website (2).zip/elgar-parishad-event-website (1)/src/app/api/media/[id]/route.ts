import { NextResponse } from "next/server";
import { db } from "@/db";
import { mediaAssets } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;
  const numId = Number.parseInt(id, 10);
  if (!Number.isFinite(numId)) {
    return new NextResponse("Invalid media id", { status: 400 });
  }

  const [asset] = await db
    .select()
    .from(mediaAssets)
    .where(eq(mediaAssets.id, numId))
    .limit(1);

  if (!asset) {
    return new NextResponse("Not found", { status: 404 });
  }

  const buffer = Buffer.from(asset.base64Data, "base64");
  return new NextResponse(buffer, {
    status: 200,
    headers: {
      "Content-Type": asset.mimeType || "image/jpeg",
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  });
}
