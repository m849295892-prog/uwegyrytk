import { NextResponse } from "next/server";
import { db } from "@/db";
import { opinions } from "@/db/schema";
import { isOrganiserAuthenticated } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function PATCH(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  const authed = await isOrganiserAuthenticated(request);
  if (!authed) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await context.params;
  const numId = Number.parseInt(id, 10);
  if (!Number.isFinite(numId)) {
    return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
  }

  const body = await request.json();
  const updatesObj: Partial<{ isVisible: boolean; isFeatured: boolean }> = {};
  if (typeof body?.isVisible === "boolean") {
    updatesObj.isVisible = body.isVisible;
  }
  if (typeof body?.isFeatured === "boolean") {
    updatesObj.isFeatured = body.isFeatured;
  }

  const [updated] = await db
    .update(opinions)
    .set(updatesObj)
    .where(eq(opinions.id, numId))
    .returning();

  if (!updated) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  return NextResponse.json({ opinion: updated });
}

export async function DELETE(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  const authed = await isOrganiserAuthenticated(request);
  if (!authed) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await context.params;
  const numId = Number.parseInt(id, 10);
  if (!Number.isFinite(numId)) {
    return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
  }

  await db.delete(opinions).where(eq(opinions.id, numId));
  return NextResponse.json({ deleted: true });
}
