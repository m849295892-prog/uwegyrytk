import { NextResponse } from "next/server";
import { db } from "@/db";
import { opinions } from "@/db/schema";
import { ensureSeedData } from "@/lib/seed";
import { isOrganiserAuthenticated } from "@/lib/auth";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    await ensureSeedData();
    const url = new URL(request.url);
    const showAll = url.searchParams.get("all") === "1";

    if (showAll) {
      const authed = await isOrganiserAuthenticated(request);
      if (!authed) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
      }
      const list = await db
        .select()
        .from(opinions)
        .orderBy(desc(opinions.isFeatured), desc(opinions.createdAt));
      return NextResponse.json({ opinions: list });
    }

    const list = await db
      .select()
      .from(opinions)
      .where(eq(opinions.isVisible, true))
      .orderBy(desc(opinions.isFeatured), desc(opinions.createdAt));

    return NextResponse.json({ opinions: list });
  } catch (error) {
    console.error("GET /api/opinions error:", error);
    return NextResponse.json(
      { error: "Failed to load opinions" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const name = typeof body?.name === "string" ? body.name.trim() : "";
    const city = typeof body?.city === "string" ? body.city.trim() : "";
    const role =
      typeof body?.role === "string" && body.role.trim()
        ? body.role.trim()
        : null;
    const message =
      typeof body?.message === "string" ? body.message.trim() : "";

    if (name.length < 2) {
      return NextResponse.json(
        { error: "Please enter your name" },
        { status: 400 }
      );
    }
    if (city.length < 2) {
      return NextResponse.json(
        { error: "Please enter your city or district" },
        { status: 400 }
      );
    }
    if (message.length < 5) {
      return NextResponse.json(
        { error: "Please share your opinion or message (at least 5 characters)" },
        { status: 400 }
      );
    }

    const [created] = await db
      .insert(opinions)
      .values({
        name,
        city,
        role,
        message: message.slice(0, 1200),
        isVisible: true,
        isFeatured: false,
      })
      .returning();

    return NextResponse.json({ opinion: created }, { status: 201 });
  } catch (error) {
    console.error("POST /api/opinions error:", error);
    return NextResponse.json(
      { error: "Failed to submit opinion" },
      { status: 500 }
    );
  }
}
