import { NextResponse } from "next/server";
import { db } from "@/db";
import { mediaAssets, organiserPhotos } from "@/db/schema";
import { isOrganiserAuthenticated } from "@/lib/auth";
import {
  isOrganiserSlotKey,
  OrganiserPhotosDTO,
} from "@/lib/organiser-photos";
import { and, desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function getOrganiserPhotosPayload(): Promise<OrganiserPhotosDTO> {
  const rows = await db
    .select()
    .from(organiserPhotos)
    .orderBy(desc(organiserPhotos.createdAt));

  const profiles: Record<string, string> = {};
  const gallery: OrganiserPhotosDTO["gallery"] = [];

  for (const row of rows) {
    const url = row.mediaId
      ? `/api/media/${row.mediaId}`
      : row.imageUrl || null;
    if (!url) continue;

    if (row.kind === "profile" && row.slotKey) {
      if (!profiles[row.slotKey]) {
        profiles[row.slotKey] = url;
      }
    } else if (row.kind === "gallery") {
      gallery.push({
        id: row.id,
        url,
        captionEn: row.captionEn,
        captionMr: row.captionMr,
      });
    }
  }

  return { profiles, gallery };
}

export async function GET() {
  try {
    return NextResponse.json(await getOrganiserPhotosPayload());
  } catch (error) {
    console.error("GET /api/organiser-photos error:", error);
    return NextResponse.json(
      { error: "Failed to load organiser photos" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  const authed = await isOrganiserAuthenticated(request);
  if (!authed) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const kindValue = body?.kind === "profile" ? "profile" : "gallery";
    const slotKeyValue =
      typeof body?.slotKey === "string" ? body.slotKey.trim() : "";

    if (kindValue === "profile" && !isOrganiserSlotKey(slotKeyValue)) {
      return NextResponse.json(
        { error: "Please select a valid organiser" },
        { status: 400 }
      );
    }

    const captionEn =
      typeof body?.captionEn === "string" && body.captionEn.trim()
        ? body.captionEn.trim().slice(0, 200)
        : null;
    const captionMr =
      typeof body?.captionMr === "string" && body.captionMr.trim()
        ? body.captionMr.trim().slice(0, 200)
        : null;

    let newMediaId: number | null = null;
    let newImageUrl: string | null = null;

    if (typeof body?.imageBase64 === "string" && body.imageBase64.length > 0) {
      let rawBase64 = body.imageBase64;
      let mimeType =
        typeof body?.imageMimeType === "string" &&
        body.imageMimeType.startsWith("image/")
          ? body.imageMimeType
          : "image/jpeg";

      const match = rawBase64.match(
        /^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/
      );
      if (match) {
        mimeType = match[1];
        rawBase64 = match[2];
      }

      if (rawBase64.length > 4_200_000) {
        return NextResponse.json(
          { error: "Image is too large. Please upload an image under 3MB." },
          { status: 400 }
        );
      }

      const [saved] = await db
        .insert(mediaAssets)
        .values({
          mimeType,
          base64Data: rawBase64,
          fileName:
            typeof body?.imageFileName === "string"
              ? body.imageFileName.slice(0, 120)
              : "organiser-photo.jpg",
        })
        .returning();
      newMediaId = saved.id;
    } else if (typeof body?.imageUrl === "string" && body.imageUrl.trim()) {
      const url = body.imageUrl.trim();
      if (!/^https?:\/\//i.test(url) && !url.startsWith("/")) {
        return NextResponse.json(
          { error: "Please provide a valid image URL" },
          { status: 400 }
        );
      }
      newImageUrl = url;
    } else {
      return NextResponse.json(
        { error: "Please choose a photo or provide an image URL" },
        { status: 400 }
      );
    }

    if (kindValue === "profile") {
      const existing = await db
        .select()
        .from(organiserPhotos)
        .where(
          and(
            eq(organiserPhotos.kind, "profile"),
            eq(organiserPhotos.slotKey, slotKeyValue)
          )
        );

      for (const row of existing) {
        if (row.mediaId) {
          await db.delete(mediaAssets).where(eq(mediaAssets.id, row.mediaId));
        }
      }

      await db
        .delete(organiserPhotos)
        .where(
          and(
            eq(organiserPhotos.kind, "profile"),
            eq(organiserPhotos.slotKey, slotKeyValue)
          )
        );
    }

    await db.insert(organiserPhotos).values({
      kind: kindValue,
      slotKey: kindValue === "profile" ? slotKeyValue : null,
      mediaId: newMediaId,
      imageUrl: newImageUrl,
      captionEn: kindValue === "gallery" ? captionEn : null,
      captionMr: kindValue === "gallery" ? captionMr : null,
    });

    return NextResponse.json(await getOrganiserPhotosPayload(), {
      status: 201,
    });
  } catch (error) {
    console.error("POST /api/organiser-photos error:", error);
    return NextResponse.json(
      { error: "Failed to save organiser photo" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  const authed = await isOrganiserAuthenticated(request);
  if (!authed) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const url = new URL(request.url, "http://localhost");
    const slotKeyValue = url.searchParams.get("slotKey");
    const idValue = url.searchParams.get("id");

    let rowsToDelete: { id: number; mediaId: number | null }[] = [];

    if (slotKeyValue) {
      if (!isOrganiserSlotKey(slotKeyValue)) {
        return NextResponse.json(
          { error: "Invalid organiser" },
          { status: 400 }
        );
      }
      rowsToDelete = await db
        .select({
          id: organiserPhotos.id,
          mediaId: organiserPhotos.mediaId,
        })
        .from(organiserPhotos)
        .where(
          and(
            eq(organiserPhotos.kind, "profile"),
            eq(organiserPhotos.slotKey, slotKeyValue)
          )
        );
    } else if (idValue) {
      const numericId = Number.parseInt(idValue, 10);
      if (!Number.isFinite(numericId)) {
        return NextResponse.json({ error: "Invalid photo ID" }, { status: 400 });
      }
      rowsToDelete = await db
        .select({
          id: organiserPhotos.id,
          mediaId: organiserPhotos.mediaId,
        })
        .from(organiserPhotos)
        .where(eq(organiserPhotos.id, numericId));
    } else {
      return NextResponse.json(
        { error: "Please specify a photo to remove" },
        { status: 400 }
      );
    }

    for (const row of rowsToDelete) {
      if (row.mediaId) {
        await db.delete(mediaAssets).where(eq(mediaAssets.id, row.mediaId));
      }
      await db
        .delete(organiserPhotos)
        .where(eq(organiserPhotos.id, row.id));
    }

    return NextResponse.json(await getOrganiserPhotosPayload());
  } catch (error) {
    console.error("DELETE /api/organiser-photos error:", error);
    return NextResponse.json(
      { error: "Failed to remove organiser photo" },
      { status: 500 }
    );
  }
}
