import { NextResponse } from "next/server";
import { db } from "@/db";
import { mediaAssets, updates } from "@/db/schema";
import { isOrganiserAuthenticated } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function PATCH(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  const authed = await isOrganiserAuthenticated(request);
  if (!authed) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await context.params;
  const numId = Number.parseInt(id, 10);
  if (!Number.isFinite(numId)) {
    return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
  }

  const body = await request.json();
  const patchObj: Partial<{ isPinned: boolean }> = {};
  if (typeof body?.isPinned === "boolean") {
    patchObj.isPinned = body.isPinned;
  }

  const [updated] = await db
    .update(updates)
    .set(patchObj)
    .where(eq(updates.id, numId))
    .returning();

  if (!updated) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  return NextResponse.json({ update: updated });
}

export async function DELETE(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  const authed = await isOrganiserAuthenticated(request);
  if (!authed) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await context.params;
  const numId = Number.parseInt(id, 10);
  if (!Number.isFinite(numId)) {
    return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
  }

  const [existing] = await db
    .select()
    .from(updates)
    .where(eq(updates.id, numId))
    .limit(1);

  if (existing?.mediaId) {
    await db.delete(mediaAssets).where(eq(mediaAssets.id, existing.mediaId));
  }
  await db.delete(updates).where(eq(updates.id, numId));

  return NextResponse.json({ deleted: true });
}
