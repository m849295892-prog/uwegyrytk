import { NextResponse } from "next/server";
import { db } from "@/db";
import { mediaAssets, updates } from "@/db/schema";
import { ensureSeedData } from "@/lib/seed";
import { isOrganiserAuthenticated } from "@/lib/auth";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeedData();
    const list = await db
      .select()
      .from(updates)
      .orderBy(desc(updates.isPinned), desc(updates.createdAt));

    const formatted = list.map((item) => ({
      ...item,
      resolvedImageUrl: item.mediaId
        ? `/api/media/${item.mediaId}`
        : item.imageUrl || null,
    }));

    return NextResponse.json({ updates: formatted });
  } catch (error) {
    console.error("GET /api/updates error:", error);
    return NextResponse.json(
      { error: "Failed to load updates" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  const authed = await isOrganiserAuthenticated(request);
  if (!authed) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const titleEn =
      typeof body?.titleEn === "string" ? body.titleEn.trim() : "";
    const titleMr =
      typeof body?.titleMr === "string" && body.titleMr.trim()
        ? body.titleMr.trim()
        : null;
    const bodyEn = typeof body?.bodyEn === "string" ? body.bodyEn.trim() : "";
    const bodyMr =
      typeof body?.bodyMr === "string" && body.bodyMr.trim()
        ? body.bodyMr.trim()
        : null;

    const categoryRaw = typeof body?.category === "string" ? body.category : "announcement";
    const category = ["announcement", "venue", "photo", "press"].includes(categoryRaw)
      ? categoryRaw
      : "announcement";

    const authorName =
      typeof body?.authorName === "string" && body.authorName.trim()
        ? body.authorName.trim()
        : "Organising Committee";

    const isPinned = Boolean(body?.isPinned);
    const imageUrl =
      typeof body?.imageUrl === "string" && body.imageUrl.trim()
        ? body.imageUrl.trim()
        : null;

    if (!titleEn && !titleMr) {
      return NextResponse.json(
        { error: "Please provide a post title" },
        { status: 400 }
      );
    }
    if (!bodyEn && !bodyMr && !body?.imageBase64 && !imageUrl) {
      return NextResponse.json(
        { error: "Please provide post details or upload a photo" },
        { status: 400 }
      );
    }

    let mediaId: number | null = null;
    if (
      typeof body?.imageBase64 === "string" &&
      body.imageBase64.length > 0
    ) {
      // Strip optional data URI prefix if present
      let rawBase64 = body.imageBase64;
      let mimeType =
        typeof body?.imageMimeType === "string" &&
        body.imageMimeType.startsWith("image/")
          ? body.imageMimeType
          : "image/jpeg";

      const match = rawBase64.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
      if (match) {
        mimeType = match[1];
        rawBase64 = match[2];
      }

      // Guard max ~3MB base64 payload
      if (rawBase64.length > 4_200_000) {
        return NextResponse.json(
          { error: "Image is too large. Please upload an image under 3MB." },
          { status: 400 }
        );
      }

      const [savedMedia] = await db
        .insert(mediaAssets)
        .values({
          mimeType,
          base64Data: rawBase64,
          fileName:
            typeof body?.imageFileName === "string"
              ? body.imageFileName.slice(0, 120)
              : "upload.jpg",
        })
        .returning();
      mediaId = savedMedia.id;
    }

    const [created] = await db
      .insert(updates)
      .values({
        titleEn: titleEn || titleMr || "Official Update",
        titleMr: titleMr || titleEn || "अधिकृत माहिती",
        bodyEn: bodyEn || bodyMr || "",
        bodyMr: bodyMr || bodyEn || "",
        category,
        authorName,
        mediaId,
        imageUrl,
        isPinned,
      })
      .returning();

    return NextResponse.json(
      {
        update: {
          ...created,
          resolvedImageUrl: created.mediaId
            ? `/api/media/${created.mediaId}`
            : created.imageUrl || null,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("POST /api/updates error:", error);
    return NextResponse.json(
      { error: "Failed to publish update" },
      { status: 500 }
    );
  }
}
