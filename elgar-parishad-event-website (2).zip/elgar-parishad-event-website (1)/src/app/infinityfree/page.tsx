import React from "react";

export const metadata = {
  title: "InfinityFree Hosting Package | Elgar Parishad Nashik 2026",
  description:
    "Download the static HTML, PHP and MySQL version of the Elgar Parishad website for InfinityFree hosting.",
};

export default function InfinityFreePage() {
  return (
    <main className="min-h-screen bg-slate-50 text-[#0F172A]">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl p-7 sm:p-10 space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-[#0D47A1] text-xs font-bold uppercase tracking-wider">
            InfinityFree Compatible
          </div>

          <div className="space-y-2">
            <h1 className="text-3xl sm:text-4xl font-extrabold text-[#08245E]">
              Download the InfinityFree Package
            </h1>
            <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
              This is a self-contained static HTML + PHP + MySQL version of the Elgar Parishad website. It does not require Node.js, Next.js, PostgreSQL, npm, or SSH, so it runs on InfinityFree&apos;s normal free PHP hosting.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <a
              href="/downloads/infinityfree.zip"
              download
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-[#0D47A1] hover:bg-[#08245E] text-white font-bold text-sm shadow-lg transition"
            >
              Download ZIP Package
            </a>
            <a
              href="/infinityfree/README.md"
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-[#0F172A] font-semibold text-sm transition"
            >
              Read Setup Guide
            </a>
            <a
              href="/infinityfree/index.html"
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#08245E] font-bold text-sm transition"
            >
              Preview Static Site
            </a>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-2xl p-5 text-sm text-slate-700 space-y-2">
            <p className="font-bold text-[#08245E]">Quick setup</p>
            <ol className="list-decimal pl-5 space-y-1">
              <li>Create a MySQL database in your InfinityFree control panel.</li>
              <li>Edit <code className="font-mono">api/config.php</code> with your DB host, name, user, password, and organiser passcode.</li>
              <li>Upload the ZIP contents into <code className="font-mono">htdocs</code>.</li>
              <li>Visit <code className="font-mono">install.php</code> once, then delete it.</li>
              <li>Open <code className="font-mono">organiser.html</code> to manage registrations, opinions, updates, and photos.</li>
            </ol>
            <p className="mt-3 text-xs text-[#0D47A1] font-medium">
              Reliability tip: point a free uptime monitor at <code className="font-mono">/health.html</code> to avoid InfinityFree inactivity suspension. The organiser portal uses a normal first-party PHP session, so there is no Node.js process to go offline.
            </p>
          </div>

          <p className="text-xs text-slate-500">
            The main Next.js/PostgreSQL preview remains unchanged. This package is a separate deployable copy for InfinityFree.
          </p>

          <a href="/" className="inline-block text-sm font-semibold text-[#0D47A1] hover:underline">
            ← Back to main website
          </a>
        </div>
      </div>
    </main>
  );
}
