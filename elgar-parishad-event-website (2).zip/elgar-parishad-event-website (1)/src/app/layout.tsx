import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Elgar Parishad Nashik 2026 | Reservation in the Private Sector",
  description:
    "Elgar Parishad for Reservation in the Private Sector — Nashik, 12th December 2026. Chief Guest: Adv. Prakash Ambedkar. Register attendance, share your opinion, and view official updates.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="bg-[#FDFBF7] text-[#0F172A] antialiased font-sans selection:bg-[#0D47A1] selection:text-white">
        {children}
      </body>
    </html>
  );
}
