import React from "react";
import { isOrganiserAuthenticated } from "@/lib/auth";
import { OrganiserDashboardClient } from "@/components/OrganiserDashboardClient";

export const dynamic = "force-dynamic";

export default async function OrganiserPage() {
  const authenticated = await isOrganiserAuthenticated();
  return <OrganiserDashboardClient initialAuthenticated={authenticated} />;
}
