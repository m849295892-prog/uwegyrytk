import React from "react";
import { existsSync } from "node:fs";
import { join } from "node:path";
import { db } from "@/db";
import { opinions, updates } from "@/db/schema";
import { getEventSummary } from "@/app/api/event-info/route";
import { getOrganiserPhotosPayload } from "@/app/api/organiser-photos/route";
import { ensureSeedData } from "@/lib/seed";
import {
  STATIC_FALLBACK_OPINIONS,
  STATIC_FALLBACK_ORGANISER_PHOTOS,
  STATIC_FALLBACK_SETTINGS,
  STATIC_FALLBACK_UPDATES,
} from "@/lib/static-content";
import { desc, eq } from "drizzle-orm";
import { ElgarHomeClient } from "@/components/ElgarHomeClient";

// The public homepage is pre-rendered at build time (static HTML).
// All forms, uploads, and organiser tools continue to work through the
// existing dynamic API routes, so the site's appearance and features stay identical.
export const dynamic = "force-static";
export const revalidate = false;

function findSuppliedImage(names: string[]): string | null {
  for (const name of names) {
    if (existsSync(join(process.cwd(), "public", "images", name))) {
      return `/images/${name}`;
    }
  }
  return null;
}

function findSuppliedGuestPhoto(): string | null {
  return findSuppliedImage([
    "chief-guest.jpg",
    "chief-guest.jpeg",
    "chief-guest.png",
    "chief-guest.webp",
  ]);
}

function findSuppliedAmbedkarPhoto(): string | null {
  return findSuppliedImage([
    "ambedkar-original.jpg",
    "ambedkar-original.jpeg",
    "ambedkar-original.png",
    "ambedkar-original.webp",
  ]);
}

export default async function HomePage() {
  let settings = {
    ...STATIC_FALLBACK_SETTINGS,
    guestPhotoUrl: findSuppliedGuestPhoto(),
    ambedkarPhotoUrl: findSuppliedAmbedkarPhoto(),
  };
  let formattedUpdates = STATIC_FALLBACK_UPDATES;
  let formattedOpinions = STATIC_FALLBACK_OPINIONS;
  let organiserPhotos = STATIC_FALLBACK_ORGANISER_PHOTOS;

  // Build-time snapshot of current committee content. If the database is not
  // reachable during the build, the identical static fallback above is used.
  try {
    await ensureSeedData();
    const summary = await getEventSummary();

    settings = {
      id: summary.settings.id,
      venueEn: summary.settings.venueEn,
      venueMr: summary.settings.venueMr,
      timeEn: summary.settings.timeEn,
      timeMr: summary.settings.timeMr,
      guestPhotoUrl: summary.guestPhotoUrl ?? findSuppliedGuestPhoto(),
      ambedkarPhotoUrl:
        summary.ambedkarPhotoUrl ?? findSuppliedAmbedkarPhoto(),
    };

    organiserPhotos = await getOrganiserPhotosPayload();

    const updateRows = await db
      .select()
      .from(updates)
      .orderBy(desc(updates.isPinned), desc(updates.createdAt));
    formattedUpdates = updateRows.map((u) => ({
      id: u.id,
      titleEn: u.titleEn,
      titleMr: u.titleMr,
      bodyEn: u.bodyEn,
      bodyMr: u.bodyMr,
      category: u.category,
      authorName: u.authorName,
      resolvedImageUrl: u.mediaId
        ? `/api/media/${u.mediaId}`
        : u.imageUrl || null,
      isPinned: u.isPinned,
      createdAt: u.createdAt.toISOString(),
    }));

    const opinionRows = await db
      .select()
      .from(opinions)
      .where(eq(opinions.isVisible, true))
      .orderBy(desc(opinions.isFeatured), desc(opinions.createdAt));
    formattedOpinions = opinionRows.map((o) => ({
      id: o.id,
      name: o.name,
      city: o.city,
      role: o.role,
      message: o.message,
      isVisible: o.isVisible,
      isFeatured: o.isFeatured,
      createdAt: o.createdAt.toISOString(),
    }));
  } catch (error) {
    console.warn(
      "Static homepage build used fallback content (database unavailable):",
      error
    );
  }

  return (
    <ElgarHomeClient
      initialSettings={settings}
      initialOrganiserPhotos={organiserPhotos}
      initialUpdates={formattedUpdates}
      initialOpinions={formattedOpinions}
    />
  );
}
