import React from "react";

interface AshokaChakraProps {
  className?: string;
}

export function AshokaChakra({ className = "w-8 h-8" }: AshokaChakraProps) {
  const spokes = Array.from({ length: 24 }, (_, i) => i * 15);
  return (
    <svg
      viewBox="0 0 100 100"
      className={className}
      fill="none"
      aria-hidden="true"
    >
      <circle
        cx="50"
        cy="50"
        r="45"
        stroke="currentColor"
        strokeWidth="4.5"
      />
      <circle
        cx="50"
        cy="50"
        r="9"
        stroke="currentColor"
        strokeWidth="3.5"
      />
      <circle cx="50" cy="50" r="3.5" fill="currentColor" />
      {spokes.map((angle) => (
        <line
          key={angle}
          x1="50"
          y1="41"
          x2="50"
          y2="6"
          stroke="currentColor"
          strokeWidth="2.2"
          strokeLinecap="round"
          transform={`rotate(${angle} 50 50)`}
        />
      ))}
    </svg>
  );
}
