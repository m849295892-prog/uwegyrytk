"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import {
  Calendar,
  MapPin,
  Clock,
  Users,
  CheckCircle2,
  MessageSquarePlus,
  Megaphone,
  Award,
  Pin,
  Lock,
  Menu,
  X,
  Quote,
  Sparkles,
  Image as ImageIcon,
  Languages,
  UserCheck,
  Send,
} from "lucide-react";
import { AshokaChakra } from "./AshokaChakra";
import { Lang, TRANSLATIONS } from "@/lib/i18n";
import {
  ORGANISER_SLOTS,
  OrganiserPhotosDTO,
} from "@/lib/organiser-photos";

export interface EventSettingsDTO {
  id: number;
  venueEn: string;
  venueMr: string;
  timeEn: string;
  timeMr: string;
  guestPhotoUrl: string | null;
  ambedkarPhotoUrl: string | null;
}

export interface UpdateDTO {
  id: number;
  titleEn: string;
  titleMr: string | null;
  bodyEn: string;
  bodyMr: string | null;
  category: string;
  authorName: string;
  resolvedImageUrl: string | null;
  isPinned: boolean;
  createdAt: string;
}

export interface OpinionDTO {
  id: number;
  name: string;
  city: string;
  role: string | null;
  message: string;
  isVisible: boolean;
  isFeatured: boolean;
  createdAt: string;
}

interface ElgarHomeClientProps {
  initialSettings: EventSettingsDTO;
  initialOrganiserPhotos: OrganiserPhotosDTO;
  initialUpdates: UpdateDTO[];
  initialOpinions: OpinionDTO[];
}

export function ElgarHomeClient({
  initialSettings,
  initialOrganiserPhotos,
  initialUpdates,
  initialOpinions,
}: ElgarHomeClientProps) {
  const [lang, setLang] = useState<Lang>("en");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [settings, setSettings] = useState<EventSettingsDTO>(initialSettings);
  const [updates, setUpdates] = useState<UpdateDTO[]>(initialUpdates);
  const [opinions, setOpinions] = useState<OpinionDTO[]>(initialOpinions);
  const [organiserPhotos, setOrganiserPhotos] =
    useState<OrganiserPhotosDTO>(initialOrganiserPhotos);
  const [lightboxImage, setLightboxImage] = useState<{
    url: string;
    title: string;
  } | null>(null);

  // RSVP form state
  const [rsvpFullName, setRsvpFullName] = useState("");
  const [rsvpCity, setRsvpCity] = useState("");
  const [rsvpStatus, setRsvpStatus] = useState<"attending" | "maybe">(
    "attending"
  );
  const [rsvpCompanions, setRsvpCompanions] = useState("0");
  const [rsvpNotes, setRsvpNotes] = useState("");
  const [rsvpSubmitting, setRsvpSubmitting] = useState(false);
  const [rsvpError, setRsvpError] = useState<string | null>(null);
  const [rsvpSuccess, setRsvpSuccess] = useState<{
    referenceCode: string;
    fullName: string;
  } | null>(null);

  // Opinion form state
  const [opName, setOpName] = useState("");
  const [opCity, setOpCity] = useState("");
  const [opRole, setOpRole] = useState("");
  const [opMessage, setOpMessage] = useState("");
  const [opSubmitting, setOpSubmitting] = useState(false);
  const [opError, setOpError] = useState<string | null>(null);
  const [opSuccess, setOpSuccess] = useState(false);

  // Restore saved language preference
  useEffect(() => {
    try {
      const saved = window.localStorage.getItem("elgar_lang");
      if (saved === "mr" || saved === "en") {
        setLang(saved);
      }
    } catch {
      // ignore storage errors
    }
  }, []);

  // The public page is a static HTML snapshot. Refresh committee-managed
  // content from the existing API routes after hydration so every feature
  // (venue, updates, opinions, photos) stays live with no design change.
  useEffect(() => {
    let cancelled = false;

    const loadLiveContent = async () => {
      try {
        const [evRes, updRes, opRes, orgRes] = await Promise.all([
          fetch("/api/event-info", { cache: "no-store" }),
          fetch("/api/updates", { cache: "no-store" }),
          fetch("/api/opinions", { cache: "no-store" }),
          fetch("/api/organiser-photos", { cache: "no-store" }),
        ]);

        if (cancelled) return;

        if (evRes.ok) {
          const data = await evRes.json();
          if (data.settings) {
            setSettings((prev) => ({
              ...prev,
              venueEn: data.settings.venueEn || prev.venueEn,
              venueMr: data.settings.venueMr || prev.venueMr,
              timeEn: data.settings.timeEn || prev.timeEn,
              timeMr: data.settings.timeMr || prev.timeMr,
              guestPhotoUrl: data.guestPhotoUrl ?? prev.guestPhotoUrl,
              ambedkarPhotoUrl:
                data.ambedkarPhotoUrl ?? prev.ambedkarPhotoUrl,
            }));
          }
        }

        if (updRes.ok) {
          const data = await updRes.json();
          if (Array.isArray(data.updates)) setUpdates(data.updates);
        }

        if (opRes.ok) {
          const data = await opRes.json();
          if (Array.isArray(data.opinions)) setOpinions(data.opinions);
        }

        if (orgRes.ok) {
          const data = await orgRes.json();
          setOrganiserPhotos({
            profiles: data.profiles || {},
            gallery: Array.isArray(data.gallery) ? data.gallery : [],
          });
        }
      } catch {
        // Keep the static snapshot if the live API is unavailable.
      }
    };

    loadLiveContent();
    return () => {
      cancelled = true;
    };
  }, []);

  const handleSetLang = (next: Lang) => {
    setLang(next);
    try {
      window.localStorage.setItem("elgar_lang", next);
    } catch {
      // ignore
    }
  };

  const t = TRANSLATIONS[lang];

  const handleRsvpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRsvpError(null);
    setRsvpSubmitting(true);

    try {
      const res = await fetch("/api/attendees", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: rsvpFullName,
          city: rsvpCity,
          status: rsvpStatus,
          companions: Number.parseInt(rsvpCompanions, 10) || 0,
          notes: rsvpNotes,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setRsvpError(
          data.error ||
            (lang === "mr"
              ? "कृपया सर्व आवश्यक माहिती भरा."
              : "Please check your details and try again.")
        );
      } else {
        setRsvpSuccess({
          referenceCode: data.registration.referenceCode,
          fullName: data.registration.fullName,
        });
        setRsvpFullName("");
        setRsvpCity("");
        setRsvpCompanions("0");
        setRsvpNotes("");
      }
    } catch {
      setRsvpError(
        lang === "mr"
          ? "नेटवर्क त्रुटी. कृपया पुन्हा प्रयत्न करा."
          : "Network error. Please try again."
      );
    } finally {
      setRsvpSubmitting(false);
    }
  };

  const handleOpinionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setOpError(null);
    setOpSuccess(false);
    setOpSubmitting(true);

    try {
      const res = await fetch("/api/opinions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: opName,
          city: opCity,
          role: opRole,
          message: opMessage,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setOpError(
          data.error ||
            (lang === "mr"
              ? "कृपया आपले नाव, शहर आणि मत लिहा."
              : "Please complete all required fields.")
        );
      } else {
        setOpinions((prev) => [data.opinion, ...prev]);
        setOpSuccess(true);
        setOpName("");
        setOpCity("");
        setOpRole("");
        setOpMessage("");
      }
    } catch {
      setOpError(
        lang === "mr"
          ? "नेटवर्क त्रुटी. कृपया पुन्हा प्रयत्न करा."
          : "Network error. Please try again."
      );
    } finally {
      setOpSubmitting(false);
    }
  };

  const formatDate = (iso: string) => {
    try {
      return new Date(iso).toLocaleDateString(
        lang === "mr" ? "mr-IN" : "en-IN",
        {
          day: "numeric",
          month: "short",
          year: "numeric",
        }
      );
    } catch {
      return "";
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FDFBF7] text-[#0F172A]">
      {/* Sticky Top Navigation */}
      <header className="sticky top-0 z-40 bg-[#08245E]/95 backdrop-blur-md text-white border-b border-white/15 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
          {/* Brand */}
          <a href="#" className="flex items-center gap-2.5 shrink-0">
            <AshokaChakra className="w-9 h-9 text-amber-400 shrink-0" />
            <div className="leading-tight">
              <div className="font-bold text-sm sm:text-base tracking-wide text-white">
                {t.siteTitle}
              </div>
              <div className="text-[11px] text-blue-200 hidden sm:block">
                {t.siteTagline}
              </div>
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-5 text-sm font-medium text-blue-100">
            <a href="#ambedkar" className="hover:text-amber-300 transition">
              {t.nav.ambedkar}
            </a>
            <a href="#mission" className="hover:text-amber-300 transition">
              {t.nav.mission}
            </a>
            <a href="#organisers" className="hover:text-amber-300 transition">
              {t.nav.organisers}
            </a>
            <a href="#rsvp" className="hover:text-amber-300 transition">
              {t.nav.rsvp}
            </a>
            <a href="#updates" className="hover:text-amber-300 transition">
              {t.nav.updates}
            </a>
            <a href="#opinions" className="hover:text-amber-300 transition">
              {t.nav.opinions}
            </a>
          </nav>

          {/* Language Switcher + Organiser Portal */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Prominent EN / Marathi Switcher */}
            <div
              className="inline-flex items-center bg-[#04153B] border border-blue-400/40 rounded-full p-0.5 shadow-inner"
              role="group"
              aria-label="Language toggle"
            >
              <button
                type="button"
                onClick={() => handleSetLang("en")}
                className={`px-2.5 sm:px-3 py-1 rounded-full text-xs font-semibold transition cursor-pointer ${
                  lang === "en"
                    ? "bg-amber-400 text-[#08245E] shadow"
                    : "text-blue-100 hover:text-white"
                }`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => handleSetLang("mr")}
                className={`px-2.5 sm:px-3 py-1 rounded-full text-xs font-semibold transition cursor-pointer ${
                  lang === "mr"
                    ? "bg-amber-400 text-[#08245E] shadow"
                    : "text-blue-100 hover:text-white"
                }`}
              >
                मराठी
              </button>
            </div>

            <Link
              href="/organiser"
              className="hidden sm:inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 border border-white/20 text-white transition"
            >
              <Lock className="w-3.5 h-3.5 text-amber-300" />
              {t.nav.portal}
            </Link>

            <button
              type="button"
              onClick={() => setMobileMenuOpen((v) => !v)}
              className="lg:hidden p-2 rounded-lg text-blue-100 hover:bg-white/10"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#061C49] border-t border-white/10 px-4 py-4 space-y-2 text-sm">
            {[
              { href: "#ambedkar", label: t.nav.ambedkar },
              { href: "#mission", label: t.nav.mission },
              { href: "#organisers", label: t.nav.organisers },
              { href: "#rsvp", label: t.nav.rsvp },
              { href: "#updates", label: t.nav.updates },
              { href: "#opinions", label: t.nav.opinions },
            ].map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className="block py-2 px-3 rounded-lg text-blue-100 hover:bg-white/10 hover:text-amber-300 font-medium"
              >
                {item.label}
              </a>
            ))}
            <Link
              href="/organiser"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 py-2 px-3 rounded-lg bg-amber-400/15 text-amber-300 font-semibold"
            >
              <Lock className="w-4 h-4" />
              {t.nav.portal}
            </Link>
          </div>
        )}
      </header>

      {/* HERO SECTION */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#061B47] via-[#0D47A1] to-[#0A2E7A] text-white">
        {/* Watermark Ashoka Chakra */}
        <div className="pointer-events-none absolute -right-24 -top-24 opacity-[0.07]">
          <AshokaChakra className="w-[460px] h-[460px] text-white" />
        </div>
        <div className="pointer-events-none absolute -left-24 bottom-0 opacity-[0.05]">
          <AshokaChakra className="w-[320px] h-[320px] text-amber-300" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-12 sm:py-16 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            {/* Hero Left */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-400/15 border border-amber-300/40 text-amber-200 text-xs sm:text-sm font-semibold">
                <AshokaChakra className="w-4 h-4 text-amber-300" />
                <span>{t.hero.badge}</span>
              </div>

              <div className="space-y-2">
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
                  {t.hero.title}
                </h1>
                <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-amber-300">
                  {t.hero.subtitle}
                </p>
              </div>

              <p className="text-blue-100 text-base sm:text-lg leading-relaxed max-w-2xl">
                {t.hero.description}
              </p>

              {/* CTA Buttons + Quick Language Toggle Reminder */}
              <div className="flex flex-wrap items-center gap-3 pt-1">
                <a
                  href="#rsvp"
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#08245E] font-bold text-sm sm:text-base shadow-lg shadow-amber-950/30 transition"
                >
                  <UserCheck className="w-5 h-5" />
                  {t.hero.ctaAttend}
                </a>
                <a
                  href="#opinions"
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/25 text-white font-semibold text-sm sm:text-base transition"
                >
                  <MessageSquarePlus className="w-5 h-5 text-amber-300" />
                  {t.hero.ctaOpinion}
                </a>
                <button
                  type="button"
                  onClick={() => handleSetLang(lang === "en" ? "mr" : "en")}
                  className="inline-flex items-center gap-1.5 px-4 py-3.5 rounded-xl bg-[#04153B]/70 hover:bg-[#04153B] border border-blue-300/30 text-blue-100 text-xs sm:text-sm font-medium transition cursor-pointer"
                >
                  <Languages className="w-4 h-4 text-amber-300" />
                  {lang === "en" ? "मराठीत वाचा" : "Read in English"}
                </button>
              </div>
            </div>

            {/* Hero Right: Event Details Card */}
            <div className="lg:col-span-5">
              <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6 sm:p-7 shadow-2xl space-y-5">
                {/* Chief Guest Highlight with Organiser-Provided Photo */}
                <div className="p-4 rounded-xl bg-gradient-to-r from-amber-400/20 to-amber-500/10 border border-amber-300/40">
                  <div className="flex items-center gap-3.5">
                    {settings.guestPhotoUrl ? (
                      <img
                        src={settings.guestPhotoUrl}
                        alt={t.hero.chiefGuestName}
                        className="w-16 h-16 sm:w-20 sm:h-20 rounded-full object-cover object-top border-2 border-amber-300 shadow-lg bg-white/10 shrink-0"
                      />
                    ) : (
                      <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-amber-400/20 border-2 border-amber-300/60 flex items-center justify-center text-amber-200 font-extrabold text-lg sm:text-xl shrink-0 shadow-inner">
                        PA
                      </div>
                    )}
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 text-[10px] sm:text-xs font-bold uppercase tracking-wider text-amber-300 mb-1">
                        <Award className="w-3.5 h-3.5" />
                        {t.hero.chiefGuestLabel}
                      </div>
                      <div className="text-lg sm:text-2xl font-extrabold text-white leading-tight">
                        {t.hero.chiefGuestName}
                      </div>
                      <div className="text-xs sm:text-sm text-amber-100/90 mt-0.5">
                        {t.hero.chiefGuestRole}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Date & City */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div className="p-3.5 rounded-xl bg-[#061B47]/60 border border-white/15">
                    <div className="flex items-center gap-1.5 text-xs text-blue-200 font-medium mb-1">
                      <Calendar className="w-3.5 h-3.5 text-amber-300" />
                      {t.hero.dateLabel}
                    </div>
                    <div className="font-bold text-white text-base">
                      {t.hero.dateValue}
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-[#061B47]/60 border border-white/15">
                    <div className="flex items-center gap-1.5 text-xs text-blue-200 font-medium mb-1">
                      <MapPin className="w-3.5 h-3.5 text-amber-300" />
                      {t.hero.cityLabel}
                    </div>
                    <div className="font-bold text-white text-base">
                      {t.hero.cityValue}
                    </div>
                  </div>
                </div>

                {/* Venue & Time (Dynamic from DB, defaults to "announced soon") */}
                <div className="p-4 rounded-xl bg-[#061B47]/70 border border-blue-300/20 space-y-2.5 text-sm">
                  <div className="flex items-start gap-2.5">
                    <MapPin className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
                    <div>
                      <span className="text-blue-200 font-medium">
                        {t.hero.venueLabel}:{" "}
                      </span>
                      <span className="text-white font-semibold">
                        {lang === "mr" ? settings.venueMr : settings.venueEn}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <Clock className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
                    <div>
                      <span className="text-blue-200 font-medium">
                        {t.hero.timeLabel}:{" "}
                      </span>
                      <span className="text-white font-semibold">
                        {lang === "mr" ? settings.timeMr : settings.timeEn}
                      </span>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      </section>

      {/* DR. B.R. AMBEDKAR ORIGINAL PHOTO & QUOTE SECTION */}
      <section id="ambedkar" className="py-14 sm:py-16 bg-[#FDFBF7]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="bg-white rounded-3xl border border-amber-200/80 shadow-xl overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-12">
              {/* Dr. Ambedkar Photo — large and organiser-changeable */}
              <div className="md:col-span-6 bg-gradient-to-b from-[#0A2E7A] to-[#061B47] p-6 sm:p-8 flex flex-col items-center justify-center text-center">
                <div className="relative rounded-2xl overflow-hidden border-4 border-amber-400/80 shadow-2xl max-w-[420px] w-full bg-slate-900">
                  <img
                    src={
                      settings.ambedkarPhotoUrl ||
                      "/images/ambedkar-original.jpg"
                    }
                    alt="Original archival portrait of Dr. B.R. Ambedkar"
                    className="w-full h-auto object-cover block"
                  />
                </div>
                <p className="mt-4 text-xs text-amber-200/90 font-medium">
                  {t.ambedkar.photoCaption}
                </p>
              </div>

              {/* Quote & Constitutional Message */}
              <div className="md:col-span-6 p-7 sm:p-10 lg:p-12 flex flex-col justify-center space-y-5">
                <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0D47A1]">
                  <AshokaChakra className="w-4 h-4 text-[#0D47A1]" />
                  {t.ambedkar.eyebrow}
                </div>

                <div>
                  <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0F172A]">
                    {t.ambedkar.name}
                  </h2>
                  <p className="text-sm text-slate-600 font-medium mt-0.5">
                    {t.ambedkar.years}
                  </p>
                </div>

                <blockquote className="relative pl-5 border-l-4 border-amber-500 py-1">
                  <Quote className="w-6 h-6 text-amber-500/40 mb-1" />
                  <p className="font-serif text-lg sm:text-xl font-bold text-[#08245E] leading-relaxed">
                    “{t.ambedkar.quote}”
                  </p>
                </blockquote>

                <p className="text-sm sm:text-base italic text-slate-700 bg-blue-50/80 border border-blue-100 rounded-xl px-4 py-3">
                  “{t.ambedkar.secondaryQuote}”
                </p>

                <p className="text-sm sm:text-base text-slate-700 leading-relaxed">
                  {t.ambedkar.contextNote}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* WHY RESERVATION IN PRIVATE SECTOR */}
      <section id="mission" className="py-12 sm:py-16 bg-slate-50 border-y border-slate-200/70">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-3xl mx-auto mb-10 space-y-2">
            <div className="text-xs font-bold uppercase tracking-wider text-[#0D47A1]">
              {t.mission.eyebrow}
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0F172A]">
              {t.mission.heading}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {t.mission.points.map((point, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition flex flex-col gap-3"
              >
                <div className="w-10 h-10 rounded-xl bg-[#0D47A1]/10 text-[#0D47A1] flex items-center justify-center font-extrabold text-lg">
                  {idx + 1}
                </div>
                <h3 className="text-lg font-bold text-[#0F172A]">
                  {point.title}
                </h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  {point.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ORGANISING COMMITTEE HIERARCHY */}
      <section id="organisers" className="py-14 sm:py-18 bg-[#FDFBF7]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#0D47A1]">
              <AshokaChakra className="w-4 h-4" />
              {t.organisers.eyebrow}
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0F172A]">
              {t.organisers.heading}
            </h2>
            <p className="text-slate-600 text-sm sm:text-base">
              {t.organisers.subtitle}
            </p>
          </div>

          {/* TOP ROW: 3 Organisers */}
          <div className="mb-8">
            <div className="text-center mb-4">
              <span className="inline-block px-4 py-1 rounded-full bg-[#0D47A1] text-white text-xs font-bold uppercase tracking-wider shadow-sm">
                {t.organisers.topTierBadge}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {t.organisers.topRow.map((person, idx) => {
                const photoUrl =
                  organiserPhotos.profiles[ORGANISER_SLOTS[idx].key];
                return (
                  <div
                    key={person.name}
                    className="bg-gradient-to-b from-white to-blue-50/50 rounded-2xl p-6 border-2 border-[#0D47A1]/25 shadow-md text-center flex flex-col items-center relative overflow-hidden"
                  >
                    <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-[#0D47A1] via-amber-400 to-[#0D47A1]" />
                    {photoUrl ? (
                      <img
                        src={photoUrl}
                        alt={person.name}
                        className="w-16 h-16 rounded-full object-cover object-top border-2 border-[#0D47A1] shadow mb-3 bg-white"
                      />
                    ) : (
                      <div className="w-14 h-14 rounded-full bg-[#0D47A1] text-amber-300 flex items-center justify-center mb-3 shadow">
                        <AshokaChakra className="w-8 h-8" />
                      </div>
                    )}
                    <h3 className="text-xl font-extrabold text-[#08245E]">
                      {person.name}
                    </h3>
                    <span className="mt-1.5 inline-block px-3 py-0.5 rounded-full bg-amber-100 text-amber-900 text-xs font-bold">
                      {person.role}
                    </span>
                    <p className="mt-2 text-xs text-slate-600">
                      {person.subtitle}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* SECOND ROW (BELOW THE TOP 3): 2 Organisers */}
          <div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-3xl mx-auto">
              {t.organisers.bottomRow.map((person, idx) => {
                const photoUrl =
                  organiserPhotos.profiles[ORGANISER_SLOTS[idx + 3].key];
                return (
                  <div
                    key={person.name}
                    className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm text-center flex flex-col items-center relative overflow-hidden"
                  >
                    <div className="absolute top-0 inset-x-0 h-1 bg-[#0D47A1]/60" />
                    {photoUrl ? (
                      <img
                        src={photoUrl}
                        alt={person.name}
                        className="w-14 h-14 rounded-full object-cover object-top border-2 border-blue-200 shadow mb-3 bg-white"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-full bg-blue-100 text-[#0D47A1] flex items-center justify-center mb-3">
                        <Users className="w-6 h-6" />
                      </div>
                    )}
                    <h3 className="text-lg font-bold text-[#0F172A]">
                      {person.name}
                    </h3>
                    <span className="mt-1 inline-block px-3 py-0.5 rounded-full bg-blue-50 text-[#0D47A1] text-xs font-semibold">
                      {person.role}
                    </span>
                    <p className="mt-2 text-xs text-slate-600">
                      {person.subtitle}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Venue & Time Notice */}
          <div className="mt-8 max-w-3xl mx-auto bg-amber-50 border border-amber-200 rounded-2xl px-5 py-4 flex items-center gap-3 text-sm text-amber-950">
            <Megaphone className="w-5 h-5 text-amber-700 shrink-0" />
            <span className="font-medium">{t.organisers.venueNotice}</span>
          </div>

          {/* Organising Committee Photo Gallery */}
          <div className="mt-12">
            <div className="text-center max-w-2xl mx-auto mb-6 space-y-1.5">
              <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#0D47A1]">
                <ImageIcon className="w-4 h-4" />
                {t.organisers.galleryTitle}
              </div>
              <p className="text-sm text-slate-600">
                {t.organisers.gallerySubtitle}
              </p>
            </div>

            {organiserPhotos.gallery.length === 0 ? (
              <div className="max-w-2xl mx-auto bg-white border border-dashed border-slate-300 rounded-2xl p-8 text-center text-sm text-slate-500">
                {t.organisers.galleryEmpty}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {organiserPhotos.gallery.map((item) => {
                  const caption =
                    lang === "mr"
                      ? item.captionMr || item.captionEn || t.organisers.galleryTitle
                      : item.captionEn || item.captionMr || t.organisers.galleryTitle;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() =>
                        setLightboxImage({ url: item.url, title: caption })
                      }
                      className="group bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden text-left hover:shadow-md transition cursor-pointer"
                    >
                      <img
                        src={item.url}
                        alt={caption}
                        className="w-full h-52 object-cover bg-slate-100 group-hover:scale-105 transition duration-300"
                      />
                      <div className="px-4 py-3 text-sm font-semibold text-[#0F172A]">
                        {caption}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ATTENDANCE / RSVP REGISTRATION SECTION */}
      <section
        id="rsvp"
        className="py-14 sm:py-18 bg-gradient-to-b from-[#08245E] to-[#0D47A1] text-white"
      >
        <div className="max-w-5xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
            <div className="text-xs font-bold uppercase tracking-wider text-amber-300">
              {t.rsvp.eyebrow}
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
              {t.rsvp.heading}
            </h2>
            <p className="text-blue-100 text-sm sm:text-base">
              {t.rsvp.subtitle}
            </p>
          </div>

          <div className="bg-white text-[#0F172A] rounded-3xl p-6 sm:p-9 shadow-2xl border border-white/20">
            {rsvpSuccess ? (
              <div className="text-center py-8 space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-9 h-9" />
                </div>
                <h3 className="text-2xl font-extrabold text-[#0F172A]">
                  {t.rsvp.successTitle}
                </h3>
                <p className="text-slate-600 max-w-md mx-auto text-sm sm:text-base">
                  {t.rsvp.successDesc}
                </p>
                <div className="inline-block bg-blue-50 border border-blue-200 rounded-xl px-5 py-3">
                  <div className="text-xs text-slate-500 uppercase tracking-wider font-semibold">
                    {t.rsvp.refLabel}
                  </div>
                  <div className="text-lg font-extrabold text-[#0D47A1] tracking-wide">
                    {rsvpSuccess.referenceCode} • {rsvpSuccess.fullName}
                  </div>
                </div>
                <div>
                  <button
                    type="button"
                    onClick={() => setRsvpSuccess(null)}
                    className="mt-2 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#0D47A1] hover:bg-[#08245E] text-white font-semibold text-sm transition cursor-pointer"
                  >
                    {t.rsvp.registerAnother}
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleRsvpSubmit} className="space-y-5">
                {rsvpError && (
                  <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm font-medium">
                    {rsvpError}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-semibold text-slate-800 mb-1.5">
                      {t.rsvp.fullName} *
                    </label>
                    <input
                      type="text"
                      required
                      value={rsvpFullName}
                      onChange={(e) => setRsvpFullName(e.target.value)}
                      placeholder={t.rsvp.fullNamePlaceholder}
                      className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0D47A1] focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-800 mb-1.5">
                      {t.rsvp.city} *
                    </label>
                    <input
                      type="text"
                      required
                      value={rsvpCity}
                      onChange={(e) => setRsvpCity(e.target.value)}
                      placeholder={t.rsvp.cityPlaceholder}
                      className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0D47A1] focus:border-transparent"
                    />
                  </div>
                </div>

                {/* Attendance Choice */}
                <div>
                  <label className="block text-sm font-semibold text-slate-800 mb-2">
                    {t.rsvp.attendanceChoice} *
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setRsvpStatus("attending")}
                      className={`p-3.5 rounded-xl border-2 text-left text-sm font-semibold flex items-center gap-2.5 transition cursor-pointer ${
                        rsvpStatus === "attending"
                          ? "border-[#0D47A1] bg-blue-50 text-[#08245E]"
                          : "border-slate-200 hover:border-slate-300 text-slate-700"
                      }`}
                    >
                      <CheckCircle2
                        className={`w-5 h-5 shrink-0 ${
                          rsvpStatus === "attending"
                            ? "text-[#0D47A1]"
                            : "text-slate-400"
                        }`}
                      />
                      <span>{t.rsvp.attendingYes}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setRsvpStatus("maybe")}
                      className={`p-3.5 rounded-xl border-2 text-left text-sm font-semibold flex items-center gap-2.5 transition cursor-pointer ${
                        rsvpStatus === "maybe"
                          ? "border-amber-500 bg-amber-50 text-amber-950"
                          : "border-slate-200 hover:border-slate-300 text-slate-700"
                      }`}
                    >
                      <Clock
                        className={`w-5 h-5 shrink-0 ${
                          rsvpStatus === "maybe"
                            ? "text-amber-600"
                            : "text-slate-400"
                        }`}
                      />
                      <span>{t.rsvp.attendingMaybe}</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-semibold text-slate-800 mb-1.5">
                      {t.rsvp.companions}
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={500}
                      value={rsvpCompanions}
                      onChange={(e) => setRsvpCompanions(e.target.value)}
                      className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0D47A1]"
                    />
                    <p className="text-xs text-slate-500 mt-1">
                      {t.rsvp.companionsHelp}
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-800 mb-1.5">
                      {t.rsvp.notes}
                    </label>
                    <input
                      type="text"
                      value={rsvpNotes}
                      onChange={(e) => setRsvpNotes(e.target.value)}
                      placeholder={t.rsvp.notesPlaceholder}
                      className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0D47A1]"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={rsvpSubmitting}
                  className="w-full py-3.5 px-6 rounded-xl bg-[#0D47A1] hover:bg-[#08245E] disabled:opacity-60 text-white font-bold text-base shadow-lg transition cursor-pointer"
                >
                  {rsvpSubmitting ? t.rsvp.submitting : t.rsvp.submitBtn}
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* OFFICIAL UPDATES & PHOTO GALLERY */}
      <section id="updates" className="py-14 sm:py-18 bg-[#FDFBF7]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div className="space-y-2 max-w-2xl">
              <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#0D47A1]">
                <Megaphone className="w-4 h-4" />
                {t.updates.eyebrow}
              </div>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0F172A]">
                {t.updates.heading}
              </h2>
              <p className="text-slate-600 text-sm sm:text-base">
                {t.updates.subtitle}
              </p>
            </div>

            <Link
              href="/organiser"
              className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#0D47A1] hover:text-[#08245E] bg-blue-50 hover:bg-blue-100 border border-blue-200 px-4 py-2.5 rounded-xl transition shrink-0"
            >
              <ImageIcon className="w-4 h-4" />
              {lang === "mr"
                ? "आयोजक आहात? अपडेट किंवा फोटो पोस्ट करा →"
                : "Organiser? Post Update or Photo →"}
            </Link>
          </div>

          {updates.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center text-slate-500">
              {t.updates.noUpdates}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {updates.map((post) => {
                const title =
                  lang === "mr" && post.titleMr ? post.titleMr : post.titleEn;
                const body =
                  lang === "mr" && post.bodyMr ? post.bodyMr : post.bodyEn;
                const catLabel =
                  t.updates.categories[
                    post.category as keyof typeof t.updates.categories
                  ] || t.updates.categories.announcement;

                return (
                  <article
                    key={post.id}
                    className={`bg-white rounded-2xl border shadow-sm overflow-hidden flex flex-col transition hover:shadow-md ${
                      post.isPinned
                        ? "border-amber-400 ring-1 ring-amber-300/60"
                        : "border-slate-200"
                    }`}
                  >
                    {post.resolvedImageUrl && (
                      <button
                        type="button"
                        onClick={() =>
                          setLightboxImage({
                            url: post.resolvedImageUrl!,
                            title,
                          })
                        }
                        className="relative h-52 w-full bg-slate-100 overflow-hidden group cursor-pointer"
                      >
                        <img
                          src={post.resolvedImageUrl}
                          alt={title}
                          className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                        />
                      </button>
                    )}

                    <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                      <div className="space-y-3">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wide bg-blue-50 text-[#0D47A1] border border-blue-100">
                            {catLabel}
                          </span>
                          {post.isPinned && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900">
                              <Pin className="w-3 h-3" />
                              {t.updates.pinnedBadge}
                            </span>
                          )}
                        </div>

                        <h3 className="text-lg font-bold text-[#0F172A] leading-snug">
                          {title}
                        </h3>

                        {body && (
                          <p className="text-sm text-slate-600 leading-relaxed whitespace-pre-line">
                            {body}
                          </p>
                        )}
                      </div>

                      <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                        <span className="truncate max-w-[65%]">
                          {t.updates.postedBy} {post.authorName}
                        </span>
                        <span>{formatDate(post.createdAt)}</span>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* PUBLIC OPINION / VOICES SECTION */}
      <section
        id="opinions"
        className="py-14 sm:py-18 bg-slate-50 border-t border-slate-200"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#0D47A1]">
              <MessageSquarePlus className="w-4 h-4" />
              {t.opinions.eyebrow}
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0F172A]">
              {t.opinions.heading}
            </h2>
            <p className="text-slate-600 text-sm sm:text-base">
              {t.opinions.subtitle}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Submit Opinion Form */}
            <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm">
              <h3 className="text-xl font-bold text-[#0F172A] mb-4 flex items-center gap-2">
                <Send className="w-5 h-5 text-[#0D47A1]" />
                {t.opinions.formTitle}
              </h3>

              <form onSubmit={handleOpinionSubmit} className="space-y-4">
                {opError && (
                  <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm">
                    {opError}
                  </div>
                )}
                {opSuccess && (
                  <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-medium">
                    {t.opinions.successMsg}
                  </div>
                )}

                <div>
                  <label className="block text-sm font-semibold text-slate-800 mb-1">
                    {t.opinions.nameLabel} *
                  </label>
                  <input
                    type="text"
                    required
                    value={opName}
                    onChange={(e) => setOpName(e.target.value)}
                    placeholder={t.opinions.namePlaceholder}
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0D47A1]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-semibold text-slate-800 mb-1">
                      {t.opinions.cityLabel} *
                    </label>
                    <input
                      type="text"
                      required
                      value={opCity}
                      onChange={(e) => setOpCity(e.target.value)}
                      placeholder={t.opinions.cityPlaceholder}
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0D47A1]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-800 mb-1">
                      {t.opinions.roleLabel}
                    </label>
                    <input
                      type="text"
                      value={opRole}
                      onChange={(e) => setOpRole(e.target.value)}
                      placeholder={t.opinions.rolePlaceholder}
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0D47A1]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-800 mb-1">
                    {t.opinions.messageLabel} *
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={opMessage}
                    onChange={(e) => setOpMessage(e.target.value)}
                    placeholder={t.opinions.messagePlaceholder}
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0D47A1]"
                  />
                </div>

                <button
                  type="submit"
                  disabled={opSubmitting}
                  className="w-full py-3 px-5 rounded-xl bg-[#0D47A1] hover:bg-[#08245E] disabled:opacity-60 text-white font-bold text-sm shadow transition cursor-pointer"
                >
                  {opSubmitting ? t.opinions.submitting : t.opinions.submitBtn}
                </button>
              </form>
            </div>

            {/* Community Voices List */}
            <div className="lg:col-span-7 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-[#0F172A]">
                  {t.opinions.feedTitle} ({opinions.length})
                </h3>
              </div>

              {opinions.length === 0 ? (
                <div className="bg-white rounded-2xl p-8 border border-slate-200 text-center text-slate-500 text-sm">
                  {t.opinions.emptyFeed}
                </div>
              ) : (
                <div className="space-y-4 max-h-[560px] overflow-y-auto pr-1">
                  {opinions.map((op) => (
                    <div
                      key={op.id}
                      className={`bg-white rounded-2xl p-5 border shadow-sm ${
                        op.isFeatured
                          ? "border-amber-300 ring-1 ring-amber-200"
                          : "border-slate-200"
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                        <div>
                          <span className="font-bold text-[#0F172A]">
                            {op.name}
                          </span>
                          <span className="text-xs text-slate-500 ml-2">
                            {op.city}
                            {op.role ? ` • ${op.role}` : ""}
                          </span>
                        </div>
                        {op.isFeatured && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900">
                            <Sparkles className="w-3 h-3" />
                            {t.opinions.featuredBadge}
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                        “{op.message}”
                      </p>
                      <div className="text-[11px] text-slate-400 mt-2">
                        {formatDate(op.createdAt)}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#061B47] text-blue-100 border-t border-blue-900 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2.5">
                <AshokaChakra className="w-7 h-7 text-amber-400" />
                <span className="font-bold text-lg text-white">
                  {t.footer.heading}
                </span>
              </div>
              <p className="text-sm text-blue-200">{t.footer.sub}</p>
              <p className="text-xs text-blue-300">{t.footer.organisersLine}</p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => handleSetLang(lang === "en" ? "mr" : "en")}
                className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition cursor-pointer"
              >
                {lang === "en" ? "मराठी आवृत्ती पहा" : "View English Version"}
              </button>
              <Link
                href="/organiser"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#061B47] text-xs font-bold transition"
              >
                <Lock className="w-3.5 h-3.5" />
                {t.footer.portalLink}
              </Link>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-white/10 text-xs text-blue-300 flex flex-col sm:flex-row items-center justify-between gap-2">
            <span>{t.footer.copyright}</span>
            <span className="font-semibold text-amber-200">
              {t.footer.designBy}
            </span>
            <span>Nashik • 12 December 2026</span>
          </div>
        </div>
      </footer>

      {/* PHOTO LIGHTBOX MODAL */}
      {lightboxImage && (
        <div
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setLightboxImage(null)}
        >
          <div
            className="relative max-w-4xl w-full bg-white rounded-2xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setLightboxImage(null)}
              className="absolute top-3 right-3 z-10 p-2 rounded-full bg-black/60 text-white hover:bg-black cursor-pointer"
              aria-label="Close photo"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={lightboxImage.url}
              alt={lightboxImage.title}
              className="w-full max-h-[80vh] object-contain bg-slate-950"
            />
            <div className="p-4 text-sm font-semibold text-slate-800">
              {lightboxImage.title}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
