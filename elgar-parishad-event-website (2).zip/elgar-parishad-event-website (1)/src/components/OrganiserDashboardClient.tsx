"use client";

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  Camera,
  CheckCircle2,
  Download,
  Eye,
  EyeOff,
  ImagePlus,
  Images,
  Lock,
  LogOut,
  MapPin,
  Megaphone,
  MessageSquare,
  Pin,
  PinOff,
  Search,
  Sparkles,
  Trash2,
  Users,
} from "lucide-react";
import { AshokaChakra } from "./AshokaChakra";
import {
  ORGANISER_SLOTS,
  OrganiserPhotosDTO,
} from "@/lib/organiser-photos";

type ImagePayload = {
  base64: string;
  mimeType: string;
  fileName: string;
};

interface AttendeeRow {
  id: number;
  fullName: string;
  phone: string;
  city: string;
  organization: string | null;
  status: string;
  companions: number;
  notes: string | null;
  createdAt: string;
}

interface StatsSummary {
  totalRegistrations: number;
  attendingRegistrations: number;
  maybeRegistrations: number;
  confirmedHeadcount: number;
  totalPotentialHeadcount: number;
}

interface UpdateRow {
  id: number;
  titleEn: string;
  titleMr: string | null;
  bodyEn: string;
  bodyMr: string | null;
  category: string;
  authorName: string;
  resolvedImageUrl: string | null;
  isPinned: boolean;
  createdAt: string;
}

interface OpinionRow {
  id: number;
  name: string;
  city: string;
  role: string | null;
  message: string;
  isVisible: boolean;
  isFeatured: boolean;
  createdAt: string;
}

type TabKey =
  | "attendees"
  | "updates"
  | "opinions"
  | "venue"
  | "guestPhoto"
  | "ambedkarPhoto"
  | "organiserPhotos";

async function compressImageToBase64(
  file: File
): Promise<{ base64: string; mimeType: string; fileName: string }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Could not read file"));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("Invalid image file"));
      img.onload = () => {
        const maxDim = 1280;
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          reject(new Error("Canvas unavailable"));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL("image/jpeg", 0.82);
        resolve({
          base64: dataUrl,
          mimeType: "image/jpeg",
          fileName: file.name,
        });
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

const TOKEN_STORAGE_KEY = "elgar_organiser_token";

export function OrganiserDashboardClient({
  initialAuthenticated,
}: {
  initialAuthenticated: boolean;
}) {
  const [authenticated, setAuthenticated] = useState(initialAuthenticated);
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const tokenRef = useRef<string | null>(null);
  const [passcode, setPasscode] = useState("");
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);

  const [lang, setLang] = useState<"en" | "mr">("en");
  const [activeTab, setActiveTab] = useState<TabKey>("attendees");
  const [loadingData, setLoadingData] = useState(false);

  // Attendees state
  const [attendees, setAttendees] = useState<AttendeeRow[]>([]);
  const [stats, setStats] = useState<StatsSummary>({
    totalRegistrations: 0,
    attendingRegistrations: 0,
    maybeRegistrations: 0,
    confirmedHeadcount: 0,
    totalPotentialHeadcount: 0,
  });
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "attending" | "maybe">(
    "all"
  );

  // Updates state
  const [updatesList, setUpdatesList] = useState<UpdateRow[]>([]);
  const [postTitleEn, setPostTitleEn] = useState("");
  const [postTitleMr, setPostTitleMr] = useState("");
  const [postBodyEn, setPostBodyEn] = useState("");
  const [postBodyMr, setPostBodyMr] = useState("");
  const [postCategory, setPostCategory] = useState("announcement");
  const [postAuthor, setPostAuthor] = useState("Organising Committee");
  const [postPinned, setPostPinned] = useState(false);
  const [postImagePreview, setPostImagePreview] = useState<string | null>(null);
  const [postImagePayload, setPostImagePayload] = useState<{
    base64: string;
    mimeType: string;
    fileName: string;
  } | null>(null);
  const [postSubmitting, setPostSubmitting] = useState(false);
  const [postFeedback, setPostFeedback] = useState<string | null>(null);

  // Opinions state
  const [opinionsList, setOpinionsList] = useState<OpinionRow[]>([]);

  // Venue/Time state
  const [venueEn, setVenueEn] = useState("");
  const [venueMr, setVenueMr] = useState("");
  const [timeEn, setTimeEn] = useState("");
  const [timeMr, setTimeMr] = useState("");
  const [venueSaving, setVenueSaving] = useState(false);
  const [venueSavedMsg, setVenueSavedMsg] = useState<string | null>(null);

  // Chief Guest photo state
  const [guestPhotoUrl, setGuestPhotoUrl] = useState<string | null>(null);
  const [guestPhotoPreview, setGuestPhotoPreview] = useState<string | null>(null);
  const [guestPhotoPayload, setGuestPhotoPayload] = useState<{
    base64: string;
    mimeType: string;
    fileName: string;
  } | null>(null);
  const [guestPhotoUrlInput, setGuestPhotoUrlInput] = useState("");
  const [guestPhotoSaving, setGuestPhotoSaving] = useState(false);
  const [guestPhotoMsg, setGuestPhotoMsg] = useState<string | null>(null);

  // Dr. B.R. Ambedkar photo state
  const [ambedkarPhotoUrl, setAmbedkarPhotoUrl] = useState<string | null>(null);
  const [ambedkarPhotoPreview, setAmbedkarPhotoPreview] = useState<string | null>(
    null
  );
  const [ambedkarPhotoPayload, setAmbedkarPhotoPayload] = useState<{
    base64: string;
    mimeType: string;
    fileName: string;
  } | null>(null);
  const [ambedkarPhotoUrlInput, setAmbedkarPhotoUrlInput] = useState("");
  const [ambedkarPhotoSaving, setAmbedkarPhotoSaving] = useState(false);
  const [ambedkarPhotoMsg, setAmbedkarPhotoMsg] = useState<string | null>(null);

  // Organiser photos state
  const [organiserPhotos, setOrganiserPhotos] = useState<OrganiserPhotosDTO>({
    profiles: {},
    gallery: [],
  });
  const [profileSlot, setProfileSlot] = useState<string>(
    ORGANISER_SLOTS[0].key
  );
  const [profilePreview, setProfilePreview] = useState<string | null>(null);
  const [profilePayload, setProfilePayload] = useState<ImagePayload | null>(
    null
  );
  const [galleryPreview, setGalleryPreview] = useState<string | null>(null);
  const [galleryPayload, setGalleryPayload] = useState<ImagePayload | null>(
    null
  );
  const [galleryCaptionEn, setGalleryCaptionEn] = useState("");
  const [galleryCaptionMr, setGalleryCaptionMr] = useState("");
  const [orgPhotoSaving, setOrgPhotoSaving] = useState(false);
  const [orgPhotoMsg, setOrgPhotoMsg] = useState<string | null>(null);

  const authFetch = useCallback(
    (input: string, init: RequestInit = {}) => {
      const headers = new Headers(init.headers);
      let tok = tokenRef.current || sessionToken;
      if (!tok && typeof window !== "undefined") {
        try {
          tok = window.sessionStorage.getItem(TOKEN_STORAGE_KEY);
        } catch {
          // ignore storage errors
        }
      }
      let targetUrl = input;
      if (tok) {
        headers.set("x-organiser-token", tok);
        headers.set("Authorization", `Bearer ${tok}`);
        const sep = input.includes("?") ? "&" : "?";
        targetUrl = `${input}${sep}token=${encodeURIComponent(tok)}`;
      }
      return fetch(targetUrl, {
        ...init,
        headers,
        credentials: "include",
      });
    },
    [sessionToken]
  );

  useEffect(() => {
    if (!initialAuthenticated && typeof window !== "undefined") {
      try {
        const stored = window.sessionStorage.getItem(TOKEN_STORAGE_KEY);
        if (stored) {
          tokenRef.current = stored;
          setSessionToken(stored);
          setAuthenticated(true);
        }
      } catch {
        // ignore storage errors
      }
    }
  }, [initialAuthenticated]);

  const loadDashboardData = useCallback(async () => {
    setLoadingData(true);
    try {
      const [attRes, updRes, opRes, evRes, orgRes] = await Promise.all([
        authFetch("/api/attendees"),
        authFetch("/api/updates"),
        authFetch("/api/opinions?all=1"),
        authFetch("/api/event-info"),
        authFetch("/api/organiser-photos"),
      ]);

      if (attRes.status === 401) {
        tokenRef.current = null;
        setSessionToken(null);
        setAuthenticated(false);
        setLoginError(
          "Your session expired or could not be verified. Please sign in again."
        );
        try {
          window.sessionStorage.removeItem(TOKEN_STORAGE_KEY);
        } catch {
          // ignore
        }
        return;
      }

      if (attRes.ok) {
        const attData = await attRes.json();
        setAttendees(attData.attendees || []);
        if (attData.stats) setStats(attData.stats);
      }
      if (updRes.ok) {
        const updData = await updRes.json();
        setUpdatesList(updData.updates || []);
      }
      if (opRes.ok) {
        const opData = await opRes.json();
        setOpinionsList(opData.opinions || []);
      }
      if (evRes.ok) {
        const evData = await evRes.json();
        if (evData.settings) {
          setVenueEn(evData.settings.venueEn || "");
          setVenueMr(evData.settings.venueMr || "");
          setTimeEn(evData.settings.timeEn || "");
          setTimeMr(evData.settings.timeMr || "");
        }
        setGuestPhotoUrl(evData.guestPhotoUrl ?? null);
        setAmbedkarPhotoUrl(evData.ambedkarPhotoUrl ?? null);
      }
      if (orgRes.ok) {
        const orgData = await orgRes.json();
        setOrganiserPhotos({
          profiles: orgData.profiles || {},
          gallery: orgData.gallery || [],
        });
      }
    } catch (err) {
      console.error("Failed to load dashboard data:", err);
    } finally {
      setLoadingData(false);
    }
  }, [authFetch]);

  useEffect(() => {
    if (authenticated) {
      loadDashboardData();
    }
  }, [authenticated, loadDashboardData]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoginLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ passcode }),
      });
      if (!res.ok) {
        setLoginError(
          lang === "mr"
            ? "चुकीचा पासकोड. कृपया पुन्हा प्रयत्न करा."
            : "Invalid organiser passcode. Please try again."
        );
      } else {
        const data = await res.json();
        if (data?.token) {
          tokenRef.current = data.token;
          setSessionToken(data.token);
          try {
            window.sessionStorage.setItem(TOKEN_STORAGE_KEY, data.token);
          } catch {
            // ignore
          }
        }
        setAuthenticated(true);
        setPasscode("");
      }
    } catch {
      setLoginError("Network error");
    } finally {
      setLoginLoading(false);
    }
  };

  const handleLogout = async () => {
    await authFetch("/api/auth/logout", { method: "POST" });
    tokenRef.current = null;
    setSessionToken(null);
    try {
      window.sessionStorage.removeItem(TOKEN_STORAGE_KEY);
    } catch {
      // ignore
    }
    setAuthenticated(false);
  };

  const filteredAttendees = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return attendees.filter((a) => {
      if (statusFilter !== "all" && a.status !== statusFilter) return false;
      if (!q) return true;
      return (
        a.fullName.toLowerCase().includes(q) ||
        a.city.toLowerCase().includes(q) ||
        (a.notes || "").toLowerCase().includes(q)
      );
    });
  }, [attendees, searchQuery, statusFilter]);

  const handleExportCsv = () => {
    const headers = [
      "ID",
      "Full Name",
      "City/Taluka",
      "Status",
      "Companions",
      "Total Headcount",
      "Notes",
      "Registered At",
    ];
    const rows = filteredAttendees.map((a) => [
      `ELG-2026-${String(a.id).padStart(4, "0")}`,
      a.fullName,
      a.city,
      a.status,
      String(a.companions),
      String(1 + a.companions),
      (a.notes || "").replace(/\r?\n/g, " "),
      new Date(a.createdAt).toLocaleString("en-IN"),
    ]);

    const csvContent =
      "\uFEFF" +
      [headers, ...rows]
        .map((row) =>
          row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(",")
        )
        .join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `elgar-parishad-attendees-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDeleteAttendee = async (id: number) => {
    const res = await authFetch(`/api/attendees/${id}`, { method: "DELETE" });
    if (res.ok) {
      await loadDashboardData();
    }
  };

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImageToBase64(file);
      setPostImagePayload(compressed);
      setPostImagePreview(compressed.base64);
    } catch {
      setPostFeedback("Could not process this image file.");
    }
  };

  const handlePublishUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setPostFeedback(null);
    setPostSubmitting(true);

    try {
      const res = await authFetch("/api/updates", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          titleEn: postTitleEn,
          titleMr: postTitleMr,
          bodyEn: postBodyEn,
          bodyMr: postBodyMr,
          category: postCategory,
          authorName: postAuthor,
          isPinned: postPinned,
          imageBase64: postImagePayload?.base64,
          imageMimeType: postImagePayload?.mimeType,
          imageFileName: postImagePayload?.fileName,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setPostFeedback(data.error || "Failed to publish");
      } else {
        setPostTitleEn("");
        setPostTitleMr("");
        setPostBodyEn("");
        setPostBodyMr("");
        setPostPinned(false);
        setPostImagePayload(null);
        setPostImagePreview(null);
        setPostFeedback(
          lang === "mr"
            ? "माहिती / छायाचित्र यशस्वीरित्या प्रसिद्ध झाले!"
            : "Update & photo published to the website!"
        );
        await loadDashboardData();
      }
    } catch {
      setPostFeedback("Network error while publishing.");
    } finally {
      setPostSubmitting(false);
    }
  };

  const handleTogglePinUpdate = async (id: number, current: boolean) => {
    const res = await authFetch(`/api/updates/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isPinned: !current }),
    });
    if (res.ok) await loadDashboardData();
  };

  const handleDeleteUpdate = async (id: number) => {
    const res = await authFetch(`/api/updates/${id}`, { method: "DELETE" });
    if (res.ok) await loadDashboardData();
  };

  const handleToggleOpinion = async (
    id: number,
    patch: { isVisible?: boolean; isFeatured?: boolean }
  ) => {
    const res = await authFetch(`/api/opinions/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
    });
    if (res.ok) await loadDashboardData();
  };

  const handleDeleteOpinion = async (id: number) => {
    const res = await authFetch(`/api/opinions/${id}`, { method: "DELETE" });
    if (res.ok) await loadDashboardData();
  };

  const handleSaveVenue = async (e: React.FormEvent) => {
    e.preventDefault();
    setVenueSavedMsg(null);
    setVenueSaving(true);
    try {
      const res = await authFetch("/api/event-info", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ venueEn, venueMr, timeEn, timeMr }),
      });
      if (res.ok) {
        setVenueSavedMsg(
          lang === "mr"
            ? "स्थळ आणि वेळ मुख्य पानावर अपडेट झाली आहे!"
            : "Venue & time updated on the public homepage!"
        );
      }
    } finally {
      setVenueSaving(false);
    }
  };

  const handleGuestPhotoSelect = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setGuestPhotoMsg(null);
    try {
      const compressed = await compressImageToBase64(file);
      setGuestPhotoPayload(compressed);
      setGuestPhotoPreview(compressed.base64);
      setGuestPhotoUrlInput("");
    } catch {
      setGuestPhotoMsg(
        lang === "mr"
          ? "हा फोटो वाचता आला नाही. दुसरा फोटो निवडा."
          : "Could not read this photo. Please choose another image."
      );
    }
  };

  const handleSaveGuestPhoto = async (e: React.FormEvent) => {
    e.preventDefault();
    setGuestPhotoMsg(null);

    if (!guestPhotoPayload && !guestPhotoUrlInput.trim()) {
      setGuestPhotoMsg(
        lang === "mr"
          ? "कृपया फोटो निवडा किंवा फोटोची लिंक टाका."
          : "Please choose a photo file or paste an image URL."
      );
      return;
    }

    setGuestPhotoSaving(true);
    try {
      const res = await authFetch("/api/guest-photo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: guestPhotoPayload?.base64,
          imageMimeType: guestPhotoPayload?.mimeType,
          imageFileName: guestPhotoPayload?.fileName,
          imageUrl: guestPhotoUrlInput.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setGuestPhotoMsg(data.error || "Failed to save Chief Guest photo.");
      } else {
        setGuestPhotoUrl(data.guestPhotoUrl ?? null);
        setGuestPhotoPayload(null);
        setGuestPhotoPreview(null);
        setGuestPhotoUrlInput("");
        setGuestPhotoMsg(
          lang === "mr"
            ? "प्रमुख पाहुण्यांचा फोटो नावाजवळ प्रसिद्ध झाला आहे!"
            : "Chief Guest photo is now live beside his name on the homepage!"
        );
      }
    } catch {
      setGuestPhotoMsg("Network error while saving the photo.");
    } finally {
      setGuestPhotoSaving(false);
    }
  };

  const handleRemoveGuestPhoto = async () => {
    setGuestPhotoMsg(null);
    const res = await authFetch("/api/guest-photo", { method: "DELETE" });
    if (res.ok) {
      setGuestPhotoUrl(null);
      setGuestPhotoPreview(null);
      setGuestPhotoPayload(null);
      setGuestPhotoMsg(
        lang === "mr"
          ? "फोटो काढून टाकला आहे."
          : "Chief Guest photo removed from the homepage."
      );
    }
  };

  const handleAmbedkarPhotoSelect = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAmbedkarPhotoMsg(null);
    try {
      const compressed = await compressImageToBase64(file);
      setAmbedkarPhotoPayload(compressed);
      setAmbedkarPhotoPreview(compressed.base64);
      setAmbedkarPhotoUrlInput("");
    } catch {
      setAmbedkarPhotoMsg(
        lang === "mr"
          ? "हा फोटो वाचता आला नाही. दुसरा फोटो निवडा."
          : "Could not read this photo. Please choose another image."
      );
    }
  };

  const handleSaveAmbedkarPhoto = async (e: React.FormEvent) => {
    e.preventDefault();
    setAmbedkarPhotoMsg(null);

    if (!ambedkarPhotoPayload && !ambedkarPhotoUrlInput.trim()) {
      setAmbedkarPhotoMsg(
        lang === "mr"
          ? "कृपया फोटो निवडा किंवा फोटोची लिंक टाका."
          : "Please choose a photo file or paste an image URL."
      );
      return;
    }

    setAmbedkarPhotoSaving(true);
    try {
      const res = await authFetch("/api/ambedkar-photo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: ambedkarPhotoPayload?.base64,
          imageMimeType: ambedkarPhotoPayload?.mimeType,
          imageFileName: ambedkarPhotoPayload?.fileName,
          imageUrl: ambedkarPhotoUrlInput.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setAmbedkarPhotoMsg(
          data.error || "Failed to save Dr. Ambedkar photo."
        );
      } else {
        setAmbedkarPhotoUrl(data.ambedkarPhotoUrl ?? null);
        setAmbedkarPhotoPayload(null);
        setAmbedkarPhotoPreview(null);
        setAmbedkarPhotoUrlInput("");
        setAmbedkarPhotoMsg(
          lang === "mr"
            ? "डॉ. बाबासाहेब आंबेडकरांचा मोठा फोटो मुख्य पानावर अपडेट झाला आहे!"
            : "Dr. Ambedkar's large photo is now live on the homepage!"
        );
      }
    } catch {
      setAmbedkarPhotoMsg("Network error while saving the photo.");
    } finally {
      setAmbedkarPhotoSaving(false);
    }
  };

  const handleRemoveAmbedkarPhoto = async () => {
    setAmbedkarPhotoMsg(null);
    const res = await authFetch("/api/ambedkar-photo", { method: "DELETE" });
    if (res.ok) {
      setAmbedkarPhotoUrl(null);
      setAmbedkarPhotoPreview(null);
      setAmbedkarPhotoPayload(null);
      setAmbedkarPhotoMsg(
        lang === "mr"
          ? "मूळ छायाचित्र पुन्हा वापरले जात आहे."
          : "Reverted to the original archival photo."
      );
    }
  };

  const applyOrganiserPhotosData = (data: {
    profiles?: Record<string, string>;
    gallery?: OrganiserPhotosDTO["gallery"];
  }) => {
    setOrganiserPhotos({
      profiles: data.profiles || {},
      gallery: data.gallery || [],
    });
  };

  const submitOrganiserPhoto = async (
    payload: Record<string, unknown>,
    successMessage: string
  ): Promise<boolean> => {
    setOrgPhotoMsg(null);
    setOrgPhotoSaving(true);
    try {
      const res = await authFetch("/api/organiser-photos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setOrgPhotoMsg(data.error || "Failed to save organiser photo.");
        return false;
      }
      applyOrganiserPhotosData(data);
      setOrgPhotoMsg(successMessage);
      return true;
    } catch {
      setOrgPhotoMsg("Network error while saving the photo.");
      return false;
    } finally {
      setOrgPhotoSaving(false);
    }
  };

  const handleProfilePhotoSelect = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setOrgPhotoMsg(null);
    try {
      const compressed = await compressImageToBase64(file);
      setProfilePayload(compressed);
      setProfilePreview(compressed.base64);
    } catch {
      setOrgPhotoMsg("Could not read this photo. Please choose another image.");
    }
  };

  const handleSaveProfilePhoto = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profilePayload) {
      setOrgPhotoMsg("Please choose a photo for the selected organiser.");
      return;
    }
    const ok = await submitOrganiserPhoto(
      {
        kind: "profile",
        slotKey: profileSlot,
        imageBase64: profilePayload.base64,
        imageMimeType: profilePayload.mimeType,
        imageFileName: profilePayload.fileName,
      },
      lang === "mr"
        ? "आयोजकाचा फोटो मुख्य पानावर अपडेट झाला आहे!"
        : "Organiser profile photo updated on the homepage!"
    );
    if (ok) {
      setProfilePayload(null);
      setProfilePreview(null);
    }
  };

  const handleRemoveProfilePhoto = async (slotKey: string) => {
    setOrgPhotoMsg(null);
    const res = await authFetch(
      `/api/organiser-photos?slotKey=${encodeURIComponent(slotKey)}`,
      { method: "DELETE" }
    );
    if (res.ok) {
      applyOrganiserPhotosData(await res.json());
      setOrgPhotoMsg(
        lang === "mr" ? "आयोजकाचा फोटो काढला आहे." : "Organiser photo removed."
      );
    }
  };

  const handleGalleryPhotoSelect = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setOrgPhotoMsg(null);
    try {
      const compressed = await compressImageToBase64(file);
      setGalleryPayload(compressed);
      setGalleryPreview(compressed.base64);
    } catch {
      setOrgPhotoMsg("Could not read this photo. Please choose another image.");
    }
  };

  const handleSaveGalleryPhoto = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!galleryPayload) {
      setOrgPhotoMsg("Please choose a committee photo first.");
      return;
    }
    const ok = await submitOrganiserPhoto(
      {
        kind: "gallery",
        captionEn: galleryCaptionEn,
        captionMr: galleryCaptionMr,
        imageBase64: galleryPayload.base64,
        imageMimeType: galleryPayload.mimeType,
        imageFileName: galleryPayload.fileName,
      },
      lang === "mr"
        ? "समितीचे छायाचित्र गॅलरीत प्रसिद्ध झाले आहे!"
        : "Committee photo published to the gallery!"
    );
    if (ok) {
      setGalleryPayload(null);
      setGalleryPreview(null);
      setGalleryCaptionEn("");
      setGalleryCaptionMr("");
    }
  };

  const handleDeleteGalleryPhoto = async (id: number) => {
    setOrgPhotoMsg(null);
    const res = await authFetch(`/api/organiser-photos?id=${id}`, {
      method: "DELETE",
    });
    if (res.ok) {
      applyOrganiserPhotosData(await res.json());
      setOrgPhotoMsg(
        lang === "mr" ? "छायाचित्र काढले आहे." : "Gallery photo removed."
      );
    }
  };

  if (!authenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#061B47] via-[#0D47A1] to-[#08245E] flex flex-col items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl p-7 sm:p-9 space-y-6">
          <div className="flex items-center justify-between">
            <Link
              href="/"
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#0D47A1] hover:underline"
            >
              <ArrowLeft className="w-4 h-4" />
              {lang === "mr" ? "मुख्य पानावर जा" : "Back to Website"}
            </Link>
            <div className="inline-flex rounded-full bg-slate-100 p-0.5 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setLang("en")}
                className={`px-2.5 py-1 rounded-full cursor-pointer ${
                  lang === "en" ? "bg-[#0D47A1] text-white" : "text-slate-600"
                }`}
              >
                EN
              </button>
              <button
                type="button"
                onClick={() => setLang("mr")}
                className={`px-2.5 py-1 rounded-full cursor-pointer ${
                  lang === "mr" ? "bg-[#0D47A1] text-white" : "text-slate-600"
                }`}
              >
                मराठी
              </button>
            </div>
          </div>

          <div className="text-center space-y-2">
            <div className="w-14 h-14 rounded-2xl bg-[#0D47A1] text-amber-300 flex items-center justify-center mx-auto shadow">
              <AshokaChakra className="w-8 h-8" />
            </div>
            <h1 className="text-2xl font-extrabold text-[#0F172A]">
              {lang === "mr" ? "आयोजक पोर्टल लॉगिन" : "Organiser Committee Portal"}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600">
              {lang === "mr"
                ? "नोंदणी संख्या पाहण्यासाठी, मते वाचण्यासाठी आणि नवीन माहिती/फोटो प्रसिद्ध करण्यासाठी पासकोड टाका."
                : "Enter the organising committee passcode to view applicant counts, read public opinions, and publish updates or photos."}
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            {loginError && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm">
                {loginError}
              </div>
            )}

            <div>
              <label className="block text-sm font-semibold text-slate-800 mb-1.5">
                {lang === "mr" ? "आयोजक पासकोड" : "Organiser Passcode"}
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="password"
                  required
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  placeholder={lang === "mr" ? "पासकोड टाका" : "Enter passcode"}
                  className="w-full rounded-xl border border-slate-300 pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0D47A1]"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loginLoading}
              className="w-full py-3 rounded-xl bg-[#0D47A1] hover:bg-[#08245E] text-white font-bold text-sm shadow transition cursor-pointer"
            >
              {loginLoading
                ? lang === "mr"
                  ? "तपासत आहे..."
                  : "Verifying..."
                : lang === "mr"
                ? "पोर्टल उघडा"
                : "Sign In to Dashboard"}
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-[#0F172A] flex flex-col">
      {/* Top Bar */}
      <header className="bg-[#08245E] text-white border-b border-white/15 sticky top-0 z-30 shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <AshokaChakra className="w-8 h-8 text-amber-400" />
            <div>
              <h1 className="font-bold text-sm sm:text-base">
                {lang === "mr"
                  ? "एल्गार परिषद — आयोजक डॅशबोर्ड"
                  : "Elgar Parishad — Organiser Dashboard"}
              </h1>
              <p className="text-[11px] text-blue-200 hidden sm:block">
                Nashik • 12 December 2026
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            <div className="inline-flex rounded-full bg-[#04153B] p-0.5 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setLang("en")}
                className={`px-2.5 py-1 rounded-full cursor-pointer ${
                  lang === "en" ? "bg-amber-400 text-[#08245E]" : "text-blue-100"
                }`}
              >
                EN
              </button>
              <button
                type="button"
                onClick={() => setLang("mr")}
                className={`px-2.5 py-1 rounded-full cursor-pointer ${
                  lang === "mr" ? "bg-amber-400 text-[#08245E]" : "text-blue-100"
                }`}
              >
                मराठी
              </button>
            </div>

            <Link
              href="/"
              className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold transition"
            >
              {lang === "mr" ? "वेबसाईट पहा" : "View Public Site"}
            </Link>

            <button
              type="button"
              onClick={handleLogout}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-100 text-xs font-semibold cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">
                {lang === "mr" ? "बाहेर पडा" : "Logout"}
              </span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto w-full px-4 sm:px-6 py-8 space-y-6">
        {/* Top KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
            <div className="text-xs font-semibold text-slate-500 uppercase">
              {lang === "mr" ? "अपेक्षित एकूण उपस्थिती" : "Confirmed Headcount"}
            </div>
            <div className="text-3xl font-extrabold text-[#0D47A1] mt-1 tabular-nums">
              {stats.confirmedHeadcount}
            </div>
            <div className="text-xs text-slate-500 mt-1">
              {lang === "mr"
                ? "सहकाऱ्यांसह निश्चित संख्या"
                : "Includes accompanying members"}
            </div>
          </div>

          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
            <div className="text-xs font-semibold text-slate-500 uppercase">
              {lang === "mr" ? "एकूण प्राप्त अर्ज" : "Total Applications"}
            </div>
            <div className="text-3xl font-extrabold text-[#0F172A] mt-1 tabular-nums">
              {stats.totalRegistrations}
            </div>
            <div className="text-xs text-emerald-700 mt-1 font-medium">
              {stats.attendingRegistrations}{" "}
              {lang === "mr" ? "निश्चित उपस्थित" : "confirmed"} •{" "}
              {stats.maybeRegistrations}{" "}
              {lang === "mr" ? "इच्छुक" : "tentative"}
            </div>
          </div>

          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
            <div className="text-xs font-semibold text-slate-500 uppercase">
              {lang === "mr" ? "नागरिकांची मते" : "Public Opinions"}
            </div>
            <div className="text-3xl font-extrabold text-amber-700 mt-1 tabular-nums">
              {opinionsList.length}
            </div>
            <div className="text-xs text-slate-500 mt-1">
              {lang === "mr" ? "समितीकडे प्राप्त विचार" : "Submitted by citizens"}
            </div>
          </div>

          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
            <div className="text-xs font-semibold text-slate-500 uppercase">
              {lang === "mr" ? "प्रसिद्ध अपडेट्स / फोटो" : "Updates & Photos"}
            </div>
            <div className="text-3xl font-extrabold text-[#0F172A] mt-1 tabular-nums">
              {updatesList.length}
            </div>
            <div className="text-xs text-slate-500 mt-1">
              {lang === "mr" ? "वेबसाईटवर प्रकाशित" : "Live on bulletin"}
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-3">
          {[
            {
              key: "attendees" as TabKey,
              icon: Users,
              label:
                lang === "mr"
                  ? `उपस्थिती यादी (${attendees.length})`
                  : `Registered Attendees (${attendees.length})`,
            },
            {
              key: "updates" as TabKey,
              icon: Megaphone,
              label:
                lang === "mr"
                  ? "नवीन अपडेट / फोटो टाका"
                  : "Post Update & Photos",
            },
            {
              key: "opinions" as TabKey,
              icon: MessageSquare,
              label:
                lang === "mr"
                  ? `जनमत पहा (${opinionsList.length})`
                  : `View Public Opinions (${opinionsList.length})`,
            },
            {
              key: "venue" as TabKey,
              icon: MapPin,
              label:
                lang === "mr" ? "स्थळ व वेळ अपडेट करा" : "Set Venue & Time",
            },
            {
              key: "guestPhoto" as TabKey,
              icon: Camera,
              label:
                lang === "mr"
                  ? "प्रमुख पाहुण्यांचा फोटो"
                  : "Chief Guest Photo",
            },
            {
              key: "ambedkarPhoto" as TabKey,
              icon: Camera,
              label:
                lang === "mr"
                  ? "डॉ. आंबेडकरांचा फोटो"
                  : "Dr. Ambedkar Photo",
            },
            {
              key: "organiserPhotos" as TabKey,
              icon: Images,
              label:
                lang === "mr"
                  ? "आयोजकांची छायाचित्रे"
                  : "Organiser Photos",
            },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                type="button"
                onClick={() => setActiveTab(tab.key)}
                className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition cursor-pointer ${
                  active
                    ? "bg-[#0D47A1] text-white shadow-sm"
                    : "bg-white text-slate-700 border border-slate-200 hover:bg-slate-100"
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {loadingData && (
          <div className="text-xs text-slate-500">
            {lang === "mr" ? "माहिती लोड होत आहे..." : "Refreshing data..."}
          </div>
        )}

        {/* TAB 1: ATTENDEES */}
        {activeTab === "attendees" && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-3 flex-1">
                <div className="relative flex-1 min-w-[200px] max-w-sm">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={
                      lang === "mr"
                        ? "नाव किंवा शहर शोधा..."
                        : "Search name or city..."
                    }
                    className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#0D47A1]"
                  />
                </div>

                <select
                  value={statusFilter}
                  onChange={(e) =>
                    setStatusFilter(
                      e.target.value as "all" | "attending" | "maybe"
                    )
                  }
                  className="rounded-xl border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  <option value="all">
                    {lang === "mr" ? "सर्व नोंदणी" : "All Statuses"}
                  </option>
                  <option value="attending">
                    {lang === "mr" ? "निश्चित उपस्थित" : "Attending"}
                  </option>
                  <option value="maybe">
                    {lang === "mr" ? "इच्छुक / कळवणारे" : "Tentative / Maybe"}
                  </option>
                </select>
              </div>

              <button
                type="button"
                onClick={handleExportCsv}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold shadow-sm cursor-pointer"
              >
                <Download className="w-4 h-4" />
                {lang === "mr" ? "CSV डाउनलोड करा" : "Export CSV"}
              </button>
            </div>

            {filteredAttendees.length === 0 ? (
              <div className="p-10 text-center text-slate-500 text-sm">
                {lang === "mr"
                  ? "अजून कोणतीही नोंदणी नाही."
                  : "No matching attendee registrations found yet."}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 text-xs uppercase text-slate-600 border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-3">Ref</th>
                      <th className="px-4 py-3">
                        {lang === "mr" ? "नाव" : "Name"}
                      </th>
                      <th className="px-4 py-3">
                        {lang === "mr" ? "शहर / तालुका" : "City / Taluka"}
                      </th>
                      <th className="px-4 py-3">
                        {lang === "mr" ? "स्थिती" : "Status"}
                      </th>
                      <th className="px-4 py-3">
                        {lang === "mr" ? "एकूण लोक" : "Headcount"}
                      </th>
                      <th className="px-4 py-3">
                        {lang === "mr" ? "टीप" : "Notes"}
                      </th>
                      <th className="px-4 py-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredAttendees.map((row) => (
                      <tr key={row.id} className="hover:bg-slate-50/70">
                        <td className="px-4 py-3 font-mono text-xs text-slate-500">
                          ELG-{String(row.id).padStart(4, "0")}
                        </td>
                        <td className="px-4 py-3 font-semibold text-[#0F172A]">
                          {row.fullName}
                        </td>
                        <td className="px-4 py-3">{row.city}</td>
                        <td className="px-4 py-3">
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                              row.status === "attending"
                                ? "bg-emerald-100 text-emerald-800"
                                : "bg-amber-100 text-amber-800"
                            }`}
                          >
                            {row.status === "attending"
                              ? lang === "mr"
                                ? "उपस्थित"
                                : "Attending"
                              : lang === "mr"
                              ? "इच्छुक"
                              : "Maybe"}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-bold text-[#0D47A1]">
                          {1 + row.companions}{" "}
                          <span className="text-xs font-normal text-slate-500">
                            (+{row.companions})
                          </span>
                        </td>
                        <td className="px-4 py-3 text-xs text-slate-600 max-w-xs truncate">
                          {row.notes || "—"}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <button
                            type="button"
                            onClick={() => handleDeleteAttendee(row.id)}
                            className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50 cursor-pointer"
                            title="Remove entry"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: POST UPDATES & PHOTOS */}
        {activeTab === "updates" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Simple Publish Form */}
            <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
              <h2 className="text-lg font-extrabold text-[#0F172A] mb-4 flex items-center gap-2">
                <Megaphone className="w-5 h-5 text-[#0D47A1]" />
                {lang === "mr"
                  ? "नवीन पोस्ट / फोटो प्रसिद्ध करा"
                  : "Publish Update or Photo"}
              </h2>

              <form onSubmit={handlePublishUpdate} className="space-y-4">
                {postFeedback && (
                  <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-[#0D47A1] text-sm font-medium">
                    {postFeedback}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {lang === "mr" ? "प्रकार" : "Category"}
                    </label>
                    <select
                      value={postCategory}
                      onChange={(e) => setPostCategory(e.target.value)}
                      className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm bg-white"
                    >
                      <option value="announcement">Announcement</option>
                      <option value="photo">Photo Update</option>
                      <option value="venue">Venue & Schedule</option>
                      <option value="press">Press Release</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {lang === "mr" ? "कोणाकडून" : "Posted By"}
                    </label>
                    <select
                      value={postAuthor}
                      onChange={(e) => setPostAuthor(e.target.value)}
                      className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm bg-white"
                    >
                      <option value="Organising Committee">
                        Organising Committee
                      </option>
                      <option value="Babanrao Gholap">Babanrao Gholap</option>
                      <option value="Vilas Patil">Vilas Patil</option>
                      <option value="Prakash Bagul">Prakash Bagul</option>
                      <option value="Mahesh Avhad">Mahesh Avhad</option>
                      <option value="Sanjay Donde">Sanjay Donde</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {lang === "mr" ? "शीर्षक (English)" : "Title (English)"} *
                  </label>
                  <input
                    type="text"
                    required={!postTitleMr}
                    value={postTitleEn}
                    onChange={(e) => setPostTitleEn(e.target.value)}
                    placeholder="e.g., Nashik Preparatory Meeting Photos"
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {lang === "mr"
                      ? "शीर्षक (मराठी - ऐच्छिक)"
                      : "Title in Marathi (Optional)"}
                  </label>
                  <input
                    type="text"
                    value={postTitleMr}
                    onChange={(e) => setPostTitleMr(e.target.value)}
                    placeholder="उदा. नाशिक पूर्वतयारी बैठकीची छायाचित्रे"
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {lang === "mr" ? "माहिती (English)" : "Details (English)"}
                  </label>
                  <textarea
                    rows={3}
                    value={postBodyEn}
                    onChange={(e) => setPostBodyEn(e.target.value)}
                    placeholder="Write update details..."
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {lang === "mr"
                      ? "माहिती (मराठी - ऐच्छिक)"
                      : "Details in Marathi (Optional)"}
                  </label>
                  <textarea
                    rows={3}
                    value={postBodyMr}
                    onChange={(e) => setPostBodyMr(e.target.value)}
                    placeholder="मराठीत सविस्तर माहिती..."
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>

                {/* Direct Photo Upload */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    {lang === "mr"
                      ? "फोटो अपलोड करा (ऐच्छिक)"
                      : "Upload Photo from Phone / PC (Optional)"}
                  </label>
                  <label className="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 hover:border-[#0D47A1] rounded-xl p-4 cursor-pointer bg-slate-50 transition">
                    <ImagePlus className="w-6 h-6 text-[#0D47A1] mb-1" />
                    <span className="text-xs font-medium text-slate-700">
                      {postImagePayload
                        ? postImagePayload.fileName
                        : lang === "mr"
                        ? "येथे क्लिक करून फोटो निवडा"
                        : "Tap to select image (JPG / PNG)"}
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoSelect}
                      className="hidden"
                    />
                  </label>

                  {postImagePreview && (
                    <div className="mt-2 relative rounded-xl overflow-hidden border border-slate-200">
                      <img
                        src={postImagePreview}
                        alt="Preview"
                        className="w-full h-40 object-cover"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          setPostImagePreview(null);
                          setPostImagePayload(null);
                        }}
                        className="absolute top-2 right-2 px-2 py-1 rounded bg-black/70 text-white text-xs cursor-pointer"
                      >
                        Remove
                      </button>
                    </div>
                  )}
                </div>

                <label className="flex items-center gap-2 text-sm font-medium text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={postPinned}
                    onChange={(e) => setPostPinned(e.target.checked)}
                    className="rounded border-slate-300 text-[#0D47A1]"
                  />
                  {lang === "mr"
                    ? "ही पोस्ट सर्वात वर पिन करा"
                    : "Pin this post to the top"}
                </label>

                <button
                  type="submit"
                  disabled={postSubmitting}
                  className="w-full py-3 rounded-xl bg-[#0D47A1] hover:bg-[#08245E] text-white font-bold text-sm shadow transition cursor-pointer"
                >
                  {postSubmitting
                    ? lang === "mr"
                      ? "प्रसिद्ध होत आहे..."
                      : "Publishing..."
                    : lang === "mr"
                    ? "वेबसाईटवर प्रसिद्ध करा"
                    : "Publish to Website"}
                </button>
              </form>
            </div>

            {/* Existing Posts */}
            <div className="lg:col-span-7 space-y-4">
              <h3 className="text-lg font-bold text-[#0F172A]">
                {lang === "mr" ? "प्रसिद्ध केलेल्या पोस्ट" : "Published Updates"} (
                {updatesList.length})
              </h3>
              {updatesList.map((u) => (
                <div
                  key={u.id}
                  className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col sm:flex-row gap-4 shadow-sm"
                >
                  {u.resolvedImageUrl && (
                    <img
                      src={u.resolvedImageUrl}
                      alt={u.titleEn}
                      className="w-full sm:w-32 h-28 object-cover rounded-xl shrink-0 bg-slate-100"
                    />
                  )}
                  <div className="flex-1 space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-bold uppercase text-[#0D47A1] bg-blue-50 px-2 py-0.5 rounded-full">
                        {u.category}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleTogglePinUpdate(u.id, u.isPinned)}
                          className={`p-1.5 rounded-lg text-xs cursor-pointer ${
                            u.isPinned
                              ? "bg-amber-100 text-amber-800"
                              : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                          }`}
                          title={u.isPinned ? "Unpin" : "Pin to top"}
                        >
                          {u.isPinned ? (
                            <PinOff className="w-4 h-4" />
                          ) : (
                            <Pin className="w-4 h-4" />
                          )}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteUpdate(u.id)}
                          className="p-1.5 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 cursor-pointer"
                          title="Delete post"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    <h4 className="font-bold text-[#0F172A] text-sm">
                      {u.titleEn}
                    </h4>
                    {u.titleMr && u.titleMr !== u.titleEn && (
                      <div className="text-xs font-semibold text-slate-700">
                        {u.titleMr}
                      </div>
                    )}
                    <p className="text-xs text-slate-600 line-clamp-2">
                      {u.bodyEn}
                    </p>
                    <div className="text-[11px] text-slate-400">
                      {u.authorName} •{" "}
                      {new Date(u.createdAt).toLocaleDateString("en-IN")}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: PUBLIC OPINIONS */}
        {activeTab === "opinions" && (
          <div className="space-y-4">
            {opinionsList.length === 0 ? (
              <div className="bg-white rounded-2xl p-8 text-center text-slate-500 border border-slate-200">
                No public opinions submitted yet.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {opinionsList.map((op) => (
                  <div
                    key={op.id}
                    className={`bg-white rounded-2xl p-5 border shadow-sm space-y-3 ${
                      !op.isVisible
                        ? "border-slate-200 opacity-60"
                        : op.isFeatured
                        ? "border-amber-400"
                        : "border-slate-200"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="font-bold text-[#0F172A]">{op.name}</div>
                        <div className="text-xs text-slate-500">
                          {op.city}
                          {op.role ? ` • ${op.role}` : ""}
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() =>
                            handleToggleOpinion(op.id, {
                              isFeatured: !op.isFeatured,
                            })
                          }
                          className={`p-1.5 rounded-lg text-xs cursor-pointer ${
                            op.isFeatured
                              ? "bg-amber-100 text-amber-800"
                              : "bg-slate-100 text-slate-600"
                          }`}
                          title="Highlight on Homepage"
                        >
                          <Sparkles className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            handleToggleOpinion(op.id, {
                              isVisible: !op.isVisible,
                            })
                          }
                          className="p-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 cursor-pointer"
                          title={op.isVisible ? "Hide from Public" : "Show"}
                        >
                          {op.isVisible ? (
                            <Eye className="w-4 h-4" />
                          ) : (
                            <EyeOff className="w-4 h-4" />
                          )}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteOpinion(op.id)}
                          className="p-1.5 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 cursor-pointer"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    <p className="text-sm text-slate-700 leading-relaxed">
                      “{op.message}”
                    </p>
                    <div className="text-[11px] text-slate-400">
                      {new Date(op.createdAt).toLocaleString("en-IN")}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: VENUE & TIME SETTINGS */}
        {activeTab === "venue" && (
          <div className="max-w-2xl bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8">
            <h2 className="text-xl font-extrabold text-[#0F172A] mb-2">
              {lang === "mr"
                ? "नाशिक स्थळ व वेळ जाहीर करा"
                : "Update Nashik Venue & Time"}
            </h2>
            <p className="text-sm text-slate-600 mb-6">
              {lang === "mr"
                ? "स्थळ आणि वेळ निश्चित झाल्यावर येथे बदल करा; ते लगेच मुख्य वेबसाईटवर दिसतील."
                : "Once the Organising Committee finalizes the Nashik venue and programme time, update them here to reflect live on the public homepage."}
            </p>

            <form onSubmit={handleSaveVenue} className="space-y-4">
              {venueSavedMsg && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-medium flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  {venueSavedMsg}
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Venue (English)
                </label>
                <input
                  type="text"
                  value={venueEn}
                  onChange={(e) => setVenueEn(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  स्थळ (मराठी)
                </label>
                <input
                  type="text"
                  value={venueMr}
                  onChange={(e) => setVenueMr(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Time (English)
                  </label>
                  <input
                    type="text"
                    value={timeEn}
                    onChange={(e) => setTimeEn(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    वेळ (मराठी)
                  </label>
                  <input
                    type="text"
                    value={timeMr}
                    onChange={(e) => setTimeMr(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={venueSaving}
                className="px-6 py-3 rounded-xl bg-[#0D47A1] hover:bg-[#08245E] text-white font-bold text-sm shadow cursor-pointer"
              >
                {venueSaving
                  ? "Saving..."
                  : lang === "mr"
                  ? "स्थळ व वेळ जतन करा"
                  : "Save Venue & Time"}
              </button>
            </form>
          </div>
        )}

        {/* TAB 5: CHIEF GUEST PHOTO */}
        {activeTab === "guestPhoto" && (
          <div className="max-w-2xl bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8">
            <h2 className="text-xl font-extrabold text-[#0F172A] mb-2 flex items-center gap-2">
              <Camera className="w-5 h-5 text-[#0D47A1]" />
              {lang === "mr"
                ? "प्रमुख पाहुण्यांचा फोटो बदला"
                : "Set Chief Guest Photo"}
            </h2>
            <p className="text-sm text-slate-600 mb-6">
              {lang === "mr"
                ? "अ‍ॅड. प्रकाश आंबेडकर यांचा नेमका फोटो येथे अपलोड करा. हा फोटो मुख्य पानावर त्यांच्या नावाजवळ लगेच दिसेल."
                : "Upload the exact photo of Adv. Prakash Ambedkar here. It will appear right beside his name in the Chief Guest card on the public homepage."}
            </p>

            {/* Live preview of how it looks beside the name */}
            <div className="mb-6 p-4 rounded-xl bg-gradient-to-r from-[#08245E] to-[#0D47A1] border border-blue-200 flex items-center gap-4">
              {(guestPhotoPreview || guestPhotoUrl) ? (
                <img
                  src={guestPhotoPreview || guestPhotoUrl || ""}
                  alt="Adv. Prakash Ambedkar"
                  className="w-20 h-20 rounded-full object-cover object-top border-2 border-amber-300 shadow-lg bg-white/10 shrink-0"
                />
              ) : (
                <div className="w-20 h-20 rounded-full bg-amber-400/20 border-2 border-amber-300/60 flex items-center justify-center text-amber-200 font-extrabold text-xl shrink-0">
                  PA
                </div>
              )}
              <div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-amber-300 mb-0.5">
                  {lang === "mr" ? "प्रमुख पाहुणे" : "Chief Guest"}
                </div>
                <div className="text-lg sm:text-xl font-extrabold text-white">
                  {lang === "mr" ? "अ‍ॅड. प्रकाश आंबेडकर" : "Adv. Prakash Ambedkar"}
                </div>
                <div className="text-xs text-blue-100">
                  {lang === "mr" ? "वेबसाईटवरील झलक" : "Homepage preview"}
                </div>
              </div>
            </div>

            <form onSubmit={handleSaveGuestPhoto} className="space-y-4">
              {guestPhotoMsg && (
                <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-[#0D47A1] text-sm font-medium">
                  {guestPhotoMsg}
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  {lang === "mr"
                    ? "फोन / संगणकावरून फोटो निवडा"
                    : "Upload Photo from Phone / PC"}
                </label>
                <label className="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 hover:border-[#0D47A1] rounded-xl p-5 cursor-pointer bg-slate-50 transition">
                  <ImagePlus className="w-7 h-7 text-[#0D47A1] mb-1.5" />
                  <span className="text-xs font-medium text-slate-700 text-center">
                    {guestPhotoPayload
                      ? guestPhotoPayload.fileName
                      : lang === "mr"
                      ? "येथे क्लिक करून फोटो निवडा (JPG / PNG)"
                      : "Tap to select the Chief Guest photo (JPG / PNG)"}
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleGuestPhotoSelect}
                    className="hidden"
                  />
                </label>
              </div>

              <div className="text-center text-xs text-slate-400 font-semibold">
                {lang === "mr" ? "किंवा" : "OR"}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {lang === "mr"
                    ? "फोटोची लिंक (ऐच्छिक)"
                    : "Paste an Image URL (Optional)"}
                </label>
                <input
                  type="text"
                  value={guestPhotoUrlInput}
                  onChange={(e) => setGuestPhotoUrlInput(e.target.value)}
                  placeholder="https://example.com/adv-prakash-ambedkar.jpg"
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                />
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-1">
                <button
                  type="submit"
                  disabled={guestPhotoSaving}
                  className="px-6 py-3 rounded-xl bg-[#0D47A1] hover:bg-[#08245E] disabled:opacity-60 text-white font-bold text-sm shadow cursor-pointer"
                >
                  {guestPhotoSaving
                    ? lang === "mr"
                      ? "जतन होत आहे..."
                      : "Saving..."
                    : lang === "mr"
                    ? "फोटो नावाजवळ लावा"
                    : "Save Photo Beside His Name"}
                </button>

                <button
                  type="button"
                  onClick={handleRemoveGuestPhoto}
                  className="inline-flex items-center gap-1.5 px-4 py-3 rounded-xl bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 font-semibold text-sm cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  {lang === "mr" ? "फोटो काढा" : "Remove Photo"}
                </button>
              </div>

              <p className="text-xs text-slate-500 pt-1">
                {lang === "mr"
                  ? "टीप: थेट दिलेला फोटो public/images/chief-guest.jpg म्हणून ठेवला असल्यास तो आपोआप वापरला जातो."
                  : "Tip: A photo supplied directly as public/images/chief-guest.jpg is also used automatically when no uploaded photo is set."}
              </p>
            </form>
          </div>
        )}

        {/* TAB 6: ORGANISER PHOTOS */}
        {activeTab === "organiserPhotos" && (
          <div className="space-y-6">
            {orgPhotoMsg && (
              <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-[#0D47A1] text-sm font-medium">
                {orgPhotoMsg}
              </div>
            )}

            {/* Per-organiser profile photos */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8">
              <h2 className="text-xl font-extrabold text-[#0F172A] mb-2 flex items-center gap-2">
                <Users className="w-5 h-5 text-[#0D47A1]" />
                {lang === "mr"
                  ? "आयोजकांचे प्रोफाइल फोटो"
                  : "Organiser Profile Photos"}
              </h2>
              <p className="text-sm text-slate-600 mb-6">
                {lang === "mr"
                  ? "प्रत्येक आयोजकासाठी एक फोटो निवडा. तो मुख्य पानावर त्यांच्या नावाच्या वर दिसेल."
                  : "Add one photo for each organiser. It appears above their name on the public homepage."}
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mb-7">
                {ORGANISER_SLOTS.map((slot) => {
                  const photoUrl = organiserPhotos.profiles[slot.key];
                  return (
                    <div
                      key={slot.key}
                      className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-center"
                    >
                      {photoUrl ? (
                        <img
                          src={photoUrl}
                          alt={lang === "mr" ? slot.nameMr : slot.nameEn}
                          className="w-14 h-14 rounded-full object-cover object-top border-2 border-[#0D47A1] mx-auto mb-2 bg-white"
                        />
                      ) : (
                        <div className="w-14 h-14 rounded-full bg-blue-100 text-[#0D47A1] flex items-center justify-center mx-auto mb-2 font-bold text-sm">
                          {slot.nameEn
                            .split(" ")
                            .map((w) => w[0])
                            .join("")}
                        </div>
                      )}
                      <div className="text-xs font-semibold text-[#0F172A] leading-tight">
                        {lang === "mr" ? slot.nameMr : slot.nameEn}
                      </div>
                      {photoUrl && (
                        <button
                          type="button"
                          onClick={() => handleRemoveProfilePhoto(slot.key)}
                          className="mt-2 inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 text-[11px] font-semibold cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                          {lang === "mr" ? "काढा" : "Remove"}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>

              <form onSubmit={handleSaveProfilePhoto} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {lang === "mr" ? "आयोजक निवडा" : "Select Organiser"}
                  </label>
                  <select
                    value={profileSlot}
                    onChange={(e) => setProfileSlot(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm bg-white"
                  >
                    {ORGANISER_SLOTS.map((slot) => (
                      <option key={slot.key} value={slot.key}>
                        {lang === "mr" ? slot.nameMr : slot.nameEn}
                      </option>
                    ))}
                  </select>
                </div>

                <label className="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 hover:border-[#0D47A1] rounded-xl p-5 cursor-pointer bg-slate-50 transition">
                  <ImagePlus className="w-7 h-7 text-[#0D47A1] mb-1.5" />
                  <span className="text-xs font-medium text-slate-700 text-center">
                    {profilePayload
                      ? profilePayload.fileName
                      : lang === "mr"
                      ? "फोटो निवडा (JPG / PNG)"
                      : "Choose organiser photo (JPG / PNG)"}
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleProfilePhotoSelect}
                    className="hidden"
                  />
                </label>

                {profilePreview && (
                  <img
                    src={profilePreview}
                    alt="Preview"
                    className="w-24 h-24 rounded-full object-cover object-top border-2 border-[#0D47A1] mx-auto"
                  />
                )}

                <button
                  type="submit"
                  disabled={orgPhotoSaving}
                  className="px-6 py-3 rounded-xl bg-[#0D47A1] hover:bg-[#08245E] disabled:opacity-60 text-white font-bold text-sm shadow cursor-pointer"
                >
                  {orgPhotoSaving
                    ? lang === "mr"
                      ? "जतन होत आहे..."
                      : "Saving..."
                    : lang === "mr"
                    ? "हा फोटो लावा"
                    : "Save Profile Photo"}
                </button>
              </form>
            </div>

            {/* Committee gallery */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8">
              <h2 className="text-xl font-extrabold text-[#0F172A] mb-2 flex items-center gap-2">
                <Images className="w-5 h-5 text-[#0D47A1]" />
                {lang === "mr"
                  ? "समिती फोटो गॅलरी"
                  : "Committee Photo Gallery"}
              </h2>
              <p className="text-sm text-slate-600 mb-6">
                {lang === "mr"
                  ? "बैठक, कार्यक्रम किंवा तयारीचे अनेक फोटो येथे जोडा; ते वेबसाईटवरील 'आयोजन समितीची छायाचित्रे' विभागात दिसतील."
                  : "Add multiple photos of meetings, preparations, or events. They appear in the 'Photos from the Organising Committee' section on the website."}
              </p>

              <form onSubmit={handleSaveGalleryPhoto} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {lang === "mr" ? "मथळा (English)" : "Caption (English)"}
                    </label>
                    <input
                      type="text"
                      value={galleryCaptionEn}
                      onChange={(e) => setGalleryCaptionEn(e.target.value)}
                      placeholder="e.g., Nashik preparatory meeting"
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {lang === "mr" ? "मथळा (मराठी)" : "Caption (Marathi)"}
                    </label>
                    <input
                      type="text"
                      value={galleryCaptionMr}
                      onChange={(e) => setGalleryCaptionMr(e.target.value)}
                      placeholder="उदा. नाशिक पूर्वतयारी बैठक"
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                    />
                  </div>
                </div>

                <label className="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 hover:border-[#0D47A1] rounded-xl p-5 cursor-pointer bg-slate-50 transition">
                  <ImagePlus className="w-7 h-7 text-[#0D47A1] mb-1.5" />
                  <span className="text-xs font-medium text-slate-700 text-center">
                    {galleryPayload
                      ? galleryPayload.fileName
                      : lang === "mr"
                      ? "गॅलरीसाठी फोटो निवडा"
                      : "Choose a committee photo"}
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleGalleryPhotoSelect}
                    className="hidden"
                  />
                </label>

                {galleryPreview && (
                  <img
                    src={galleryPreview}
                    alt="Gallery preview"
                    className="w-full max-w-sm h-40 object-cover rounded-xl border border-slate-200 mx-auto"
                  />
                )}

                <button
                  type="submit"
                  disabled={orgPhotoSaving}
                  className="px-6 py-3 rounded-xl bg-[#0D47A1] hover:bg-[#08245E] disabled:opacity-60 text-white font-bold text-sm shadow cursor-pointer"
                >
                  {orgPhotoSaving
                    ? lang === "mr"
                      ? "प्रसिद्ध होत आहे..."
                      : "Publishing..."
                    : lang === "mr"
                    ? "गॅलरीत जोडा"
                    : "Add Photo to Gallery"}
                </button>
              </form>

              {organiserPhotos.gallery.length > 0 && (
                <div className="mt-7 pt-6 border-t border-slate-200">
                  <h3 className="text-sm font-bold text-[#0F172A] mb-3">
                    {lang === "mr"
                      ? `प्रसिद्ध छायाचित्रे (${organiserPhotos.gallery.length})`
                      : `Published Photos (${organiserPhotos.gallery.length})`}
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                    {organiserPhotos.gallery.map((item) => (
                      <div
                        key={item.id}
                        className="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-50"
                      >
                        <img
                          src={item.url}
                          alt={
                            item.captionEn ||
                            item.captionMr ||
                            "Organising Committee"
                          }
                          className="w-full h-28 object-cover"
                        />
                        <div className="px-2 py-1.5 text-[11px] font-medium text-slate-700 truncate">
                          {lang === "mr"
                            ? item.captionMr || item.captionEn || "—"
                            : item.captionEn || item.captionMr || "—"}
                        </div>
                        <button
                          type="button"
                          onClick={() => handleDeleteGalleryPhoto(item.id)}
                          className="absolute top-1.5 right-1.5 p-1.5 rounded-lg bg-black/60 hover:bg-black text-white cursor-pointer"
                          title="Delete photo"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 7: DR. B.R. AMBEDKAR PHOTO */}
        {activeTab === "ambedkarPhoto" && (
          <div className="max-w-2xl bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8">
            <h2 className="text-xl font-extrabold text-[#0F172A] mb-2 flex items-center gap-2">
              <Camera className="w-5 h-5 text-[#0D47A1]" />
              {lang === "mr"
                ? "डॉ. बाबासाहेब आंबेडकरांचा फोटो बदला"
                : "Change Dr. B.R. Ambedkar Photo"}
            </h2>
            <p className="text-sm text-slate-600 mb-6">
              {lang === "mr"
                ? "येथे अपलोड केलेला फोटो मुख्य पानावर डॉ. आंबेडकर यांच्या विभागात मोठ्या आकारात दिसेल. काढून टाकल्यास मूळ ऐतिहासिक छायाचित्र पुन्हा दिसेल."
                : "The photo uploaded here appears large in the Dr. Ambedkar section on the homepage. Removing it restores the original archival portrait."}
            </p>

            {/* Large preview */}
            <div className="mb-6 p-4 rounded-xl bg-gradient-to-b from-[#0A2E7A] to-[#061B47] flex justify-center">
              <div className="rounded-2xl overflow-hidden border-4 border-amber-400/80 shadow-2xl max-w-[380px] w-full bg-slate-900">
                <img
                  src={
                    ambedkarPhotoPreview ||
                    ambedkarPhotoUrl ||
                    "/images/ambedkar-original.jpg"
                  }
                  alt="Dr. B.R. Ambedkar"
                  className="w-full h-auto object-cover block"
                />
              </div>
            </div>

            <form onSubmit={handleSaveAmbedkarPhoto} className="space-y-4">
              {ambedkarPhotoMsg && (
                <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-[#0D47A1] text-sm font-medium">
                  {ambedkarPhotoMsg}
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  {lang === "mr"
                    ? "फोन / संगणकावरून मोठा फोटो निवडा"
                    : "Upload Large Photo from Phone / PC"}
                </label>
                <label className="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 hover:border-[#0D47A1] rounded-xl p-5 cursor-pointer bg-slate-50 transition">
                  <ImagePlus className="w-7 h-7 text-[#0D47A1] mb-1.5" />
                  <span className="text-xs font-medium text-slate-700 text-center">
                    {ambedkarPhotoPayload
                      ? ambedkarPhotoPayload.fileName
                      : lang === "mr"
                      ? "येथे क्लिक करून फोटो निवडा (JPG / PNG)"
                      : "Tap to select Dr. Ambedkar's photo (JPG / PNG)"}
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleAmbedkarPhotoSelect}
                    className="hidden"
                  />
                </label>
              </div>

              <div className="text-center text-xs text-slate-400 font-semibold">
                {lang === "mr" ? "किंवा" : "OR"}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {lang === "mr"
                    ? "फोटोची लिंक (ऐच्छिक)"
                    : "Paste an Image URL (Optional)"}
                </label>
                <input
                  type="text"
                  value={ambedkarPhotoUrlInput}
                  onChange={(e) => setAmbedkarPhotoUrlInput(e.target.value)}
                  placeholder="https://example.com/dr-ambedkar.jpg"
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                />
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-1">
                <button
                  type="submit"
                  disabled={ambedkarPhotoSaving}
                  className="px-6 py-3 rounded-xl bg-[#0D47A1] hover:bg-[#08245E] disabled:opacity-60 text-white font-bold text-sm shadow cursor-pointer"
                >
                  {ambedkarPhotoSaving
                    ? lang === "mr"
                      ? "जतन होत आहे..."
                      : "Saving..."
                    : lang === "mr"
                    ? "मोठा फोटो लावा"
                    : "Save Large Photo"}
                </button>

                <button
                  type="button"
                  onClick={handleRemoveAmbedkarPhoto}
                  className="inline-flex items-center gap-1.5 px-4 py-3 rounded-xl bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 font-semibold text-sm cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  {lang === "mr" ? "मूळ फोटो आणा" : "Restore Original"}
                </button>
              </div>
            </form>
          </div>
        )}

        <div className="pt-4 pb-2 text-center text-xs font-medium text-slate-400">
          Design by Sangham Prakash
        </div>
      </main>
    </div>
  );
}
