import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
} from "drizzle-orm/pg-core";

export const eventSettings = pgTable("event_settings", {
  id: serial("id").primaryKey(),
  venueEn: text("venue_en")
    .notNull()
    .default("To be announced soon by the Organising Committee"),
  venueMr: text("venue_mr")
    .notNull()
    .default("आयोजन समितीमार्फत लवकरच जाहीर केले जाईल"),
  timeEn: text("time_en").notNull().default("To be announced soon"),
  timeMr: text("time_mr").notNull().default("लवकरच जाहीर केले जाईल"),
  guestPhotoId: integer("guest_photo_id"),
  guestPhotoUrl: text("guest_photo_url"),
  ambedkarPhotoId: integer("ambedkar_photo_id"),
  ambedkarPhotoUrl: text("ambedkar_photo_url"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const attendees = pgTable("attendees", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  phone: text("phone"),
  city: text("city").notNull(),
  organization: text("organization"),
  status: text("status").notNull().default("attending"), // 'attending' | 'maybe'
  companions: integer("companions").notNull().default(0),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const opinions = pgTable("opinions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  city: text("city").notNull(),
  role: text("role"),
  message: text("message").notNull(),
  isVisible: boolean("is_visible").notNull().default(true),
  isFeatured: boolean("is_featured").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const mediaAssets = pgTable("media_assets", {
  id: serial("id").primaryKey(),
  mimeType: text("mime_type").notNull(),
  base64Data: text("base_64_data").notNull(),
  fileName: text("file_name"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const organiserPhotos = pgTable("organiser_photos", {
  id: serial("id").primaryKey(),
  // 'profile' = one photo per organiser slot, 'gallery' = committee photos
  kind: text("kind").notNull().default("gallery"),
  slotKey: text("slot_key"),
  mediaId: integer("media_id"),
  imageUrl: text("image_url"),
  captionEn: text("caption_en"),
  captionMr: text("caption_mr"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const updates = pgTable("updates", {
  id: serial("id").primaryKey(),
  titleEn: text("title_en").notNull(),
  titleMr: text("title_mr"),
  bodyEn: text("body_en").notNull(),
  bodyMr: text("body_mr"),
  category: text("category").notNull().default("announcement"), // 'announcement' | 'venue' | 'photo' | 'press'
  authorName: text("author_name").notNull().default("Organising Committee"),
  mediaId: integer("media_id"),
  imageUrl: text("image_url"),
  isPinned: boolean("is_pinned").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type EventSettings = typeof eventSettings.$inferSelect;
export type Attendee = typeof attendees.$inferSelect;
export type Opinion = typeof opinions.$inferSelect;
export type UpdatePost = typeof updates.$inferSelect;
