import crypto from "crypto";
import { cookies } from "next/headers";

export const ORGANISER_COOKIE_NAME = "elgar_organiser_session";

function getSecret(): string {
  return (
    process.env.ORGANISER_SESSION_SECRET ||
    process.env.DATABASE_URL ||
    "elgar-parishad-nashik-2026-ambedkarite-secret"
  );
}

export function getOrganiserPasscode(): string {
  return process.env.ORGANISER_PASSCODE || "ELGAR2026";
}

export function verifyPasscode(input: string): boolean {
  const expected = getOrganiserPasscode();
  return input.trim() === expected;
}

export function createSessionToken(): string {
  const issuedAt = Date.now().toString();
  const payload = `organiser:${issuedAt}`;
  const hmac = crypto
    .createHmac("sha256", getSecret())
    .update(payload)
    .digest("hex");
  return `${payload}:${hmac}`;
}

export function verifySessionToken(token: string | undefined | null): boolean {
  if (!token) return false;
  const parts = token.trim().split(":");
  if (parts.length !== 3) return false;
  const [role, issuedAt, signature] = parts;
  if (role !== "organiser" || !issuedAt || !signature) return false;

  const payload = `${role}:${issuedAt}`;
  const expected = crypto
    .createHmac("sha256", getSecret())
    .update(payload)
    .digest("hex");

  const sigBuf = Buffer.from(signature, "utf8");
  const expBuf = Buffer.from(expected, "utf8");
  if (sigBuf.length !== expBuf.length) return false;
  if (!crypto.timingSafeEqual(sigBuf, expBuf)) return false;

  // Valid for 14 days (allow up to 60s clock skew)
  const ageMs = Date.now() - Number(issuedAt);
  if (Number.isNaN(ageMs) || ageMs < -60_000 || ageMs > 14 * 24 * 60 * 60 * 1000) {
    return false;
  }

  return true;
}

export async function isOrganiserAuthenticated(
  request?: Request
): Promise<boolean> {
  if (request) {
    const authHeader = request.headers.get("authorization");
    if (authHeader?.startsWith("Bearer ")) {
      const bearerToken = authHeader.slice(7).trim();
      if (verifySessionToken(bearerToken)) {
        return true;
      }
    }

    const headerToken = request.headers.get("x-organiser-token");
    if (verifySessionToken(headerToken)) {
      return true;
    }

    try {
      const url = new URL(request.url, "http://localhost");
      const queryToken = url.searchParams.get("token");
      if (verifySessionToken(queryToken)) {
        return true;
      }
    } catch {
      // ignore invalid URL
    }
  }

  const cookieStore = await cookies();
  const token = cookieStore.get(ORGANISER_COOKIE_NAME)?.value;
  return verifySessionToken(token);
}
