export type Lang = "en" | "mr";

export const TRANSLATIONS = {
  en: {
    siteTitle: "Elgar Parishad Nashik 2026",
    siteTagline: "Movement for Reservation in the Private Sector",
    nav: {
      mission: "Demand",
      ambedkar: "Dr. Ambedkar",
      organisers: "Organisers",
      rsvp: "Register Attendance",
      updates: "Updates & Photos",
      opinions: "Public Opinion",
      portal: "Organiser Portal",
    },
    langToggle: {
      en: "English",
      mr: "मराठी",
    },
    hero: {
      badge: "Constitutional Rights Movement • Nashik",
      title: "ELGAR PARISHAD",
      subtitle: "For Reservation in the Private Sector",
      description:
        "Uniting students, workers, intellectuals, and Bahujan citizens across Maharashtra to demand equal constitutional representation in private industry and corporate employment.",
      dateLabel: "Event Date",
      dateValue: "12th December 2026",
      cityLabel: "City",
      cityValue: "Nashik, Maharashtra",
      chiefGuestLabel: "Chief Guest & Keynote Speaker",
      chiefGuestName: "Adv. Prakash Ambedkar",
      chiefGuestRole: "National Leader & Constitutional Thinker",
      venueLabel: "Venue",
      timeLabel: "Time",
      ctaAttend: "Confirm Your Attendance",
      ctaOpinion: "Share Your Opinion",
      liveCountTitle: "Registered Supporters So Far",
      confirmedPeople: "Confirmed Headcount",
      registrationsCount: "Applications Received",
      tentativeCount: "Interested / Tentative",
    },
    ambedkar: {
      eyebrow: "Our Guiding Light & Constitutional Inspiration",
      name: "Bharat Ratna Dr. B. R. Ambedkar",
      years: "Architect of the Indian Constitution (1891–1956)",
      photoCaption: "Original Archival Portrait — Dr. Bhimrao Ramji Ambedkar",
      quote:
        "Educate, Agitate and Organize; have faith in yourself. With justice on our side, I do not see how we can lose our battle.",
      secondaryQuote:
        "Political democracy cannot last unless there lies at the base of it social and economic democracy.",
      contextNote:
        "In an era where public sector jobs are shrinking and private corporations drive national employment, extending constitutional reservation to the private sector is essential to fulfill Dr. Ambedkar's vision of equality of opportunity.",
    },
    mission: {
      eyebrow: "Why This Elgar Parishad?",
      heading: "Equal Opportunity in the Private Sector is a Constitutional Necessity",
      points: [
        {
          title: "Shrinking Public Employment",
          desc: "Privatization and contractual hiring have drastically reduced government jobs, making private sector representation indispensable for SC, ST, OBC, and marginalized youth.",
        },
        {
          title: "Corporate Social Accountability",
          desc: "Private industries benefit from public land, subsidies, and national resources—they must reflect India's social diversity across all job levels.",
        },
        {
          title: "Law for Private Sector Reservation",
          desc: "Elgar Parishad Nashik demands concrete legislation ensuring fair reservation, skill support, and anti-discrimination safeguards in private enterprises.",
        },
      ],
    },
    organisers: {
      eyebrow: "Leadership & Coordination",
      heading: "Organising Committee",
      subtitle:
        "Dedicated leadership spearheading the Elgar Parishad movement in Nashik on 12th December 2026.",
      topTierBadge: "Organisers",
      topRow: [
        {
          name: "Babanrao Gholap",
          role: "Organiser",
          subtitle: "Elgar Parishad Organising Committee, Nashik",
        },
        {
          name: "Vilas Patil",
          role: "Organiser",
          subtitle: "Elgar Parishad Organising Committee, Nashik",
        },
        {
          name: "Prakash Bagul",
          role: "Organiser",
          subtitle: "Elgar Parishad Organising Committee, Nashik",
        },
      ],
      bottomRow: [
        {
          name: "Mahesh Avhad",
          role: "Organiser",
          subtitle: "Elgar Parishad Organising Committee, Nashik",
        },
        {
          name: "Sanjay Donde",
          role: "Organiser",
          subtitle: "Elgar Parishad Organising Committee, Nashik",
        },
      ],
      venueNotice:
        "The official Nashik venue and programme schedule will be announced soon by the Organising Committee.",
      galleryTitle: "Photos from the Organising Committee",
      gallerySubtitle:
        "Glimpses of our meetings, preparations, and the movement for reservation in the private sector.",
      galleryEmpty:
        "Photos shared by the Organising Committee will appear here soon.",
    },
    rsvp: {
      eyebrow: "Stand Up & Be Counted",
      heading: "Will You Attend Elgar Parishad?",
      subtitle:
        "Register your attendance so the Organising Committee can plan seating, logistics, and share venue updates with you.",
      fullName: "Full Name",
      fullNamePlaceholder: "Enter your full name",
      phone: "Mobile Number",
      phonePlaceholder: "10-digit mobile number",
      city: "City / Taluka / District",
      cityPlaceholder: "e.g., Nashik, Sinnar, Igatpuri, Pune",
      organization: "Organisation / Group / College (Optional)",
      organizationPlaceholder: "e.g., Student Wing, Trade Union, Independent",
      attendanceChoice: "Are you attending on 12th Dec 2026?",
      attendingYes: "Yes, I will definitely attend",
      attendingMaybe: "Interested / Will confirm soon",
      companions: "Additional People Joining With You",
      companionsHelp: "Enter 0 if attending alone, or number of companions/group members.",
      notes: "Message for Organisers (Optional)",
      notesPlaceholder: "Any volunteer interest or travel info...",
      submitBtn: "Submit Attendance Registration",
      submitting: "Registering...",
      successTitle: "Attendance Registered Successfully!",
      successDesc:
        "Thank you for standing with the movement for reservation in the private sector. Your participation has been recorded for the Organising Committee.",
      refLabel: "Registration Reference",
      registerAnother: "Register Another Person",
    },
    updates: {
      eyebrow: "Official Bulletins & Photos",
      heading: "Latest Updates from the Organisers",
      subtitle:
        "Stay informed about venue announcements, preparatory meetings, press notes, and rally photos.",
      pinnedBadge: "Pinned Notice",
      noUpdates: "Updates from the Organising Committee will appear here shortly.",
      categories: {
        announcement: "Announcement",
        venue: "Venue & Schedule",
        photo: "Photo Update",
        press: "Press Release",
      },
      postedBy: "Posted by",
    },
    opinions: {
      eyebrow: "Voices of the People",
      heading: "Share Your Opinion on Private Sector Reservation",
      subtitle:
        "Your thoughts, suggestions, and support messages are directly reviewed by the Organising Committee.",
      formTitle: "Write Your Opinion",
      nameLabel: "Your Name",
      namePlaceholder: "Enter your name",
      cityLabel: "City / District",
      cityPlaceholder: "e.g., Nashik",
      roleLabel: "Occupation / Role (Optional)",
      rolePlaceholder: "e.g., Student, Engineer, Worker, Citizen",
      messageLabel: "Your Opinion / Suggestion",
      messagePlaceholder:
        "Share why private sector reservation matters to you or your suggestions for Elgar Parishad...",
      submitBtn: "Submit Opinion",
      submitting: "Submitting...",
      successMsg:
        "Thank you! Your opinion has been recorded and sent to the Organising Committee.",
      feedTitle: "Community Voices",
      featuredBadge: "Highlighted by Organisers",
      emptyFeed: "Be the first to share your opinion with the movement.",
    },
    footer: {
      heading: "Elgar Parishad • Nashik • 12th December 2026",
      sub: "Demand for Constitutional Reservation in the Private Sector — Chief Guest: Adv. Prakash Ambedkar",
      organisersLine:
        "Organisers: Babanrao Gholap, Vilas Patil, Prakash Bagul, Mahesh Avhad, Sanjay Donde",
      portalLink: "Organiser Login & Dashboard",
      copyright: "Jai Bhim • Constitutional Equality & Justice",
      designBy: "Design by Sangham Prakash",
    },
  },
  mr: {
    siteTitle: "एल्गार परिषद नाशिक २०२६",
    siteTagline: "खाजगी क्षेत्रातील आरक्षणासाठी जनआंदोलन",
    nav: {
      mission: "मागणी",
      ambedkar: "डॉ. आंबेडकर",
      organisers: "आयोजक",
      rsvp: "उपस्थिती नोंदवा",
      updates: "माहिती व छायाचित्रे",
      opinions: "जनमत",
      portal: "आयोजक पोर्टल",
    },
    langToggle: {
      en: "English",
      mr: "मराठी",
    },
    hero: {
      badge: "घटनात्मक हक्क आंदोलन • नाशिक",
      title: "एल्गार परिषद",
      subtitle: "खाजगी क्षेत्रात आरक्षणाचा हक्क",
      description:
        "खाजगी उद्योग आणि कॉर्पोरेट क्षेत्रातील रोजगारात समान घटनात्मक प्रतिनिधित्व मिळावे, या न्याय्य मागणीसाठी नाशिक येथे विद्यार्थी, कामगार, विचारवंत आणि बहुजन समाज एकत्र येत आहे.",
      dateLabel: "कार्यक्रम दिनांक",
      dateValue: "१२ डिसेंबर २०२६",
      cityLabel: "ठिकाण (शहर)",
      cityValue: "नाशिक, महाराष्ट्र",
      chiefGuestLabel: "प्रमुख पाहुणे व मार्गदर्शक",
      chiefGuestName: "अ‍ॅड. प्रकाश आंबेडकर",
      chiefGuestRole: "राष्ट्रीय नेते व संविधान अभ्यासक",
      venueLabel: "स्थळ",
      timeLabel: "वेळ",
      ctaAttend: "आपली उपस्थिती नोंदवा",
      ctaOpinion: "आपले मत नोंदवा",
      liveCountTitle: "आतापर्यंत नोंदणीकृत समर्थक",
      confirmedPeople: "अपेक्षित एकूण उपस्थिती",
      registrationsCount: "प्राप्त अर्ज / नोंदणी",
      tentativeCount: "इच्छुक / कळवणारे",
    },
    ambedkar: {
      eyebrow: "आपली प्रेरणा व घटनात्मक दीपस्तंभ",
      name: "भारतरत्न डॉ. बाबासाहेब आंबेडकर",
      years: "भारतीय संविधानाचे शिल्पकार (१८९१–१९५६)",
      photoCaption: "मूळ ऐतिहासिक छायाचित्र — डॉ. भीमराव रामजी आंबेडकर",
      quote:
        "शिका, संघटित व्हा आणि संघर्ष करा; स्वतःवर विश्वास ठेवा. न्याय आपल्या बाजूने असताना आपण ही लढाई हरू शकणार नाही.",
      secondaryQuote:
        "सामाजिक आणि आर्थिक लोकशाहीचा भक्कम पाया असल्याशिवाय राजकीय लोकशाही दीर्घकाळ टिकू शकत नाही.",
      contextNote:
        "सरकारी नोकऱ्या कमी होत असताना आणि खाजगी क्षेत्रात रोजगार वाढत असताना, संधीच्या समानतेचे डॉ. बाबासाहेब आंबेडकरांचे स्वप्न पूर्ण करण्यासाठी खाजगी क्षेत्रात आरक्षण कायदा अत्यंत आवश्यक आहे.",
    },
    mission: {
      eyebrow: "ही एल्गार परिषद का?",
      heading: "खाजगी क्षेत्रातील समान संधी ही काळाची व संविधानाची गरज",
      points: [
        {
          title: "कमी होत जाणारे सरकारी रोजगार",
          desc: "खाजगीकरण आणि कंत्राटी पद्धतीमुळे शासकीय नोकऱ्या घटल्या आहेत; त्यामुळे अनुसूचित जाती, जमाती, ओबीसी व वंचित तरुणांसाठी खाजगी क्षेत्रात आरक्षण अत्यावश्यक आहे.",
        },
        {
          title: "खाजगी उद्योगांचे सामाजिक दायित्व",
          desc: "खाजगी उद्योग सार्वजनिक जमीन, सवलती आणि देशाच्या संसाधनांचा लाभ घेतात—म्हणून त्यांच्या नोकऱ्यांमध्ये भारताच्या सामाजिक विविधतेचे प्रतिबिंब दिसलेच पाहिजे.",
        },
        {
          title: "खाजगी क्षेत्रातील आरक्षणासाठी कायदा",
          desc: "खाजगी उद्योगांमध्ये न्याय्य आरक्षण, कौशल्य विकास आणि भेदभावविरोधी संरक्षण देणारा ठोस कायदा करण्याची मागणी नाशिकच्या एल्गार परिषदेतून केली जाणार आहे.",
        },
      ],
    },
    organisers: {
      eyebrow: "नेतृत्व व समन्वय",
      heading: "आयोजन समिती",
      subtitle:
        "१२ डिसेंबर २०२६ रोजी नाशिक येथे होणाऱ्या एल्गार परिषदेचे आयोजक.",
      topTierBadge: "आयोजक",
      topRow: [
        {
          name: "बबनराव घोलप",
          role: "आयोजक",
          subtitle: "एल्गार परिषद आयोजन समिती, नाशिक",
        },
        {
          name: "विलास पाटील",
          role: "आयोजक",
          subtitle: "एल्गार परिषद आयोजन समिती, नाशिक",
        },
        {
          name: "प्रकाश बागुल",
          role: "आयोजक",
          subtitle: "एल्गार परिषद आयोजन समिती, नाशिक",
        },
      ],
      bottomRow: [
        {
          name: "महेश आव्हाड",
          role: "आयोजक",
          subtitle: "एल्गार परिषद आयोजन समिती, नाशिक",
        },
        {
          name: "संजय दोंदे",
          role: "आयोजक",
          subtitle: "एल्गार परिषद आयोजन समिती, नाशिक",
        },
      ],
      venueNotice:
        "नाशिकमधील निश्चित स्थळ आणि कार्यक्रमाची वेळ आयोजन समितीमार्फत लवकरच जाहीर केली जाईल.",
      galleryTitle: "आयोजन समितीची छायाचित्रे",
      gallerySubtitle:
        "बैठका, पूर्वतयारी आणि खाजगी क्षेत्रातील आरक्षणाच्या चळवळीची काही झलक.",
      galleryEmpty:
        "आयोजन समितीने पाठवलेली छायाचित्रे लवकरच येथे दिसतील.",
    },
    rsvp: {
      eyebrow: "चळवळीत सहभागी व्हा",
      heading: "आपण एल्गार परिषदेस उपस्थित राहणार का?",
      subtitle:
        "आयोजन समितीला नियोजनासाठी व आपल्यापर्यंत स्थळ-वेळेची माहिती पोहोचवण्यासाठी कृपया आपली उपस्थिती नोंदवा.",
      fullName: "संपूर्ण नाव",
      fullNamePlaceholder: "आपले संपूर्ण नाव लिहा",
      phone: "मोबाईल नंबर",
      phonePlaceholder: "१० अंकी मोबाईल नंबर",
      city: "शहर / तालुका / जिल्हा",
      cityPlaceholder: "उदा. नाशिक, सिन्नर, इगतपुरी, पुणे",
      organization: "संघटना / गट / महाविद्यालय (ऐच्छिक)",
      organizationPlaceholder: "उदा. विद्यार्थी संघटना, कामगार संघटना",
      attendanceChoice: "आपण १२ डिसेंबर २०२६ रोजी उपस्थित राहणार का?",
      attendingYes: "होय, मी नक्की उपस्थित राहणार आहे",
      attendingMaybe: "इच्छुक आहे / लवकरच कळवेन",
      companions: "आपल्या सोबत येणाऱ्या इतर व्यक्तींची संख्या",
      companionsHelp: "एकटे येत असल्यास ० ठेवा, किंवा सोबत येणाऱ्या सहकाऱ्यांची संख्या लिहा.",
      notes: "आयोजकांसाठी संदेश (ऐच्छिक)",
      notesPlaceholder: "स्वयंसेवक सेवा किंवा प्रवासाबाबत माहिती...",
      submitBtn: "उपस्थिती नोंदवा",
      submitting: "नोंदणी सुरू आहे...",
      successTitle: "आपली उपस्थिती यशस्वीरित्या नोंदवली गेली!",
      successDesc:
        "खाजगी क्षेत्रातील आरक्षणाच्या लढ्याला पाठिंबा दिल्याबद्दल धन्यवाद. आपली नोंद आयोजन समितीकडे पोहोचली आहे.",
      refLabel: "नोंदणी क्रमांक",
      registerAnother: "दुसऱ्या व्यक्तीची नोंदणी करा",
    },
    updates: {
      eyebrow: "अधिकृत माहिती व छायाचित्रे",
      heading: "आयोजकांकडून ताज्या घडामोडी",
      subtitle:
        "स्थळ घोषणा, पूर्वतयारी बैठका, प्रसिद्धीपत्रके आणि कार्यक्रमाची छायाचित्रे येथे पहा.",
      pinnedBadge: "महत्त्वाची सूचना",
      noUpdates: "आयोजन समितीकडील ताजी माहिती लवकरच येथे प्रसिद्ध होईल.",
      categories: {
        announcement: "जाहीर सूचना",
        venue: "स्थळ व वेळ",
        photo: "छायाचित्र",
        press: "प्रसिद्धीपत्रक",
      },
      postedBy: "प्रकाशित:",
    },
    opinions: {
      eyebrow: "जनतेचा आवाज",
      heading: "खाजगी क्षेत्रातील आरक्षणावर आपले मत नोंदवा",
      subtitle:
        "आपले विचार, सूचना आणि पाठिंब्याचे संदेश थेट आयोजन समितीपर्यंत पोहोचतात.",
      formTitle: "आपले मत लिहा",
      nameLabel: "आपले नाव",
      namePlaceholder: "आपले नाव लिहा",
      cityLabel: "शहर / जिल्हा",
      cityPlaceholder: "उदा. नाशिक",
      roleLabel: "व्यवसाय / ओळख (ऐच्छिक)",
      rolePlaceholder: "उदा. विद्यार्थी, अभियंता, कामगार, नागरिक",
      messageLabel: "आपले मत / सूचना",
      messagePlaceholder:
        "खाजगी क्षेत्रात आरक्षण का गरजेचे आहे किंवा एल्गार परिषदेबाबत आपल्या सूचना येथे लिहा...",
      submitBtn: "मत पाठवा",
      submitting: "पाठवले जात आहे...",
      successMsg: "धन्यवाद! आपले मत आयोजन समितीकडे यशस्वीरित्या नोंदवले गेले आहे.",
      feedTitle: "नागरिकांचे विचार",
      featuredBadge: "आयोजकांकडून निवडलेले",
      emptyFeed: "चळवळीसाठी आपले पहिले मत नोंदवा.",
    },
    footer: {
      heading: "एल्गार परिषद • नाशिक • १२ डिसेंबर २०२६",
      sub: "खाजगी क्षेत्रात घटनात्मक आरक्षणाची मागणी — प्रमुख पाहुणे: अ‍ॅड. प्रकाश आंबेडकर",
      organisersLine:
        "आयोजक: बबनराव घोलप, विलास पाटील, प्रकाश बागुल, महेश आव्हाड, संजय दोंदे",
      portalLink: "आयोजक लॉगिन व डॅशबोर्ड",
      copyright: "जय भीम • संवैधानिक समता आणि न्याय",
      designBy: "Design by Sangham Prakash",
    },
  },
} as const;
