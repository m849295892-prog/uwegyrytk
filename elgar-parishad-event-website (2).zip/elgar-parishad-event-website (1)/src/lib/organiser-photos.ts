export const ORGANISER_SLOTS = [
  {
    key: "babanrao-gholap",
    nameEn: "Babanrao Gholap",
    nameMr: "बबनराव घोलप",
  },
  {
    key: "vilas-patil",
    nameEn: "Vilas Patil",
    nameMr: "विलास पाटील",
  },
  {
    key: "prakash-bagul",
    nameEn: "Prakash Bagul",
    nameMr: "प्रकाश बागुल",
  },
  {
    key: "mahesh-avhad",
    nameEn: "Mahesh Avhad",
    nameMr: "महेश आव्हाड",
  },
  {
    key: "sanjay-donde",
    nameEn: "Sanjay Donde",
    nameMr: "संजय दोंदे",
  },
] as const;

export type OrganiserSlotKey = (typeof ORGANISER_SLOTS)[number]["key"];

export interface OrganiserGalleryPhoto {
  id: number;
  url: string;
  captionEn: string | null;
  captionMr: string | null;
}

export interface OrganiserPhotosDTO {
  profiles: Record<string, string>;
  gallery: OrganiserGalleryPhoto[];
}

export function isOrganiserSlotKey(value: string): value is OrganiserSlotKey {
  return ORGANISER_SLOTS.some((slot) => slot.key === value);
}
