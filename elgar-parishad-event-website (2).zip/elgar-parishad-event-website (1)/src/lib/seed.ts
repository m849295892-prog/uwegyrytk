import { db } from "@/db";
import { eventSettings, opinions, updates } from "@/db/schema";
import { sql } from "drizzle-orm";

let seedPromise: Promise<void> | null = null;

export async function ensureSeedData(): Promise<void> {
  if (seedPromise) return seedPromise;
  seedPromise = (async () => {
    try {
      const [{ count: settingsCount }] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(eventSettings);

      if (settingsCount === 0) {
        await db.insert(eventSettings).values({
          venueEn: "To be announced soon by the Organising Committee (Nashik)",
          venueMr: "आयोजन समितीमार्फत लवकरच जाहीर केले जाईल (नाशिक)",
          timeEn: "To be announced soon",
          timeMr: "लवकरच जाहीर केले जाईल",
        });
      }

      const [{ count: updatesCount }] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(updates);

      if (updatesCount === 0) {
        await db.insert(updates).values([
          {
            titleEn:
              "Elgar Parishad for Private Sector Reservation — 12th December 2026, Nashik",
            titleMr:
              "खाजगी क्षेत्रातील आरक्षणासाठी एल्गार परिषद — १२ डिसेंबर २०२६, नाशिक",
            bodyEn:
              "We invite all citizens, students, workers, and Ambedkarite organisations to unite in Nashik on 12th December 2026 under the guidance of Chief Guest Adv. Prakash Ambedkar to raise our constitutional demand for reservation in the private sector.",
            bodyMr:
              "खाजगी क्षेत्रातील आरक्षणाच्या घटनात्मक मागणीसाठी १२ डिसेंबर २०२६ रोजी नाशिक येथे प्रमुख पाहुणे अ‍ॅड. प्रकाश आंबेडकर यांच्या मार्गदर्शनाखाली होणाऱ्या एल्गार परिषदेत सर्व नागरिक, विद्यार्थी, कामगार आणि आंबेडकरी संघटनांनी मोठ्या संख्येने सहभागी व्हावे.",
            category: "announcement",
            authorName: "Organising Committee (Babanrao Gholap, Vilas Patil, Prakash Bagul)",
            isPinned: true,
          },
          {
            titleEn: "Venue & Schedule Notice from the Organising Committee",
            titleMr: "स्थळ व वेळेबाबत आयोजन समितीची सूचना",
            bodyEn:
              "Preparations across Nashik district are underway. The exact ground/venue and detailed schedule for 12th December 2026 will be officially announced soon by the Organising Committee. Please register your attendance below to receive timely updates.",
            bodyMr:
              "नाशिक जिल्ह्यात तयारी वेगाने सुरू आहे. १२ डिसेंबर २०२६ च्या परिषदेचे निश्चित ठिकाण आणि सविस्तर वेळापत्रक आयोजन समितीमार्फत लवकरच जाहीर केले जाईल. वेळेवर माहिती मिळवण्यासाठी कृपया खाली आपली उपस्थिती नोंदवा.",
            category: "venue",
            authorName: "Organising Committee",
            isPinned: false,
          },
        ]);
      }

      const [{ count: opinionsCount }] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(opinions);

      if (opinionsCount === 0) {
        await db.insert(opinions).values([
          {
            name: "Milind Kamble",
            city: "Nashik",
            role: "Youth Activist",
            message:
              "With rapid privatization across industries, constitutional reservation in the private sector is essential for social justice and equal opportunity. Fully supporting Elgar Parishad!",
            isVisible: true,
            isFeatured: true,
          },
          {
            name: "सुजाता गायकवाड",
            city: "मनमाड, नाशिक",
            role: "विद्यार्थिनी",
            message:
              "खाजगी क्षेत्रात आरक्षण लागू झाल्याशिवाय बहुजन तरुणांना समान संधी मिळणार नाही. १२ डिसेंबर रोजी नाशिकच्या एल्गार परिषदेत आम्ही नक्की सहभागी होणार!",
            isVisible: true,
            isFeatured: true,
          },
        ]);
      }
    } catch (error) {
      // Allow retry if DB wasn't ready yet
      seedPromise = null;
      console.error("ensureSeedData error:", error);
    }
  })();
  return seedPromise;
}
