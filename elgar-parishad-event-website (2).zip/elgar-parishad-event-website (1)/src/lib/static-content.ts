// Static fallback content used when the public homepage is pre-rendered.
// It mirrors the default seeded database content so the static page looks
// identical to the live site even before client-side hydration.

export const STATIC_FALLBACK_SETTINGS = {
  id: 1,
  venueEn: "To be announced soon by the Organising Committee (Nashik)",
  venueMr: "आयोजन समितीमार्फत लवकरच जाहीर केले जाईल (नाशिक)",
  timeEn: "To be announced soon",
  timeMr: "लवकरच जाहीर केले जाईल",
  guestPhotoUrl: null as string | null,
  ambedkarPhotoUrl: null as string | null,
};

export const STATIC_FALLBACK_UPDATES = [
  {
    id: 1,
    titleEn:
      "Elgar Parishad for Private Sector Reservation — 12th December 2026, Nashik",
    titleMr:
      "खाजगी क्षेत्रातील आरक्षणासाठी एल्गार परिषद — १२ डिसेंबर २०२६, नाशिक" as string | null,
    bodyEn:
      "We invite all citizens, students, workers, and Ambedkarite organisations to unite in Nashik on 12th December 2026 under the guidance of Chief Guest Adv. Prakash Ambedkar to raise our constitutional demand for reservation in the private sector.",
    bodyMr:
      "खाजगी क्षेत्रातील आरक्षणाच्या घटनात्मक मागणीसाठी १२ डिसेंबर २०२६ रोजी नाशिक येथे प्रमुख पाहुणे अ‍ॅड. प्रकाश आंबेडकर यांच्या मार्गदर्शनाखाली होणाऱ्या एल्गार परिषदेत सर्व नागरिक, विद्यार्थी, कामगार आणि आंबेडकरी संघटनांनी मोठ्या संख्येने सहभागी व्हावे." as string | null,
    category: "announcement",
    authorName:
      "Organising Committee (Babanrao Gholap, Vilas Patil, Prakash Bagul)",
    resolvedImageUrl: null as string | null,
    isPinned: true,
    createdAt: "2026-11-20T09:00:00.000Z",
  },
  {
    id: 2,
    titleEn: "Venue & Schedule Notice from the Organising Committee",
    titleMr: "स्थळ व वेळेबाबत आयोजन समितीची सूचना" as string | null,
    bodyEn:
      "Preparations across Nashik district are underway. The exact ground/venue and detailed schedule for 12th December 2026 will be officially announced soon by the Organising Committee. Please register your attendance below to receive timely updates.",
    bodyMr:
      "नाशिक जिल्ह्यात तयारी वेगाने सुरू आहे. १२ डिसेंबर २०२६ च्या परिषदेचे निश्चित ठिकाण आणि सविस्तर वेळापत्रक आयोजन समितीमार्फत लवकरच जाहीर केले जाईल. वेळेवर माहिती मिळवण्यासाठी कृपया खाली आपली उपस्थिती नोंदवा." as string | null,
    category: "venue",
    authorName: "Organising Committee",
    resolvedImageUrl: null as string | null,
    isPinned: false,
    createdAt: "2026-11-21T09:00:00.000Z",
  },
];

export const STATIC_FALLBACK_OPINIONS = [
  {
    id: 1,
    name: "Milind Kamble",
    city: "Nashik",
    role: "Youth Activist" as string | null,
    message:
      "With rapid privatization across industries, constitutional reservation in the private sector is essential for social justice and equal opportunity. Fully supporting Elgar Parishad!",
    isVisible: true,
    isFeatured: true,
    createdAt: "2026-11-22T09:00:00.000Z",
  },
  {
    id: 2,
    name: "सुजाता गायकवाड",
    city: "मनमाड, नाशिक",
    role: "विद्यार्थिनी" as string | null,
    message:
      "खाजगी क्षेत्रात आरक्षण लागू झाल्याशिवाय बहुजन तरुणांना समान संधी मिळणार नाही. १२ डिसेंबर रोजी नाशिकच्या एल्गार परिषदेत आम्ही नक्की सहभागी होणार!",
    isVisible: true,
    isFeatured: true,
    createdAt: "2026-11-23T09:00:00.000Z",
  },
];

export const STATIC_FALLBACK_ORGANISER_PHOTOS = {
  profiles: {} as Record<string, string>,
  gallery: [] as {
    id: number;
    url: string;
    captionEn: string | null;
    captionMr: string | null;
  }[],
};
